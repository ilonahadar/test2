if [ -z $CONFIGWS_URL ]
then
  CONFIGWS_URL=https://configservice.np.e-pic.systems/epicws-nonprod.yml
fi

## Get config.yml
curl -fsSL $CONFIGWS_URL > config.yaml

## Append log configuration
cat log_config.yaml >> config.yaml

mkdir logs
./awslogs-agent-setup.py -n -r us-east-1 -c  aws_cloudwatch_agent_config.conf > logs/awslogs-agent.log
java -Dnewrelic.config.app_name=$NEW_RELIC_APP_NAME -Dnewrelic.config.license_key=$NEW_RELIC_LICENSE_KEY -javaagent:newrelic/newrelic.jar -jar ws-epic.jar server config.yaml

