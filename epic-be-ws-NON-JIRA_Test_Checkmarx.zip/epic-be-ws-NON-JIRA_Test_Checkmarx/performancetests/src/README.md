##EPIC Backend Performance Tests

###Pre-requisites to epic-load- tests

- JAVA JDK 8+
- Scala 2.12+
- Apache Maven

###To run performance tests follow these steps

- access to AWS 'EPIC' non prod account to retrieve AWS Secret Manager credentials.
- login to `prof epicnonprod` account to run on the nonprod environment and `prof epicprod` account to run on the prod environment.
- go to performanceTests directory: from terminal `cd performanceTests`
- run the simulations through CML by passing following commands
`mvn gatling:test`  - This will run default on nonprod environment with default parameters
`mvn gatling:test -Denv=nonprod ` - This will run on nonprod environment with default  parameters
`mvn gatling:test -Denv=prod ` - This will run on prod environment with default parameters
`mvn gatling:test -Denv=nonprod -DUSERS=1 -DMAX_USERS=5 -DDURATION=2 -DMAX_DURATION=90` - This will run on non prod env with the parameters which will pass through                                                                                                           ─╯
`mvn gatling:test -Denv=prod -DUSERS=1 -DMAX_USERS=5 -DDURATION=2 -DMAX_DURATION=90` - This will run on prod env with the parameters which will pass through                                                                                                           ─╯


###DynamicProperties
- By default, all widget simulations are executed according to `DynamicProperties` class.
- It is configurable according to business requirements.

###Reports

- Generated reports can be found in `target/gatling` folder. Open `index.html` file in your preferred browser.

- At the end of each execution of a Gatling script, a Gatling Results Report is automatically created.
You will see a message in the console about where the report is located, i.e.:
  `/Users/xxxx/epic-fe-app/epic-be-ws/performancetests/target/gatling/scopususage-20220617112544511/index.html`

