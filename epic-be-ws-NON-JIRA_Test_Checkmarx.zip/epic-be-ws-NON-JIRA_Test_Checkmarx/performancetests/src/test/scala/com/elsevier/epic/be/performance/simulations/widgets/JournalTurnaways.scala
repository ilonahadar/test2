package com.elsevier.epic.be.performance.simulations.widgets

import com.elsevier.epic.be.performance.simulations.widgets.CredentialsLoader.credentialsFeeder
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration.DurationInt
import scala.language.postfixOps

class JournalTurnaways extends BaseSimulation {

  before {
    widgetInfo("Journal Turnaways", prop: DynamicProperties)
  }


  val httpConf = http.baseUrl(prop.baseURL)
    .check(status.is(200))


  val journalTurnaways = scenario("Accessing to Journal Turnaways")
    .feed(credentialsFeeder.circular)
    .feed(csv("data/journalTurnawaysParams.csv").circular)
    .exec(http("Navigate to Journal Turnaways")
      .get("/v3/journal/categories")
      .digestAuth("#{username}", "#{password}")
      .queryParam("type", "#{type}")
      .check(status.is(200))
      .check(jsonPath("$..[?(@.code)]").exists)
      .check(jsonPath("$..[?(@.name)]").exists))


  setUp(
    journalTurnaways.inject(rampConcurrentUsers(prop.minNumOfUsers) to (prop.maxNumOfUsers) during (prop.testDuration.minutes)).protocols(httpConf)
  ).assertions(
    global.failedRequests.percent.is(0),
    forAll.responseTime.mean.between(prop.minMeanResponseTime, prop.maxMeanResponseTime)

  ).maxDuration(prop.maxDuration.minutes)
}



