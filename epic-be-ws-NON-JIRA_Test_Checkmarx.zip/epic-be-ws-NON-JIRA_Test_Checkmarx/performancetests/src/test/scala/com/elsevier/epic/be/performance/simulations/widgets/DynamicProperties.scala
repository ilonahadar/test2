package com.elsevier.epic.be.performance.simulations.widgets

import com.elsevier.epic.be.performance.simulations.config.ApplicationConfig

class DynamicProperties {


  private def getProperty(property_name: String, default_value: String): String = {
    Option(System.getProperty(property_name))
      .getOrElse(default_value)
  }

  val appConfig = ApplicationConfig.getApplicationConfig

  def baseURL: String = getProperty("URL", appConfig.base_url)

  def setInstitution: String = getProperty("INSTITUTION", "ECR-866")

  def minNumOfUsers: Int = getProperty("USERS", "1").toInt

  def maxNumOfUsers: Int = getProperty("MAX_USERS", "20").toInt

  def testDuration: Int = getProperty("DURATION", "1").toInt

  def maxDuration: Int = getProperty("MAX_DURATION", "90").toInt

  def minMeanResponseTime: Int = getProperty("MINIMUM_MEAN_RESPONSE", "1").toInt

  def maxMeanResponseTime: Int = getProperty("MAXIMUM_MEAN_RESPONSE", "3500").toInt

}
