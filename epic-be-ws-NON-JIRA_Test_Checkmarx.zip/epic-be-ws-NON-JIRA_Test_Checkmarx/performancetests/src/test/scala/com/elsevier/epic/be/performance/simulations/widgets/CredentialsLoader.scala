package com.elsevier.epic.be.performance.simulations.widgets

import com.elsevier.epic.be.performance.simulations.GetSecrets
import com.elsevier.epic.be.performance.simulations.config.ApplicationConfig
import spray.json.DefaultJsonProtocol

object CredentialsLoader extends DefaultJsonProtocol {


  case class Credentials(
                          username: String,
                          password: String,
                          access_level: Int
                        )

  import spray.json._

  implicit val credentialsFormat = jsonFormat3(Credentials)

  val appConfig = ApplicationConfig.getApplicationConfig

  val credentialJson = scala.util.Properties.envOrElse("DIGEST_CREDENTIALS", new GetSecrets().getSecret(appConfig.profile_name, appConfig.aws_arn))

  val credentials = credentialJson.parseJson.convertTo[List[Credentials]]

  val filteredCredentials = credentials.filter(p => p.username.contains(appConfig.username_includes))

  val credentialsFeeder = filteredCredentials.map { p => Map("username" -> p.username, "password" -> p.password) }.toArray


}
