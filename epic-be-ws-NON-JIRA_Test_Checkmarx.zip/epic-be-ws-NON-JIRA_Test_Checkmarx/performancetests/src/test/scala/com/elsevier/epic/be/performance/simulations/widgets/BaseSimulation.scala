package com.elsevier.epic.be.performance.simulations.widgets

import io.gatling.core.Predef.Simulation
import scala.language.postfixOps

trait BaseSimulation extends Simulation {
  trait CredentialsLoader

  val prop = new DynamicProperties()

  def widgetInfo(name: String, prop: DynamicProperties): Unit = {
    println(s"Running ${name} in  ${prop.baseURL} environment for ${prop.testDuration} minutes.")

  }
}
