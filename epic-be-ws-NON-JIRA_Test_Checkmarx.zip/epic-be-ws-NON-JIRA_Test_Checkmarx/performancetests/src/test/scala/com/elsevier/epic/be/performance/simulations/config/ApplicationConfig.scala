package com.elsevier.epic.be.performance.simulations.config

import com.typesafe.config._

object ApplicationConfig {

  /* Command Line Parameters for Gatling Scenarios
     This method look for the system property of either prod or nonprod.
     If it cant find either, it will take the default value as nonprod.
 */

  def getApplicationConfig: ApplicationConfig = {
    val env: String = Option(System.getProperty("env"))
      .getOrElse("nonprod")

    val conf: Config = ConfigFactory.load("data/serenity.conf").getConfig(s"environments.$env")
    ApplicationConfig(
      base_url = conf.getString("base.url"),
      aws_arn = conf.getString("aws.arn"),
      profile_name = conf.getString("profile.name"),
      username_includes  = conf.getString("username.includes"))

  }
}

sealed case class ApplicationConfig(base_url: String,
                                    aws_arn: String,
                                    profile_name: String,
                                    username_includes: String)
