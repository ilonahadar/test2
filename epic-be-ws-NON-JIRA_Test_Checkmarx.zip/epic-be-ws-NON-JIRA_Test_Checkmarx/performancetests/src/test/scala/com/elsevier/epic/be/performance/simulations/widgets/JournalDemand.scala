package com.elsevier.epic.be.performance.simulations.widgets

import com.elsevier.epic.be.performance.simulations.widgets.CredentialsLoader.credentialsFeeder
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration.DurationInt
import scala.language.postfixOps

class JournalDemand extends BaseSimulation {

  before {
    widgetInfo("Journal Demand", prop: DynamicProperties)
  }


  val httpConf = http.baseUrl(prop.baseURL)
    .check(status.is(200))


  val journalDemand = scenario("Accessing to Journal Demand")
    .feed(credentialsFeeder.circular)
    .feed(csv("data/journalDemandParams.csv").circular)
    .exec(http("Navigate to Journal Demand")
      .get("/v3/account/" + prop.setInstitution + "/cop5/sd/top/25/journals")
      .digestAuth("#{username}", "#{password}")
      .queryParam("period", "#{period}")
      .check(status.is(200))
      .check(jsonPath(" $.totalRecords").exists))


  setUp(
    journalDemand.inject(rampConcurrentUsers(prop.minNumOfUsers) to (prop.maxNumOfUsers) during (prop.testDuration.minutes)).protocols(httpConf)
  ).assertions(
    global.failedRequests.percent.is(0),
    forAll.responseTime.mean.between(prop.minMeanResponseTime, prop.maxMeanResponseTime)

  ).maxDuration(prop.maxDuration.minutes)
}



