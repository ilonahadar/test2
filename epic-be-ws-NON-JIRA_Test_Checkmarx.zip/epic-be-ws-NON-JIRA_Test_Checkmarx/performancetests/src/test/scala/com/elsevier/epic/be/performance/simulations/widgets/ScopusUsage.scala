package com.elsevier.epic.be.performance.simulations.widgets

import com.elsevier.epic.be.performance.simulations.widgets.CredentialsLoader.credentialsFeeder
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration.DurationInt
import scala.language.postfixOps

class ScopusUsage extends BaseSimulation {

  before {
    widgetInfo("Scopus Usage", prop: DynamicProperties)
  }

  val httpConf = http.baseUrl(prop.baseURL)
    .check(status.is(200))


  val scopusUsage = scenario("Accessing to Scopus Usage")
    .feed(csv("data/scopusUsageParams.csv").circular)
    .feed(credentialsFeeder.circular)
    .exec(http("Navigate to Scopus Usage")
      .get("/v3/account/" + prop.setInstitution + "/sc/usagev2")
      .digestAuth("#{username}", "#{password}")
      .queryParam("yearStart", "#{yearStart}")
      .queryParam("yearEnd", "#{yearEnd}")
      .check(status.is(200))
      .check(jsonPath(" $.parameters").exists))


  setUp(
    scopusUsage.inject(rampConcurrentUsers(prop.minNumOfUsers) to (prop.maxNumOfUsers) during (prop.testDuration.minutes)).protocols(httpConf)
  ).assertions(
    global.failedRequests.percent.is(0),
    forAll.responseTime.mean.between(prop.minMeanResponseTime, prop.maxMeanResponseTime)

  ).maxDuration(prop.maxDuration.minutes)
}















