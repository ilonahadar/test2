package com.elsevier.epic.be.performance.simulations

import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider
import software.amazon.awssdk.regions.Region
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient
import software.amazon.awssdk.services.secretsmanager.model._

import java.util.Base64

class GetSecrets {

  def getSecret(profileName: String,
                arn: String): String = {
    var secret: String = null
    var decodedBinarySecret: String = null

    val credentialProvider = ProfileCredentialsProvider.builder().profileName(profileName).build()

    // Create a Secrets Manager client
    val client = SecretsManagerClient.builder()
      .region(Region.US_EAST_1)
      .credentialsProvider(credentialProvider)
      .build()

    val getSecretValueRequest = GetSecretValueRequest.builder().secretId(arn).build()
    var getSecretValueResult: GetSecretValueResponse = null
    try getSecretValueResult = client.getSecretValue(getSecretValueRequest)

    catch {
      case e: DecryptionFailureException =>
        // Secrets Manager can't decrypt the protected secret text using the provided KMS key.
        // Deal with the exception here, and/or rethrow at your discretion.
        throw e
      case e: InternalServiceErrorException =>
        // An error occurred on the server side.
        throw e
      case e: InvalidParameterException =>
        // You provided an invalid value for a parameter.
        throw e
      case e: InvalidRequestException =>
        // You provided a parameter value that is not valid for the current state of the resource.
        throw e
      case e: ResourceNotFoundException =>
        // We can't find the resource that you asked for.
        throw e
    }
    // Decrypts secret using the associated KMS key.
    // Depending on whether the secret is a string or binary, one of these fields will be populated.
    if (getSecretValueResult.secretString() != null) secret = getSecretValueResult.secretString()
    else decodedBinarySecret = new String(Base64.getDecoder.decode(getSecretValueResult.secretString()).array)
    // Your code goes here.
    secret

  }


}
