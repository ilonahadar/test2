package com.elsevier.epic.be.performance.simulations.widgets

import com.elsevier.epic.be.performance.simulations.widgets.CredentialsLoader.credentialsFeeder
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration.DurationInt
import scala.language.postfixOps

class ScienceDirectUsage extends BaseSimulation {

  before {
    widgetInfo("Science Direct Usage", prop: DynamicProperties)
  }


  val httpConf = http.baseUrl(prop.baseURL)
    .check(status.is(200))


  val SDUsageBreakdown = scenario("Accessing to Science Direct Usage Breakdown")
    .feed(credentialsFeeder.circular)
    .feed(csv("data/scienceDirectParams.csv").circular)
    .exec(http("Navigate to Science Direct Usage Breakdown")
      .get("/v3/account/" + prop.setInstitution + "/sd/usagebreakdown")
      .digestAuth("#{username}", "#{password}")
      .queryParam("startyear", "#{startyear}")
      .queryParam("endyear", "#{endyear}")
      .queryParam("returnPlatforms", "#{returnPlatforms}")
      .queryParam("metric", "#{metric}")
      .check(status.is(200))
      .check(jsonPath(" $.Total").exists))


  setUp(
    SDUsageBreakdown.inject(rampConcurrentUsers(prop.minNumOfUsers) to (prop.maxNumOfUsers) during (prop.testDuration.minutes)).protocols(httpConf)
  ).assertions(
    global.failedRequests.percent.is(0),
    forAll.responseTime.mean.between(prop.minMeanResponseTime, prop.maxMeanResponseTime)

  ).maxDuration(prop.maxDuration.minutes)
}

