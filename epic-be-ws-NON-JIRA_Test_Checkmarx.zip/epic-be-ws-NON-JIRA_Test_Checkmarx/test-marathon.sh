#!/bin/bash
# Upload the EPIC web service to S3 epic-test folder
# Follow this up with run-epic to launch the web service in Marathon

# Generic function for uploading to S3

upload()
{
dateValue=`date -R`
bucket="alternative-metrics"
resource="/${bucket}/${destfile}"
contentType="application/octet-stream"
stringToSign="PUT\n\n${contentType}\n${dateValue}\n${resource}"
signature=`echo -en ${stringToSign} | openssl sha1 -hmac ${S3SECRET} -binary | base64`

curl -X PUT -T "${srcfile}" -H "Host: ${bucket}.s3.amazonaws.com" -H "Date: ${dateValue}" \
  -H "Content-Type: ${contentType}" -H "Authorization: AWS ${S3KEY}:${signature}" \
  https://${bucket}.s3.amazonaws.com/${destfile}
}

# Upload tasks

srcfile="data/schema.xml"
destfile="marathon/epic-test/schema.xml"
upload

srcfile="data/server.yml"
destfile="marathon/epic-test/server.yml"
upload

srcfile="target/ws-epic-0.2.jar"
destfile="marathon/epic-test/ws-epic.jar"
upload

echo "Creating configuration in Marathon..."

curl --socks5 127.0.0.1:8080 -H "Content-Type: application/json" http://10.182.2.116:8080/v2/apps -d '{
  "id": "test-epic",
  "instances": 1,
  "cpus": 0.8,
  "mem": 1024,
  "ports": [ 19999, 19998 ],
  "uris": [
    "http://10.182.2.122:31574/alternative-metrics/marathon/epic-test/ws-epic.jar",
    "http://10.182.2.122:31574/alternative-metrics/marathon/epic-test/schema.xml",
    "http://10.182.2.122:31574/alternative-metrics/marathon/epic-test/server.yml"
  ],
  "cmd": "java $JAVA_OPTS -Duser.timezone=GMT -Ddw.environment=prod -Ddw.server.applicationConnectors[0].port=19999 -Ddw.server.adminConnectors[0].port=19998 -Ddw.server.applicationConnectors[0].bindHost=0.0.0.0 -Ddw.serviceFile=schema.xml -jar ws-*.jar server server.yml",
  "env": {"JAVA_OPTS": "-Xms64m -Xmx1024m -XX:NewRatio=3 -XX:MaxTenuringThreshold=15 -XX:+HeapDumpOnOutOfMemoryError -XX:+UseParNewGC"}
}'

sleep 20

echo "Restarting service."

# Marathon will perform a rolling restart of the web service with this request.
curl --socks5 127.0.0.1:8080 -XPOST -H "Content-Type: application/json" http://10.182.2.116:8080/v2/apps/test-epic/restart
