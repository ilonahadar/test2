# EPIC API

This project is the main build for the EPIC web service.  It produces a fat JAR that can be launched from the command line.

## Execution

#### To run the app from IntelliJ

1. Get the database credentials from the `epic-rcdb-credential` secret on SM
2. Create a new Gradle build for this project:
   1. Top right, _Edit Configurations_...
   2. Plus (+) sign, Gradle 
   3. In the _Tasks and Arguments_ box, put `runApp`
   4. In the _Environment Variables_ box, put
      1. `POSTGRES_USER=<db_username_from_secret>;POSTGRES_PASSWORD=<db_password_from_secret>;ENCRYPTION_KEY=<encryption_keys_from_secret>`
   5. Save the gradle build by clicking _Apply_
3. Change your project's SDK
   1. Top left in the MacOS taskbar, _File_ -> _Project Structure_
   2. In the menu on the left, click _Project_
   3. Make sure the SDK is set to `1.8`
      1. If you haven't got a `1.8` option, you'll need to install JDK 8
      2. I recommend [sdkman](https://sdkman.io) for that
4. Make sure you have the nonprod profile active in your environment (run `prof ....`)
5. Run the new configuration you made


#### To run the app from the command line

You must

* have the variables mentioned above in step 4.iv.a set in your environment.
* make sure you are using Java 8 in your shell (confirm via `java -version`)
* have the nonprod aws profile active

Run the following command inside the project root dir
```
./gradlew runApp
```

#### Build documentation 
The `runApp` gradle task will build the app, package it in a "fat" jar and handle fetching from the config service and storing of the `local_config.yaml` needed for launching the app.
The jar is finally ran via a basic `java -jar` command, with the following parameters `server local_config.yaml`.

The 'server' parameter instructs DropWizard to run in server mode and the yml file is the server configuration.  
Due to their sensitive nature, please do not upload YML configuration files to this repository.

Please note that the XML schema file for the service is found in 'data/schema.xml'.

## Code Coverage

Coverage reports are generated with Jacoco.  When running the service, you should find that a Jacoco report file is generated at target/jacoco.exec.  You can convert this into an HTML report by running:

```
mvn jacoco:report
```

## Integration Testing

Integration tests are not supported as yet.

## Further Information

Please refer to the internal Confluence wiki for further information about this project.
