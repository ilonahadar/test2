SELECT * FROM getRA_PersonalizedUsers(?);
SELECT * FROM getRA_DeviceTypeUsage(?);
SELECT * FROM getRA_AccessType(?);
SELECT * FROM getRA_GenPersonalized(?, ARRAY['ANON_SHIBBOLETH','REG_SHIBBOLETH']::text[]);
SELECT * FROM getRA_GenPersonalized(?, ARRAY['ANON_IP','REG_IP']::text[]);
SELECT * FROM getRA_PeerInstitutions(?)