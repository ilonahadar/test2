SELECT * FROM getcombineddbsearchmetrics(?,?);
