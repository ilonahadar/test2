SELECT * FROM getScopusUsageV2(?,?,?,?);
SELECT * FROM getScopusUsageSubjectPrevYear(?);
SELECT * FROM getScopusUsageSubjectPrevYear_v2(?)