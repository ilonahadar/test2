select * from getmie_JournalArticles_read(?,?,?);
select * from getmie_JournalArticles_published(?,?,?);