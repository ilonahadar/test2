select acc_id, b.acct_name, platforms from accounts_flat_map a, (
select acct_id, acct_name, array_agg(platform_name) as platforms from acct_to_platform
where platform_primary_flag='Y' group by acct_id, acct_name
) b
where a.acc_id=b.acct_id and sis_hq=?;
