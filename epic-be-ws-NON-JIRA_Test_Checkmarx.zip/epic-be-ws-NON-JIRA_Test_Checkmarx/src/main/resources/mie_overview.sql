SELECT * FROM getmie_institutionprofiles(?);
SELECT * FROM getmie_MinMemberLoginMonth(?);
SELECT * FROM getmie_activemembersrunningtotal(?);
SELECT * FROM getmie_groupscreated_runningtotal(?) limit 3;
SELECT * FROM getmie_groupsjoinedrunningtotal(?) limit 3;
SELECT * FROM getmie_member_academicprofession(?);
SELECT * FROM getmie_member_academicdomains(?);
SELECT * FROM getmie_SubjectArea(?);

