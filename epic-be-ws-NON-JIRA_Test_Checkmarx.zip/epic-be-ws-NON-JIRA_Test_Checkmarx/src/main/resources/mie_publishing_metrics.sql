select * from getmie_topNjournals_published(?,?) limit 100;
select * from getmie_topmembers_published(?,?) limit 100;