select * from get_SCTotalCitingCountriesbySubject(?,?);
select * from get_SCTotalReferencedCountriesbySubject(?,?);
select * from get_SCTotalReadingCountriesbySubject(?,?);
select * from get_SCTotalPatentCitingCountriesbySubject(?,?);
select * from get_SCTopCitingCountriesbySubject(?,?,?);
select * from get_SCTopReferencedCountriesbySubject(?,?,?);
select * from get_SCTopReadingCountriesbySubject(?,?,?);
select * from get_SCTopPatentCitingCountriesbySubject(?,?,?);