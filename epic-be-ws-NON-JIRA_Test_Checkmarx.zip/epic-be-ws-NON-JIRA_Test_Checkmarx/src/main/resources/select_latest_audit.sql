SELECT table_name, import_date, source_date
FROM (
   SELECT table_name, import_date, source_date, rank() OVER (PARTITION BY table_name ORDER BY import_date DESC) AS rnk
   FROM import_audit
) ia
WHERE rnk = 1
ORDER BY import_date DESC;
