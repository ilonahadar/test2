select * from getmie_topNjournals_read(?,?) limit 100;
select * from getmie_topArticles_read(?,?) limit 100;