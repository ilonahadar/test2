select sv_id, inst_name, segment, customer_id, hq_country, account_id, platform, affils, super_account_type, sv_name from vw_epic_accounts a where a.sis_hq=?
