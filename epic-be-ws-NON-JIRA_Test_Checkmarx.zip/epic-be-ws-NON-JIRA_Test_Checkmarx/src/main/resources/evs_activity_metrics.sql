select * from get_SDUsagebySubject(?,?);
select * from get_SCPublicationsbySubject(?,?);
select * from get_SCReferencesbySubject(?,?);
select * from get_SCCitationsbySubject(?,?);
select * from get_PatentCitationsbySubject(?,?);