SELECT * FROM getEVUsage(?,?,?,?);
SELECT * FROM getEVTopSearches(?,?,?);
