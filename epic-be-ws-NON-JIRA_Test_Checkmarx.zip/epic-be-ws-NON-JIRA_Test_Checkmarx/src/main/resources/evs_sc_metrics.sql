select * from get_SCAvgCitations(?,?) union select * from get_SCAvgCitationsbyPublisher(?,?);
