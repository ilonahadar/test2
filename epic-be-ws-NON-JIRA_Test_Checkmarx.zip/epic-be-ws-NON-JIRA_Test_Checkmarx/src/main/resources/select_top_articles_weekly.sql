SELECT
           top.year_week,
           top.pii,
           top.count AS total,
           j.title AS source_name,
           j.issn AS isxn,
           j.imprint,
           pp.authors,
           pp.title,
           a.pub_date,
           a.doi,
           a.volume,
           a.issue,
           a.content_type
        FROM vw_top_articles top
        INNER JOIN sdarticle_p a ON a.pii=top.pii
        INNER JOIN pii_title_authors pp on pp.pii=top.pii
        INNER JOIN journal j ON j.issn=a.isxn
        WHERE top.sis=?
        ORDER BY year_week DESC, total DESC, pub_date DESC
        LIMIT ?;