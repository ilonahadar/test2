/**
 * Helpful generic functions that relate to the processing of incoming requests and outgoing responses.
 */

package com.elsevier.epic.core;

import com.elsevier.epic.auth.URIAuthorisation;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.jaxb.AuthType;
import com.elsevier.epic.jaxb.ResourceType;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

public class WebAssist {
   private static final TimeZone tzDefault = TimeZone.getTimeZone("UTC");

   /**
    * Perform all response configuration options for the targeted resource.
    *
    * @param pResource
    * @param pResponse
    * @return
    */

   public static ResponseBuilder configureResponse(ResourceType pResource, ResponseBuilder pResponse) {
      checkResourceExpiry(pResource, pResponse);
      return pResponse;
   }

   /**
    * Set the 'Expires' HTTP header if the resource utilises the &lt;expires&gt; tag.
    *
    * @param pResource
    * @param pResponse
    */

   public static void checkResourceExpiry(ResourceType pResource, ResponseBuilder pResponse) {
      Integer expires = pResource.getExpires();

      if (expires == null) return;

      if (expires == -1) expires = 60 * 60 * 24 * 365 * 10; // -1, never expires (set to 10 years).

      if (expires > 0) { // Expires in X seconds
         Calendar expiry = Calendar.getInstance(tzDefault);
         expiry.add(Calendar.SECOND, expires);
         pResponse.expires(expiry.getTime());

         CacheControl cc = new CacheControl();
         cc.setMaxAge(expires);
         cc.setPrivate(false);
         pResponse.cacheControl(cc);
      }
   }

   /**
    * Perform authorisation if required for this resource.  A WebApplicationException is thrown if
    * authorisation fails.
    *
    * @param pResource
    * @param pRequest
    * @param pIDs
    */

   public static void checkResourceAuthentication(ResourceType pResource, HttpServletRequest pRequest, ArrayList<IDValue> pIDs) {
      List<AuthType> authList = pResource.getAuth();
      if (authList != null) {
         for (AuthType auth : authList) {
            String className = auth.getClazz();

            try {
               Class cl = Class.forName(auth.getClazz()); // On-the-fly class resolution...
               Object obj = cl.getConstructor().newInstance();
               if (obj instanceof URIAuthorisation) {
                  ((URIAuthorisation)obj).authorise(pRequest, pIDs);
               }
            }
            catch (ClassNotFoundException | NoSuchMethodException | SecurityException ex) {
               throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
                  .setMessage("The authorisation settings for this interface are not defined correctly.")
                  .setException(ex)
                  .build());
            }
            catch (IllegalAccessException | InvocationTargetException | InstantiationException ex) {
               throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
                  .setMessage("Failed to call the authorisation interface.")
                  .setException(ex)
                  .build());
            }
         }
      }
   }
}
