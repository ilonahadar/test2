package com.elsevier.epic.cop5;

import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TopJournalTurnaways implements DataFeed {
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

   static class TurnawayResult {
       final String issn;
       final String title;
       final int total;
       final int year;
       final int month;

       public TurnawayResult(String issn, String title, int total, int year, int month) {
           this.issn = issn;
           this.title = title;
           this.total = total;
           this.year = year;
           this.month = month;
       }
   }

   interface FindTurnawayQuery {
      class TurnawayMap implements ResultSetMapper<TurnawayResult> {
          @Override
          public TurnawayResult map(int row, ResultSet rst, StatementContext ctxStatement) throws SQLException {
              return new TurnawayResult(rst.getString(1), rst.getString(2), rst.getInt(3), rst.getInt(4), rst.getInt(5));
          }
      }

       // TO DO ... why does journal_monthly_usage have m6, m12, m24, m36 configurable where it is not HERE?
       @Mapper(TurnawayMap.class)
       @SqlQuery("SELECT v.issn, j.title, m12, year, month FROM vw_journal_monthly_turnaways_rolling_c5 v, journal j WHERE sis=:accountId and j.issn= v.issn ORDER BY m12 DESC LIMIT :limit;")
       List<TurnawayResult> getTurnaways(@Bind("accountId") int accountId, @Bind("limit") int limit);
   }

   // Entry point for querying top N turnaways

   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      int accountId = Integer.parseInt(pIDs.get(0).value);
      int count = Integer.parseInt(pIDs.get(1).value);

      FindTurnawayQuery turnawayQuery = PostgresClient.getDBI().onDemand(FindTurnawayQuery.class);
      List<TurnawayResult> results = turnawayQuery.getTurnaways(accountId, count);

      if (results.size() == 0) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.NO_CONTENT)
            .setMessage("No data available for the queried account.")
            .build());
      }

      int year = results.get(0).year;
      int month = results.get(0).month;

      ArrayNode jsResults = jsFactory.arrayNode();
      int totalRecords = 0;
      for (TurnawayResult entry : results) {
         ObjectNode jsObject = jsResults.addObject();
         jsObject.put("issn", entry.issn);
         jsObject.put("title", entry.title);
         jsObject.put("total", entry.total);
         totalRecords++;
         if (--count <= 0) break;
      }

      ObjectNode jsRoot = jsFactory.objectNode();
      jsRoot.put("totalRecords", totalRecords);
      jsRoot.put("reportDate", String.format("%04d-%02d-01", year, month));
      jsRoot.put("period", 12);
      jsRoot.put("interval", "monthly");
      jsRoot.set("results", jsResults);

      return Response.ok(jsRoot).build();
   }
}
