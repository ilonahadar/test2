package com.elsevier.epic.scival.collaboration;

import java.util.ArrayList;
import java.util.List;

/**
 * Encapsulates the json response
 */
public class SciValCollaborationByCountryResponse {
    private List<Result> results = new ArrayList<>();
    private String countryName;
    private float FWCI;

    public SciValCollaborationByCountryResponse(String countryName, float fwci) {
        this.countryName = countryName;
        this.FWCI = fwci;
    }

    public void addResult(String institutionName, int coAuthoredPublications, float coAuthoredGrowthPercent, float institutionFWCI, float coAuthFWCI) {
        results.add(new Result(institutionName, coAuthoredPublications, coAuthoredGrowthPercent, institutionFWCI, coAuthFWCI));
    }

    public int resultCount() {
        return results.size();
    }

    public class Result {
        private String institutionName;
        private final int coAuthPub;
        private final float coAuthGrowth;
        private final float institutionFWCI;
        private float coAuthFWCI;

        public Result(String institutionName, int coAuthPub, float coAuthGrowth, float institutionFWCI, float coAuthFWCI) {
            this.institutionName = institutionName;
            this.coAuthPub = coAuthPub;
            this.coAuthGrowth = coAuthGrowth;
            this.institutionFWCI = institutionFWCI;
            this.coAuthFWCI = coAuthFWCI;
        }
    }
}
