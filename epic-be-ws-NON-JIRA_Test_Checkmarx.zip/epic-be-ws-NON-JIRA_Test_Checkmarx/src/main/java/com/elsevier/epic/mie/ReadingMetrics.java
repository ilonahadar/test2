package com.elsevier.epic.mie;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.io.InputStream;
import java.sql.*;
import java.util.*;


public class ReadingMetrics implements DataFeed{

    private static final Logger LOG = Log.getLogger(ReadingMetrics.class);
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

    PreparedStatement getStatement(Connection con) throws SQLException {

        PreparedStatement ps = con.prepareStatement(getResourceString("/mie_reading_metrics.sql"));
        ps.setQueryTimeout(60);
        return ps;
    }

    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {

        if (pIDs.size() < 1) throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);

        String paramAccount  = pIDs.get(0).value;
        String paramSubjectID = pIDs.get(1).value;

        int accountID;
        int subjectID;
        try { accountID = Integer.parseInt(paramAccount);
              subjectID = Integer.parseInt(paramSubjectID);}
        catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
                    .setMessage("Invalid ID '" + paramAccount + "'")
                    .setException(ex)
                    .build());
        }

        ObjectNode jsRoot = jsFactory.objectNode();
        ObjectNode jsParams = jsFactory.objectNode();
        jsRoot.set("parameters", jsParams);
        jsParams.put("sisid", paramAccount);
        jsParams.put("subjectid", paramSubjectID);

        queryCounter(jsRoot, accountID, subjectID);
        return Response.ok(jsRoot).build();
    }

    private void queryCounter(ObjectNode pResult, int pSIS, int pSubID){

        try (Connection con = PostgresClient.getConnection();
            PreparedStatement ps = getStatement(con)){

            ps.setInt(1, pSIS);
            ps.setInt(2, pSubID);
            ps.setInt(3, pSIS);
            ps.setInt(4, pSubID);

            if (!CoreServer.isProduction()) LOG.info(ps.toString());

            ObjectNode readMetrics = jsFactory.objectNode();

            ps.execute();

            topJournals(ps, readMetrics, "TopJournals");
            ps.getMoreResults();
            topArticles(ps, readMetrics, "TopArticles");

            pResult.set("result", readMetrics);

        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }
    }

    static private void topJournals(PreparedStatement ps, ObjectNode ReadMetrics, String name) throws java.sql.SQLException {

        ResultSet rst = ps.getResultSet();

        ObjectNode timeNode = jsFactory.objectNode();
        ArrayNode rowNode1 = jsFactory.arrayNode();
        ArrayNode rowNode2 = jsFactory.arrayNode();
        ArrayNode rowNode3 = jsFactory.arrayNode();

        while (rst.next()) {

            String timePeriod = rst.getString(1);
            String issn = rst.getString(2);
            String journalTitle = rst.getString(3);
            String articleReadCount = rst.getString(4);
            String rank = rst.getString(5);

            if (timePeriod.equals("All")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("issn", issn);
                locNode.put("journal_title", journalTitle);
                locNode.put("articles_count", articleReadCount);
                locNode.put("rank", rank);

                rowNode1.add(locNode);

                timeNode.set("All_Time", rowNode1);

            }

            if (timePeriod.equals("This_Year")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("issn", issn);
                locNode.put("journal_title", journalTitle);
                locNode.put("articles_count", articleReadCount);
                locNode.put("rank", rank);

                rowNode2.add(locNode);

                timeNode.set(timePeriod, rowNode2);

            }

            if (timePeriod.equals("This_Month")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("issn", issn);
                locNode.put("journal_title", journalTitle);
                locNode.put("articles_count", articleReadCount);
                locNode.put("rank", rank);

                rowNode3.add(locNode);

                timeNode.set(timePeriod, rowNode3);

            }

        }

        ReadMetrics.set(name, timeNode);

    }

    static private void topArticles(PreparedStatement ps, ObjectNode ReadMetrics, String name) throws java.sql.SQLException {

        ResultSet rst = ps.getResultSet();

        ObjectNode timeNode = jsFactory.objectNode();
        ArrayNode rowNode1 = jsFactory.arrayNode();
        ArrayNode rowNode2 = jsFactory.arrayNode();
        ArrayNode rowNode3 = jsFactory.arrayNode();

        while (rst.next()) {

            String timePeriod = rst.getString(1);
            String articletitle = rst.getString(2);
            String readersCnt = rst.getString(3);
            String articleRank = rst.getString(4);

            if (timePeriod.equals("All")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("article_title", articletitle);
                locNode.put("readers_count", readersCnt);
                locNode.put("rank", articleRank);

                rowNode1.add(locNode);

                timeNode.set("All_Time", rowNode1);

            }

            if (timePeriod.equals("This_Year")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("article_title", articletitle);
                locNode.put("readers_count", readersCnt);
                locNode.put("rank", articleRank);

                rowNode2.add(locNode);

                timeNode.set(timePeriod, rowNode2);

            }

            if (timePeriod.equals("This_Month")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("article_title", articletitle);
                locNode.put("readers_count", readersCnt);
                locNode.put("rank", articleRank);

                rowNode3.add(locNode);

                timeNode.set(timePeriod, rowNode3);

            }

        }

        ReadMetrics.set(name, timeNode);

    }

    static private String getResourceString(String pName) {
        // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
        // all available resource files.
        InputStream isResource = String.class.getResourceAsStream(pName);
        if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
        else throw new RuntimeException("Could not find resource '" + pName + "'");
    }
}
