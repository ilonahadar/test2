package com.elsevier.epic;

import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.utility.SDJournals;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Map;

public class JournalFamilies implements DataFeed {
    private final JsonNodeFactory jsFactory = new JsonNodeFactory(false);
    private ObjectNode jsFamiliesList = null;
    private SDJournals sdJournals;

    public JournalFamilies() {
        sdJournals = SDJournals.getInstance();
    }

    public JournalFamilies(SDJournals sdJournals) {
        this.sdJournals = sdJournals;
    }

    private ObjectNode getJournalFamilies() {

        if (jsFamiliesList != null) {
            return jsFamiliesList;
        }

        jsFamiliesList = jsFactory.objectNode();
        final ArrayNode journalFamilies = jsFamiliesList.putArray("journal_families");

        for (String journalFamily : sdJournals.allJournalFamilies()) {
            journalFamilies.add(journalFamily);
        }

        return jsFamiliesList;
    }

    @Override
    public Response query(
            final HttpServletRequest pRequest,
            final ArrayList<IDValue> ids,
            final Map<String, String> parameters) {
        return Response.ok(getJournalFamilies()).build();
    }
}
