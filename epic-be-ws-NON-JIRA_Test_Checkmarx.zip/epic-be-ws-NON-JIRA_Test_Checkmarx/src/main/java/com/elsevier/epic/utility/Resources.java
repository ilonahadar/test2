/**
 * Generic functions for processing some of the <resource> tags in the schema
 */

package com.elsevier.epic.utility;

import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.types.PostProcess;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.jaxb.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Resources {
   /**
    * Process and validate query parameters.
    *
    * @param pResource  The resource that matched the URI request.
    * @param pRequest
    * @return
    */

   public static Map<String, String> extractParameters(ResourceType pResource, HttpServletRequest pRequest) {
      Map<String, String> resultMap = new HashMap<>();
      ParametersType params = pResource.getParameters();
      if (params == null) return resultMap; // Return an empty map if there aren't any parameters for this interface.

      List<ParamType> plist = params.getParam();

      // Set any parameter defaults specified in the data schema.
      for (ParamType p : plist) {
         String def = p.getDef();
         if (def != null) resultMap.put(p.getName().toLowerCase(), def);
      }

      Map<String, String[]> parameterMap = pRequest.getParameterMap();
      for (Map.Entry<String, String[]> entry : parameterMap.entrySet()) {
         String pName = entry.getKey().toLowerCase();
         String[] pvalues = entry.getValue();
         boolean foundParameter = false;

         for (ParamType p : plist) {
            if (p.getName().toLowerCase().equals(pName)) {
               foundParameter = true;
               checkParameterType(p, pvalues[0]);
               resultMap.put(pName, pvalues[0]);
               break;
            }
         }

         if (!foundParameter) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
               .setMessage("Parameter '" + pName + "' is unrecognised.")
               .build());
         }
      }

      return resultMap;
   }

   // Check if the value assigned to a parameter is of the correct type.

   private static void checkParameterType(ParamType pType, String pValue) {
      switch (pType.getType()) {
         case "INTEGER":
            try {
               Integer.parseInt(pValue);
            }
            catch (NumberFormatException ex) {
               throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
                  .setMessage("Parameter '" + pType.getName() + "' is not in the required format for an integer value.")
                  .build());
            }
            break;

         case "HEX":
            int i = 0;
            if (pValue.startsWith("0x")) i = 2;
            while (i < pValue.length()) {
               char ch = pValue.charAt(i++);
               if (((ch >= '0') && (ch <= '9')) ||
                   ((ch >= 'a') && (ch <= 'z')) ||
                   ((ch >= 'A') && (ch <= 'Z'))) continue;
               throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
                  .setMessage("Parameter '" + pType.getName() + "' is not in the required format for a hex value.")
                  .build());
            }
            break;

         case "BOOL":
            if ((!"true".equals(pValue)) && (!"false".equals(pValue))) {
               throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
                  .setMessage("Parameter '" + pType.getName() + "' is not in the required format for a boolean value.")
                  .build());
            }
            break;

         case "STRING": // No need to validate strings
            break;

         default:
            throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
               .setMessage("Incorrect internal schema definition, unrecognised type '" + pType.getType() + "'")
               .build());
      }
   }

   /**
    * Extract the identifier values from the resource path so that we can use them in the SQL.  Note that it is a
    * requirement that the identifiers are listed in the order that they appear in the path.
    *
    * @param pPath The URI that was received from the client.  It contains the ID values to be extracted.
    * @param pResource The web resource that describes the identifiers.
    * @param pPattern The regex pattern that will be used to extract the ID values.
    * @return A list of extracted values is returned.
    */

   public static ArrayList<IDValue> extractIdentifiers(String pPath, ResourceType pResource, Pattern pPattern) {
      // Process resources in the URI path.
      IdentifiersType ids = pResource.getIdentifiers();
      ArrayList<IDValue> idValues = new ArrayList<>();
      if (ids != null) {
         List<IdType> idList = ids.getId();
         Matcher m = pPattern.matcher(pPath);
         int i = 0;
         while (m.find()) {
            for (int g=1; g <= m.groupCount (); g++) {
               IdType id = idList.get(i++);
               String value = m.group(g);
               if (value.contains("%")) {
                  try {
                     value = URLDecoder.decode(value, "UTF-8");
                  }
                  catch (UnsupportedEncodingException ex) {
                     throw new WebApplicationException(ex);
                  }
               }

               String valueCase = id.getCase();
               if (valueCase != null) {
                  switch(valueCase) {
                     case "LOWER": value = value.toLowerCase(); break;
                     case "UPPER": value = value.toUpperCase(); break;
                  }
               }

               String pattern = id.getPattern(); // Optional - regex check on value.
               if (pattern != null) checkParameterValue(id.getName(), pattern, value);

               idValues.add(new IDValue(id, value));
            }
         }

         if (idList.size() != idValues.size()) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
               .setMessage("Expected to extract " + idList.size() + " identifiers from the path, got " + idValues.size())
               .build());
         }
      }
      return idValues;
   }

   private static void checkParameterValue(String name, String regex, String value) {
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(value);
      if (!matcher.matches()) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
            .setMessage("Value for '" + name + "' of '" + value + "' does not match required pattern '" + regex + "'")
            .build());
      }
   }

   /**
    *
    * @param pProcess
    * @param pResponse
    */

   public static void postProcess(PostprocessType pProcess, Response pResponse, ArrayList<IDValue> pPathParams, Map<String, String> pQueryParams) {
      String className = pProcess.getClazz();
      if (className == null) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR).build());
      }

      try {
         Class cl = Class.forName(className); // On-the-fly class resolution...
         Object obj = cl.getConstructor().newInstance();
         if (obj instanceof PostProcess) {
            PostProcess pp = (PostProcess)obj;
            pp.postProcess(pProcess, pResponse, pPathParams, pQueryParams);
         }
      }
      catch (ClassNotFoundException | NoSuchMethodException | InstantiationException | IllegalAccessException |
             IllegalArgumentException | InvocationTargetException ex) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
            .setMessage("Schema error - failed to process PostProcess class " + className)
            .setException(ex)
            .build());
      }
   }
}
