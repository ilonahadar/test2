package com.elsevier.epic.scival.collaboration;

import java.net.URL;

/**
 * Created by greend on 14/04/2016.
 */
public class ScivalCallResponse {
    private URL url;
    public boolean success;
    public String json;
    public Exception exception;

    public static ScivalCallResponse success(String json) {
        return new ScivalCallResponse(null, true, json, null);
    }

    public static ScivalCallResponse failure(URL url, Exception exception) {
        return new ScivalCallResponse(url, false, null, exception);
    }

    public ScivalCallResponse(URL url, boolean success, String json, Exception exception) {
        this.url = url;
        this.success = success;
        this.json = json;
        this.exception = exception;
    }

    public String getDescription() {
        String description = String.format("Call to Scival API '%s'", url.toString());
        if (success) {
            return description + " succeeded :)";
        } else {
            if (exception != null) {
                return description + String.format(" failed with exception %s", exception.getMessage());
            }
            return description + " failed";
        }
    }
}
