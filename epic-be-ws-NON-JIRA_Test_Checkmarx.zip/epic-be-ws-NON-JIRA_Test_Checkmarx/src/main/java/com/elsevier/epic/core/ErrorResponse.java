/**
 * This is a special builder class for returning HTTP errors with a JSON description of what went wrong.
 */

package com.elsevier.epic.core;

import com.elsevier.epic.email.EmailException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.util.Map;

@Produces(MediaType.APPLICATION_JSON)
public class ErrorResponse {
   private static final Logger LOG = Log.getLogger(ErrorResponse.class);

   protected String message = "Internal server error.";
   protected Status statusCode = Status.INTERNAL_SERVER_ERROR;
   protected String path = null;
   protected Map<String, String> parameters = null;
   protected Exception exception = null;
   static final private CacheControl noCache = new CacheControl();

   static {
      noCache.setNoCache(true);
   }

   private ErrorResponse() { }

   static public ErrorResponse status(Status statusCode) {
      ErrorResponse newResponse = new ErrorResponse();
      newResponse.statusCode = statusCode;
      newResponse.message = statusCode.getReasonPhrase();
      return newResponse;
   }

   /**
    * Please use a human readable message that would be suitable for user dialogs.
    *
    * @return
    */

   @JsonProperty
   public String getMessage() {
      return this.message;
   }

   public ErrorResponse setMessage(String message) {
      this.message = message;
      return this;
   }

   /**
    * HTTP status code value.
    *
    * @return
    */

   @JsonProperty
   public int getStatusCode() {
      return this.statusCode.getStatusCode();
   }

   public ErrorResponse setStatusCode(Status statusCode) {
      this.statusCode = statusCode;
      return this;
   }

   /**
    * Provide an exception with the response if the issue is serious (the error will be logged
    * as an exception and may result in the admin receiving an alert).
    *
    * @return
    */

   @JsonIgnore

   public Exception getException() {
      return this.exception;
   }

   public ErrorResponse setException(Exception ex) {
      this.exception = ex;
      return this;
   }

   /**
    * Response builder - call this when the data is configured and the response can be generated.
    *
    * @return
    */

   public Response build() {
      if ((this.exception != null) && (this.statusCode.getStatusCode() >= 500)) {
         LOG.warn("Responding with code " + this.statusCode.getStatusCode() + " '" + message + "'", this.exception);
      }
      else LOG.info("Responding with code " + this.statusCode.getStatusCode() + " '" + message + "'");

      // Report serious problems to the status checker.  NB: If an exception is attached, it will not be considered
      // serious if we can establish that it relates to an HTTP status with a code < 500.

      if (this.exception != null) {
         if (this.exception instanceof WebApplicationException) {
            WebApplicationException ex = (WebApplicationException) this.exception;
            if (ex.getResponse().getStatus() >= 500) {
               StatusHealthCheck.reportServerStatus(ex.getResponse().getStatus(), this.getMessage());
            }
         }
         else StatusHealthCheck.reportException(this.exception);
      }
      else if (this.statusCode.getStatusCode() >= 500) {
         StatusHealthCheck.reportServerStatus(this.statusCode.getStatusCode(), this.getMessage());
      }

      // Email the site administrator if the exception is a 5xx status code.

      if (getStatusCode() >= 500) {
         EmailException.sendErrorResponse(this);
      }

      return Response.status(statusCode)
         .entity(this)
         .type(MediaType.APPLICATION_JSON)
         .cacheControl(noCache)
         .build();
   }
}
