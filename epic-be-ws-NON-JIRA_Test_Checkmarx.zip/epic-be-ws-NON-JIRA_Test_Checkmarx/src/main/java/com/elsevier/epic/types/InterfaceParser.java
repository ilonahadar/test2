
package com.elsevier.epic.types;

import com.elsevier.epic.core.ServerConfig;
import com.elsevier.epic.jaxb.InterfaceType;
import com.elsevier.epic.jaxb.Webservice;

public interface InterfaceParser {
   void parseInterface(ServerConfig pConfig, InterfaceType pInterface, Webservice pServiceXML);
   void refreshInterface(InterfaceType pInterface, Webservice pServiceXML);
}
