/*
This is the support code for /account/{accountID}/top/{count}/article/weekly...
*/

package com.elsevier.epic;

import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.postgres.PostgresClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.elsevier.epic.utility.Utility;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;
import java.util.Scanner;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

public class TopArticles implements DataFeed {
   private static final Logger LOG = Log.getLogger(TopArticles.class);
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

   PreparedStatement getStatement(Connection con) throws SQLException {
      PreparedStatement ps = con.prepareStatement(getResourceString("/select_top_articles_weekly.sql"));
      ps.setQueryTimeout(60);
      return ps;
   }

   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      if (pIDs.size() < 2) throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);

      int accountID = Integer.parseInt(pIDs.get(0).value);
      int count = Integer.parseInt(pIDs.get(1).value);

      String paramYear  = pParameters.get("year");
      String paramWeek  = pParameters.get("week");

      ObjectNode jsRoot = jsFactory.objectNode();

      int year = Utility.readInt(paramYear);
      int week = Utility.readInt(paramWeek);

      int currentYear = Calendar.getInstance().get(Calendar.YEAR);
      year = (year <= 0) ? currentYear : year;

      if (year > currentYear) {
         return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid year parameter " + year).build();
      }

      if (week < 0) {
         return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid week parameter " + week).build();
      }

      //THIS ISN'T CORRECT - NEED YEAR / MONTH FILTERING TO WORK

      try (Connection con = PostgresClient.getConnection();
           PreparedStatement ps = getStatement(con)) {

         ps.setLong(1, accountID);
         ps.setInt(2, count);

         ArrayNode jsList = jsFactory.arrayNode();

         if (!CoreServer.isProduction()) LOG.info(ps.toString());

         try (ResultSet rst = ps.executeQuery()) {
            while (rst.next()) {
               ObjectNode jsEntry = jsFactory.objectNode();

               int col = 1;
               int yearWeek = rst.getInt(col++);
               jsRoot.put("year", yearWeek/100);
               jsRoot.put("week", yearWeek % (yearWeek/100));

               jsEntry.put("pii", rst.getString(col++));
               jsEntry.put("totalUsage", rst.getInt(col++));
               jsEntry.put("sourceTitle", rst.getString(col++));
               jsEntry.put("issn", rst.getString(col++));
               jsEntry.put("publisher", rst.getString(col++));
               String authors = rst.getString(col++);
               if (authors != null) {
                  try {
                     jsEntry.set("authors", (new ObjectMapper()).readTree(authors));
                  }
                  catch (IOException ex) { // Non-fatal, but log the issue so that we have awareness of it.
                     LOG.warn("Article " + jsEntry.get("pii") + " has an invalid author field.");
                  }
               }
               // why not check for existence? i.e. you can have a volume with no issue or an AIP.
               jsEntry.put("title", rst.getString(col++));
               jsEntry.put("pubDate", rst.getString(col++));
               jsEntry.put("doi", rst.getString(col++));
               jsEntry.put("volume", rst.getInt(col++));
               jsEntry.put("issue", rst.getInt(col++));
               jsEntry.put("contentType", rst.getString(col++));
               //jsEntry.put("docType", rst.getString(col++));

               jsList.add(jsEntry);
            }
         }

         jsRoot.put("total", jsList.size());
         jsRoot.set("results", jsList);
      }
      catch (SQLException ex) {
         LOG.warn(ex);
         return ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
            .setMessage("A server database failure has occurred.")
            .setException(ex)
            .build();
      }

      return Response.ok(jsRoot).build();
   }

   static private String getResourceString(String pName) {
      // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
      // all available resource files.
      InputStream isResource = String.class.getResourceAsStream(pName);
      if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
      else throw new RuntimeException("Could not find resource '" + pName + "'");
   }
}
