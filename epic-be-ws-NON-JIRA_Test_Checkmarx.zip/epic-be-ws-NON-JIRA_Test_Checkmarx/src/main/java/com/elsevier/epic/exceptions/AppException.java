package com.elsevier.epic.exceptions;

import com.elsevier.epic.email.EmailException;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class AppException extends WebApplicationException {
   private static final Logger LOG = Log.getLogger(AppException.class);

   public String userMsg = null; // A user message can be defined that is suitable for user dialogs.  Otherwise use Exception.msg for dev messages.

   public AppException(String msg){
      super(Response.serverError().entity("{ \"message\":\"" + escJSON(msg) + "\", \"status\":500 }")
         .status(500)
         .type(MediaType.APPLICATION_JSON)
         .build());
      this.userMsg = msg;
      LOG.warn(this.userMsg);
      EmailException.send(super.getCause(), msg);
   }

   public AppException(String msg, Throwable t){
      super(t, Response.serverError().entity("{ \"message\":\"" + escJSON(msg) + "\" }").type(MediaType.APPLICATION_JSON).build());
      this.userMsg = msg;
      LOG.warn(this.userMsg);
      EmailException.send(t, msg);
   }

   public AppException(Throwable t) {
      super(t);
      this.userMsg = t.getMessage();
      LOG.warn(t.getMessage());
      EmailException.send(t, t.getMessage());
   }

   private static String escJSON(String str) {
      str = str.replace("\\","\\\\");
      str = str.replace("\"", "\\\"");
      str = str.replace("\r\n", "\\n");
      str = str.replace("\n", "\\n");
      str = str.replace("\r", "\\n");
      str = str.replace("\t", "\\t");
      return str;
   }
}
