package com.elsevier.epic.mie;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.io.InputStream;
import java.sql.*;
import java.util.*;

public class MieOverview implements DataFeed {

    private static final Logger LOG = Log.getLogger(MieOverview.class);
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe

    PreparedStatement getStatement(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement(getResourceString("/mie_overview.sql"));
        ps.setQueryTimeout(60);
        return ps;
    }

    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
        if (pIDs.size() < 1) throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);

        String paramAccount  = pIDs.get(0).value;

        int accountID;
        try { accountID = Integer.parseInt(paramAccount); }
        catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
                    .setMessage("Invalid ID '" + paramAccount + "'")
                    .setException(ex)
                    .build());
        }

        ObjectNode jsRoot = jsFactory.objectNode();
        ObjectNode jsParams = jsFactory.objectNode();
        jsRoot.set("parameters", jsParams);
        jsParams.put("sisid", paramAccount);

        queryCounter(jsRoot, accountID);
        return Response.ok(jsRoot).build();
    }

    private void queryCounter(ObjectNode pResult, int pSIS) {
        try (Connection con = PostgresClient.getConnection();
             PreparedStatement ps = getStatement(con)) {
            ps.setInt(1, pSIS);
            ps.setInt(2, pSIS);
            ps.setInt(3, pSIS);
            ps.setInt(4, pSIS);
            ps.setInt(5, pSIS);
            ps.setInt(6, pSIS);
            ps.setInt(7, pSIS);
            ps.setInt(8, pSIS);


            if (!CoreServer.isProduction()) LOG.info(ps.toString());

            ObjectNode jsUsage = jsFactory.objectNode();

            ps.execute();

            processMembersTotalCnt(ps, jsUsage, "MieMendeleyUsers");
            ps.getMoreResults();
            processMinMemberLoginMonth(ps, jsUsage, "MembersActiveFrom");
            ps.getMoreResults();
            processMembersRunningCnt(ps, jsUsage, "MieMembers");
            ps.getMoreResults();
            processMembersRunningCnt(ps, jsUsage, "MieGroupsCreated");
            ps.getMoreResults();
            processMembersRunningCnt(ps, jsUsage, "MieGroupsJoined");
            ps.getMoreResults();
            processAcademicDisciplinePresence(ps, jsUsage, "AcademicStatus");
            ps.getMoreResults();
            processAcademicDisciplinePresence(ps, jsUsage, "MemberDomains");
            ps.getMoreResults();
            getSubjectAreaList(ps, jsUsage, "SubjectAreaList");

            pResult.set("result", jsUsage);

        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }
    }

    static private void processMembersTotalCnt(PreparedStatement ps, ObjectNode jsUsage, String name) throws java.sql.SQLException {
        ResultSet rst = ps.getResultSet();
        ResultSetMetaData rsmd = rst.getMetaData();

        int colCount = rsmd.getColumnCount();

        //Note: the order is set in the query...
        while(rst.next()){

            ObjectNode locNode = jsFactory.objectNode();
            for(int ii=1; ii<=colCount; ii++){
                String colName = rsmd.getColumnName(ii);
                int colType = rsmd.getColumnType(ii);
                if (colType == Types.VARCHAR || colType == Types.CHAR || colType == Types.DATE){
                    String result = rst.getString(ii);
                    locNode.put(colName, result);
                } else if( colType == Types.NUMERIC || colType == Types.BIGINT || colType == Types.INTEGER || colType == Types.DOUBLE) {
                    float result = rst.getFloat(ii);
                    locNode.put(colName, result);
                } else {
                    throw new RuntimeException("Could not find type for '" + colName + "'");
                }

            }
            jsUsage.set(name, locNode);
        }
    }

        static private void processMinMemberLoginMonth(PreparedStatement ps, ObjectNode jsUsage, String name) throws java.sql.SQLException {
        ResultSet rst = ps.getResultSet();
        ResultSetMetaData rsmd = rst.getMetaData();

        int colCount = rsmd.getColumnCount();

        //Note: the order is set in the query...
        while(rst.next()){

            ObjectNode locNode = jsFactory.objectNode();
            for(int ii=1; ii<=colCount; ii++){
                String colName = rsmd.getColumnName(ii);
                int colType = rsmd.getColumnType(ii);
                if (colType == Types.VARCHAR || colType == Types.CHAR || colType == Types.DATE){
                    String result = rst.getString(ii);
                    locNode.put(colName, result);
                } else if( colType == Types.NUMERIC || colType == Types.BIGINT || colType == Types.INTEGER || colType == Types.DOUBLE) {
                    float result = rst.getFloat(ii);
                    locNode.put(colName, result);
                } else {
                    throw new RuntimeException("Could not find type for '" + colName + "'");
                }

            }

            jsUsage.set(name, locNode);
        }
    }

    static private void processMembersRunningCnt(PreparedStatement ps, ObjectNode jsUsage, String name) throws java.sql.SQLException {
        ResultSet rst = ps.getResultSet();
        ResultSetMetaData rsmd = rst.getMetaData();

        int colCount = rsmd.getColumnCount();

        ArrayNode currNode = jsFactory.arrayNode();

        //Note: the order is set in the query...
        while(rst.next()){

            ObjectNode locNode = jsFactory.objectNode();
            for(int ii=1; ii<=colCount; ii++){
                String colName = rsmd.getColumnName(ii);
                int colType = rsmd.getColumnType(ii);
                if (colType == Types.VARCHAR || colType == Types.CHAR || colType == Types.DATE){
                    String result = rst.getString(ii);
                    locNode.put(colName, result);
                } else if( colType == Types.NUMERIC || colType == Types.BIGINT || colType == Types.INTEGER || colType == Types.DOUBLE) {
                    float result = rst.getFloat(ii);
                    locNode.put(colName, result);
                } else {
                    throw new RuntimeException("Could not find type for '" + colName + "'");
                }

            }
            currNode.add(locNode);
        }
        jsUsage.set(name, currNode);
    }

    static private void processAcademicDisciplinePresence(PreparedStatement ps, ObjectNode jsUsage, String name) throws java.sql.SQLException {

        ResultSet rst = ps.getResultSet();

        ObjectNode topNode = jsFactory.objectNode();

        HashMap<String, MapParentChildNodes> subjHash = new HashMap<>();

        //Note: the order is set in the query...
        while(rst.next()) {

            String memberRole = rst.getString(1);
            String memberLevel = rst.getString(2);
            //Long count = rst.getLong(3);
            Float percent = rst.getFloat(4);
            //Long count_PreviousLevel = rst.getLong(5);


            if (!subjHash.containsKey(memberRole)) {
                subjHash.put(memberRole, new MapParentChildNodes(memberRole));
            }

            MapParentChildNodes tmpPer = subjHash.get(memberRole);
            tmpPer.addPercent(memberLevel, percent);

            List<MapParentChildNodes> lstOrder = new ArrayList<MapParentChildNodes>(subjHash.values());

            for(MapParentChildNodes sh : lstOrder){

                ObjectNode roleNode = jsFactory.objectNode();

                ArrayNode breakdownNode = jsFactory.arrayNode();

                LinkedHashMap<String, Float> subjects = sh.getPercent();
                for(String subName : subjects.keySet()){

                    roleNode.put("name", sh.getName());
                    roleNode.put("percent", subjects.get("Total"));

                    if(!"Total".equals(subName)) {
                        ObjectNode locNode = jsFactory.objectNode();

                        locNode.put("name", subName);
                        locNode.put("percent", subjects.get(subName));

                        breakdownNode.add(locNode);
                    }

                }

                roleNode.set("breakdown", breakdownNode);

                topNode.set(sh.getName(), roleNode);

            }

        }

        jsUsage.set(name, topNode);
    }

    static private void getSubjectAreaList(PreparedStatement ps, ObjectNode jsUsage, String name) throws java.sql.SQLException {

        ResultSet rst = ps.getResultSet();

        ArrayNode rowNode = jsFactory.arrayNode();

        while(rst.next()){

            String subId = rst.getString(1);
            String subArea = rst.getString(2);

            ObjectNode locNode = jsFactory.objectNode();

                locNode.put("subject_id", subId);
                locNode.put("subject_area", subArea);

            rowNode.add(locNode);

        }

        jsUsage.set(name, rowNode);
    }

    static private String getResourceString(String pName) {
        // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
        // all available resource files.
        InputStream isResource = String.class.getResourceAsStream(pName);
        if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
        else throw new RuntimeException("Could not find resource '" + pName + "'");
    }
}

class MapParentChildNodes {
    private String lname;
    private Float total = 0.0F;
    private LinkedHashMap<String, String> roleLevelMap;
    private LinkedHashMap<String, Float> percent;

    MapParentChildNodes(String name) {
        lname = name;
        percent = new LinkedHashMap<>();
        roleLevelMap = new LinkedHashMap<>();
    }

    public void addPercent(String name, Float value){
        //total += value;
        percent.put(name, value);
    }

    public void addRoleLevelMap(String name, String value){
        //total += value;
        roleLevelMap.put(name, value);
    }

    public Float getTotal(){
        return total;
    }

    public LinkedHashMap<String, Float> getPercent(){
        return percent;
    }

    public LinkedHashMap<String, String> getRoleLevelMap(){
        return roleLevelMap;
    }

    public String getName(){
        return lname;
    }
}
