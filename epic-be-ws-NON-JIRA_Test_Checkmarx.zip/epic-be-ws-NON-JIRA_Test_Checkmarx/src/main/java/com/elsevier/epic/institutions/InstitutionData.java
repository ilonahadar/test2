// Support for v3/account/[inst id]
// Comment to test Checkmarx

package com.elsevier.epic.institutions;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.utility.FileUtils;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.io.IOException;
import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InstitutionData implements DataFeed {
    private static final Logger LOG = Log.getLogger(InstitutionData.class);
    private final PostgresClient postgresClient;
    private final FileUtils fileUtils;

    public InstitutionData() {
        postgresClient = new PostgresClient();
        fileUtils = new FileUtils();
    }

    public InstitutionData(final PostgresClient postgresClient,
                           final FileUtils fileUtils) {
        this.postgresClient = postgresClient;
        this.fileUtils = fileUtils;
    }

    PreparedStatement getStatement(final Connection con) throws SQLException {
        final PreparedStatement ps = con.prepareStatement(fileUtils.getResourceString("/select_account_info.sql"));
        ps.setQueryTimeout(60);
        return ps;
    }

    PreparedStatement getMetricsStatement(final Connection con) throws SQLException {
        final PreparedStatement ps = con.prepareStatement("select  * from checkMetricsDataAvailability(?)");
        ps.setQueryTimeout(60);
        return ps;
    }

    PreparedStatement getAccountDetailInfoStatement(final Connection con) throws SQLException {
        final PreparedStatement ps = con.prepareStatement(fileUtils.getResourceString("/select_account_detail_info.sql"));
        ps.setQueryTimeout(60);
        return ps;
    }

    @Override
    public Response query(final HttpServletRequest pRequest,
                          final ArrayList<IDValue> pIDs,
                          final Map<String, String> pParameters) throws IOException {

        if (pIDs.size() < 1) {
            throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);
        }

        final String paramAccount = pIDs.get(0).value;
        System.out.println("Hello World");
        final int accountID;

        try {
            accountID = Integer.parseInt(paramAccount);
        } catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
                                                           .setMessage("Invalid ID '" + paramAccount + "'")
                                                           .setException(ex)
                                                           .build());
        }

        final InstitutionDataResponse institutionDataResponse = queryInstitutionData(accountID);

        return Response.ok(institutionDataResponse).build();
    }

    private InstitutionDataResponse queryInstitutionData(final int pSIS) {

        final InstitutionDataResponse institutionDataResponse = new InstitutionDataResponse();

        try (Connection con = postgresClient.getConnectionPool();
             final PreparedStatement ps = getStatement(con)) {
            ps.setQueryTimeout(60);
            ps.setInt(1, pSIS);

            if (!CoreServer.isProduction()) {
                LOG.info(ps.toString());
            }

            try (ResultSet rst = ps.executeQuery()) {

                if (rst.next()) {
                    final int svId = rst.getInt(1);

                    if (svId > 0) {
                        institutionDataResponse.setSvId(svId);
                        institutionDataResponse.setSvName(rst.getString(10));
                    }

                    institutionDataResponse.setInstName(rst.getString(2));
                    institutionDataResponse.setSegment(rst.getString(3));
                    institutionDataResponse.setCustomerId(rst.getString(4));
                    institutionDataResponse.setCountry(rst.getString(5));
                    institutionDataResponse.setSuperAccountType(rst.getString(9));
                    institutionDataResponse.setAccountId(buildChildAccountsArray(rst.getArray(6)));
                    institutionDataResponse.setPlatform(buildPlatformsObject(rst.getArray(7)));
                    institutionDataResponse.setAcctIdInfo(getAccountDetailInfoData(pSIS));

                    final HashMap<String, String> affiliationsInfo = (HashMap<String, String>) rst.getObject("affils");

                    if (affiliationsInfo != null) {
                        final List<Map<String, String>> affiliations = new ArrayList<>();

                        for (Map.Entry<String, String> entry : affiliationsInfo.entrySet()) {
                            final Map<String, String> affiliationObject = new HashMap<>();
                            affiliationObject.put("id", entry.getKey());
                            affiliationObject.put("name", entry.getValue());
                            affiliations.add(affiliationObject);
                        }
                        institutionDataResponse.setAffiliations(affiliations);
                    }
                } else if (!rst.isBeforeFirst() && rst.getRow() == 0) {
                    throw new WebApplicationException(ErrorResponse.status(Status.NOT_FOUND)
                                                                   .setMessage("No data found for the id passed")
                                                                   .build());
                }
            } catch (SQLException ex) {
                LOG.warn(ex);
                throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                                                               .setMessage("A server database failure has occurred.")
                                                               .setException(ex)
                                                               .build());
            }
        } catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                                                           .setMessage("A server database failure has occurred.")
                                                           .setException(ex)
                                                           .build());
        }

        institutionDataResponse.setMetricDataAvailable(getMetricsData(pSIS));

        return institutionDataResponse;
    }

    private List<Integer> buildChildAccountsArray(final Array accounts) throws SQLException {

        final Integer[] acctArray = (Integer[]) accounts.getArray();

        return new ArrayList<>(Arrays.asList(acctArray));
    }

    private List<String> buildPlatformsObject(final Array platforms) throws SQLException {

        final String[] platformArray = (String[]) platforms.getArray();

        return new ArrayList<>(Arrays.asList(platformArray));
    }

    private List<Map<String, String>> getMetricsData(final int accountID) {

        String remoteAccessDate = "NULL";
        String bookTurnawayDate = "NULL";
        String elsevierApiUsageDate = "NULL";
        String sdUsageBreakdownDate = "NULL";
        String journalDemandDate = "NULL";
        String journalTurnawaysDate = "NULL";
        String scopusUsageDate = "NULL";
        String mendeleyDataDate = "NULL";
        String engineeringVillageDate = "NULL";
        String elsevierApiUsageSdDate = "NULL";
        String elsevierApiUsageScDate = "NULL";

        try (Connection con = postgresClient.getConnectionPool();
             final PreparedStatement ps = getMetricsStatement(con)) {

            ps.setQueryTimeout(60);
            ps.setInt(1, accountID);
            if (!CoreServer.isProduction()) {
                LOG.info(ps.toString());
            }

            try (ResultSet rst = ps.executeQuery()) {
                if (rst.next()) {
                    remoteAccessDate = rst.getString(1);
                    bookTurnawayDate = rst.getString(2);
                    elsevierApiUsageDate = rst.getString(3);
                    sdUsageBreakdownDate = rst.getString(4);
                    journalDemandDate = rst.getString(5);
                    journalTurnawaysDate = rst.getString(6);
                    scopusUsageDate = rst.getString(7);
                    mendeleyDataDate = rst.getString(8);
                    engineeringVillageDate = rst.getString(9);
                    elsevierApiUsageSdDate = rst.getString(10);
                    elsevierApiUsageScDate = rst.getString(11);
                }
            } catch (SQLException ex) {
                LOG.warn(ex);
                throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                                                               .setMessage("A server database failure has occurred.")
                                                               .setException(ex)
                                                               .build());
            }

        } catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                                                           .setMessage("A server database failure has occurred.")
                                                           .setException(ex)
                                                           .build());
        }
        final List<Map<String, String>> metricsCheckNode = new ArrayList<>();

        if (!isDateNull(remoteAccessDate) || !isDateNull(bookTurnawayDate)) {

            if (!isDateNull(remoteAccessDate)) {
                metricsCheckNode.add(buildMetricDataAvailableObjectNode(remoteAccessDate, "RemoteAccess"));
            }

            if (!isDateNull(bookTurnawayDate)) {
                metricsCheckNode.add(buildMetricDataAvailableObjectNode(bookTurnawayDate, "BookTurnaways"));
            }

            if (!isDateNull(elsevierApiUsageDate)) {
                metricsCheckNode.add(buildMetricDataAvailableObjectNode(elsevierApiUsageDate, "ElsevierApiUsage"));
            }

            if (!isDateNull(sdUsageBreakdownDate)) {
                metricsCheckNode.add(buildMetricDataAvailableObjectNode(sdUsageBreakdownDate, "SDUsageBreakdown"));
            }

            if (!isDateNull(journalDemandDate)) {
                metricsCheckNode.add(buildMetricDataAvailableObjectNode(journalDemandDate, "JournalDemand"));
            }

            if (!isDateNull(journalTurnawaysDate)) {
                metricsCheckNode.add(buildMetricDataAvailableObjectNode(journalTurnawaysDate, "JournalTurnaways"));
            }

            if (!isDateNull(scopusUsageDate)) {
                metricsCheckNode.add(buildMetricDataAvailableObjectNode(scopusUsageDate, "ScopusUsage"));
            }

            if (!isDateNull(mendeleyDataDate)) {
                metricsCheckNode.add(buildMetricDataAvailableObjectNode(mendeleyDataDate, "MendeleyData"));
            }

            if (!isDateNull(engineeringVillageDate)) {
                metricsCheckNode.add(buildMetricDataAvailableObjectNode(engineeringVillageDate, "EngineeringVillageData"));
            }

            if (!isDateNull(elsevierApiUsageSdDate)) {
                metricsCheckNode.add(buildMetricDataAvailableObjectNode(elsevierApiUsageSdDate, "ElsevierApiUsageSD"));
            }

            if (!isDateNull(elsevierApiUsageScDate)) {
                metricsCheckNode.add(buildMetricDataAvailableObjectNode(elsevierApiUsageScDate, "ElsevierApiUsageSC"));
            }
        }

        return metricsCheckNode;
    }

    private boolean isDateNull(final String date) {
        return date.equals("NULL");
    }

    private Map<String, String> buildMetricDataAvailableObjectNode(final String contentDate,
                                                                   final String name) {

        final Map<String, String> metricDataObject = new HashMap<>();

        metricDataObject.put("name", name);
        metricDataObject.put("contentDate", contentDate);

        return metricDataObject;
    }

    private List<Map<String, Object>> getAccountDetailInfoData(final Integer pSIS) {

        try (Connection con = postgresClient.getConnectionPool();
             final PreparedStatement ps = getAccountDetailInfoStatement(con)) {

            ps.setQueryTimeout(60);
            ps.setInt(1, pSIS);

            if (!CoreServer.isProduction()) {
                LOG.info(ps.toString());
            }

            final List<Map<String, Object>> accountIdInfo = new ArrayList<>();

            try (ResultSet rst = ps.executeQuery()) {
                while (rst.next()) {
                    final Map<String, Object> accountInfoObject = new HashMap<>();

                    accountInfoObject.put("acct_number", rst.getInt(1));

                    accountInfoObject.put("acct_name", rst.getString(2));

                    accountInfoObject.put("acct_platforms", buildPlatformsObject(rst.getArray(3)));

                    accountIdInfo.add(accountInfoObject);
                }

                return accountIdInfo;

            } catch (SQLException ex) {
                LOG.warn(ex);
                throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                                                               .setMessage("A server database failure has occurred.")
                                                               .setException(ex)
                                                               .build());
            }
        } catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                                                           .setMessage("A server database failure has occurred.")
                                                           .setException(ex)
                                                           .build());
        }
    }
}
