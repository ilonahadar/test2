package com.elsevier.epic.scival.collaboration;

import java.sql.SQLException;

/**
 * Resolves a country name from an ISO Number
 */
public interface CountryNameLookup {
    String getCountryName(int countryISONum) throws UnknownCountryException;
}
