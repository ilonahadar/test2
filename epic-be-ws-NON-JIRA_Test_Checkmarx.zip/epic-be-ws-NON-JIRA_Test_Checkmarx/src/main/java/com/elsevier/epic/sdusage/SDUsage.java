/*
This is the support code for /account/{accountID}/sd/usage/?/...
*/

package com.elsevier.epic.sdusage;

import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.postgres.PostgresClient;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.elsevier.epic.utility.Utility;
import java.io.InputStream;
import java.sql.*;
import java.util.*;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

public class SDUsage implements DataFeed {
   private static final Logger LOG = Log.getLogger(SDUsage.class);
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe
   private static final String[] payment_model = {"Package", "Purchased", "OpenAccess", "Author"};
   private static final String[] access = {"ScienceDirect.com", "Journal's Website","Journal's Mobile App"};
   private static final String[] books  = {"E-Books", "Series", "Reference Works", "Handbooks"};
   private static final String[] api   = {"TDM API","Non-TDM API"};

   static final int MIN_YEAR = 2015;

   PreparedStatement getStatement(Connection con) throws SQLException {
      PreparedStatement ps = con.prepareStatement(getResourceString("/sd_usage.sql"));
      ps.setQueryTimeout(60);
      return ps;
   }

   private static class UsageSumYear {
      String usage;
      int year;
      int[] months = new int[12];

      UsageSumYear(String pUsage, int pYear) {
         this.usage = pUsage;
         this.year = pYear;
         for (int i=0; i < months.length; i++) months[i] = 0;
      }

      void setMonth(int pMonth, int pSum) {
         this.months[pMonth-1] = pSum;
      }
   }

    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
        if (pIDs.size() < 1) throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);

        String paramAccount  = pIDs.get(0).value;

        String paramReport;
        paramReport = "SUM";

        String paramYearStart  = pParameters.get("yearstart");
        String paramYearEnd    = pParameters.get("yearend");
        int accountID;
        try { accountID = Integer.parseInt(paramAccount); }
        catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
                    .setMessage("Invalid ID '" + paramAccount + "'")
                    .setException(ex)
                    .build());
        }

        ObjectNode jsRoot = jsFactory.objectNode();

        int ys = Utility.readInt(paramYearStart);
        final int yearEnd;
        int y = Utility.readInt(paramYearEnd);

        Calendar cal = Calendar.getInstance();
        int currentYear = cal.get(Calendar.YEAR);
        yearEnd = (y <= 0) ? currentYear : y;

        if (ys > currentYear) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid year parameter " + ys).build();
        }

        if ((ys < 0) || (ys > yearEnd)) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid year parameters " + ys + " to " + yearEnd).build();
        }

        final int yearStart = (ys < MIN_YEAR) ? MIN_YEAR : ys;

        queryCounter(jsRoot, accountID, yearStart, yearEnd);
        return Response.ok(jsRoot).build();
    }
    private void queryCounter(ObjectNode pResult, int pSIS, int pYearStart, int pYearEnd) {
        try (Connection con = PostgresClient.getConnection();
             PreparedStatement ps = getStatement(con)) {
            ps.setQueryTimeout(60);
            ps.setInt(1, pSIS);
            ps.setInt(2, pYearStart);
            ps.setInt(3, pYearEnd);

            if (!CoreServer.isProduction()) LOG.info(ps.toString());
            ps.execute();

            String[] empty = {};
            SDBreakdown sdTot = new SDBreakdown("TotalUsage", empty );
            SDBreakdown sdJ = new SDBreakdown("Journal", empty );
            SDBreakdown sdPM = new SDBreakdown("Payment Model", payment_model);
            SDBreakdown sdAccess = new SDBreakdown("Access", access);
            SDBreakdown sdBooks = new SDBreakdown("Books",books);
            SDBreakdown sdAPI = new SDBreakdown("API", api);

            Map<String, SDBreakdown> jsMap = new HashMap<String, SDBreakdown>();
            jsMap.put("PaymentModel", sdPM);
            jsMap.put("Access", sdAccess);
            jsMap.put("Books", sdBooks);
            jsMap.put("API", sdAPI);

            processUsageResultSet(ps, jsMap);

            sdJ.setTotal(sdAccess.getTotal());
            sdJ.addObjectNode(sdPM.getName(), sdPM.getNodeObject());
            sdJ.addObjectNode(sdAccess.getName() ,sdAccess.getNodeObject());

            sdTot.addToTotal(sdJ.getTotal());
            sdTot.addToTotal(sdBooks.getTotal());
            sdTot.addToTotal(sdAPI.getTotal());

            pResult.set("TotalUsage", sdTot.getNodeObject());
            pResult.set("Journal", sdJ.getNodeObject());
            pResult.set("Book", sdBooks.getNodeObject());
            pResult.set("API", sdAPI.getNodeObject());
        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }
    }

    static private void processUsageResultSet(PreparedStatement ps, Map<String, SDBreakdown> jsMap) throws java.sql.SQLException{
        ResultSet rst = ps.getResultSet();
        ResultSetMetaData rsmd = rst.getMetaData();
        int columnCount = rsmd.getColumnCount();

        /*
            access_node_id	category	year	month	fta_count
            1,898	Author	2,011	{1,2,3,4,5,6,7,8,9,10,11,12}	{291,218,279,347,294,350,339,249,363,287,249,208}
         */

        while (rst.next()) {
            String category = rst.getString("category");
            int year = rst.getInt("year");
            for(String key : jsMap.keySet()){
                if (jsMap.get(key).contains(category)){
                    Long[] fta_count = (Long[]) rst.getArray("fta_count").getArray();
                    SDBreakdown locSD = jsMap.get(key);
                    locSD.addToTotal(year, fta_count);
                    locSD.addToYears(category, year, fta_count);
                }
            }
        }
    }

    static private String getResourceString(String pName) {
        // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
        // all available resource files.
        InputStream isResource = String.class.getResourceAsStream(pName);
        if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
        else throw new RuntimeException("Could not find resource '" + pName + "'");
    }
}
