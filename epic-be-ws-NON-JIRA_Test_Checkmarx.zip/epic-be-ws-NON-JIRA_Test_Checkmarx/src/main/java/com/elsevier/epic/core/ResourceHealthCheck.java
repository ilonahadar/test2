/*

This health checker is for testing the current state of resource usage, e.g. CPU, memory, storage...

*/

package com.elsevier.epic.core;

import com.codahale.metrics.health.HealthCheck;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryUsage;
import java.util.List;

public class ResourceHealthCheck extends HealthCheck {
   private static final Logger LOG = Log.getLogger(ResourceHealthCheck.class);
   private static MemoryPoolMXBean permgenBean = null;
   private static boolean permgenSearched = false;

   static private MemoryPoolMXBean getPermgen() {
      if (permgenSearched == false) {
         permgenSearched = true;
         List<MemoryPoolMXBean> beans = ManagementFactory.getMemoryPoolMXBeans();
         for (MemoryPoolMXBean bean : beans) {
            LOG.debug("Found memory pool '" + bean.getName() + "'");
            if (bean.getName().toLowerCase().contains("perm gen")) {
               permgenBean = bean;
               break;
            }
         }
      }

      return permgenBean;
   }

   @Override
   protected synchronized Result check() throws Exception {
      LOG.info("Checking resource status.");

      // This check is useful pre-JDK8 only.

      MemoryPoolMXBean permgen = getPermgen();
      if (permgen != null) {
         MemoryUsage currentUsage = getPermgen().getUsage();
         int pct = (int)((currentUsage.getUsed() * 100) / currentUsage.getMax());
         if (pct > 90) {
            return Result.unhealthy("Permgen memory usage has reached " + pct + "% and should be expanded beyond " + currentUsage.getMax() + " to prevent downtime.");
         }
      }

      return Result.healthy("No issues with resource usage.");
   }
}
