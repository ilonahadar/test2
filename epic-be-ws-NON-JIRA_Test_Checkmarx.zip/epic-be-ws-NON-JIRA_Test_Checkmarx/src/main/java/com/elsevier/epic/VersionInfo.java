/*
*/

package com.elsevier.epic;

import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;

import com.elsevier.epic.core.ServerConfig;
import com.elsevier.epic.types.InterfaceParser;
import com.elsevier.epic.jaxb.InterfaceType;
import com.elsevier.epic.jaxb.Webservice;


import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

@Path("/api/version")
@Produces({"application/json", "application/xml"})
public class VersionInfo implements InterfaceParser {
   ServerConfig pConfig = null;
   final String path;
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

   public VersionInfo(String path) {
      this.path = path;
   }

   @GET
   @Produces({"application/json"})
   public Response getInfo(@Context HttpServletRequest pRequest) {
     // return "application/json".equals(pRequest.getContentType())?Response.ok(ServiceBuilder.getPublicXML(), "application/json").build():Response.ok(ServiceBuilder.getPublicXML(), "application/xml").build();
      ObjectNode jsRoot = jsFactory.objectNode();

      jsRoot.put("dataEndpoint", pConfig.getPostgresServer());
      jsRoot.put("appVersion", this.getClass().getPackage().getImplementationVersion());
      try {
         jsRoot.put("gitCommit", getGitRepositoryCommitId());
      } catch (IOException e) {
         jsRoot.put("gitCommit", "unknown");
      }

      return Response.ok(jsRoot).build();
   }

   @Override
   public void parseInterface(ServerConfig pConfig, InterfaceType pInterface, Webservice pServiceXML) {
      this.pConfig = pConfig;
   }

    public String getGitRepositoryCommitId() throws IOException {
      String commitId = "Not_supported_by_gradle_build";
      return commitId;
   }


   @Override
   public void refreshInterface(InterfaceType interfaceType, Webservice webservice) {

   }

}
