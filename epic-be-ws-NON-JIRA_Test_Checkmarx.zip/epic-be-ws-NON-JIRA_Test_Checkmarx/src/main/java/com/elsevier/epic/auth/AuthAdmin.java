package com.elsevier.epic.auth;

import com.elsevier.epic.types.IDValue;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;

public class AuthAdmin implements URIAuthorisation {
   @Override
   public void authorise(HttpServletRequest pRequest, ArrayList<IDValue> pIDs) {
      AuthFilter.checkAccessLevel(pRequest, UserCredentials.AL_ADMIN);
   }
}
