/**
 * This class manages the authentication plugins, such as AuthIP, AuthToken and AuthDigest.  You can write your own
 * authentication plugins by extending the AuthClient class.  The entry point for incoming web requests is doFilter().
 */

package com.elsevier.epic.auth;

import com.elsevier.epic.types.InterfaceParser;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ServerConfig;
import com.elsevier.epic.exceptions.AppException;
import com.elsevier.epic.jaxb.InterfaceType;
import com.elsevier.epic.jaxb.OptionType;
import com.elsevier.epic.jaxb.Webservice;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.elsevier.epic.utility.Utility;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.*;

public class AuthFilter implements Filter, InterfaceParser {
   private static final Logger LOG = Log.getLogger(AuthFilter.class);
   private static boolean initialised = false;
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);
   private static final ArrayList<AuthClient> authClients = new ArrayList<>(); // Read-only following initialisation.

   final public static int AUTH_CONTINUE = 1;
   final public static int AUTH_ACCEPTED = 2;
   final public static int AUTH_RESPONDED = 3;

   /**
    * Throws an appropriate WebApplicationException if the user session does not meet the access level
    * requirement.
    *
    * @param pRequest
    * @param pAccessLevel
    */

   static public void checkAccessLevel(HttpServletRequest pRequest, int pAccessLevel) {
      Map<String, Object> tokenMap = (Map<String, Object>)pRequest.getAttribute("tokenMap");
      if (tokenMap == null) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.FORBIDDEN)
            .setMessage("This interface requires a valid user session.")
            .build());
      }

      Integer accessLevel = (Integer)tokenMap.get("al");
      if ((accessLevel == null) || (accessLevel != pAccessLevel)) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.FORBIDDEN)
            .setMessage("Logged in user does not have permission to access this interface.")
            .build());
      }
   }

   public AuthFilter(String path) throws InstantiationException {
      if (initialised) throw new InstantiationException(); // Enforce singleton pattern
      initialised = true;
   }

   /**
    * Check that the incoming client request passes authorisation restrictions.  NB: To turn off authentication or
    * authorisation, remove the AuthFilter class from the data schema file.
    *
    * @param request
    * @param response
    * @param chain
    * @throws IOException
    * @throws ServletException
    */

   @Override
   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
      HttpServletRequest httpRequest = (HttpServletRequest)request;

      // Requests for OPTIONS are not subject to authorization because the browser will pre-flight calls prior
      // to sending the Authorization token through.

      if ("OPTIONS".equals(httpRequest.getMethod())) {
         chain.doFilter(request, response);
         return;
      }

      // Incoming headers can be printed to the log by setting X-Debug.  This feature is not publicised and is only
      // used in circumstances where we might want to confirm the headers that are being received by the server.

      if (httpRequest.getHeader("X-Debug") != null) {
         LOG.info("--- Received HTTP headers ---");
         Enumeration<String> headerNames = httpRequest.getHeaderNames();
         while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            String headerValue = ((HttpServletRequest)request).getHeader(headerName);
            LOG.info(headerName + ": " + headerValue);
         }
         LOG.info("--- Headers end ---");
      }

      final String authHeader = httpRequest.getHeader(HttpHeaders.AUTHORIZATION);

      for (AuthClient ac : authClients) {
         int authResult = ac.authenticate(((HttpServletResponse)response), httpRequest, authHeader);

         if (authResult == AUTH_ACCEPTED) {
            chain.doFilter(request, response);
            return;
         }
         else if (authResult == AUTH_RESPONDED) {
            return;
         }
      }

      // None of the checks passed, return an unauthorized error.

      StringBuilder msg = new StringBuilder()
         .append("{ \"statusCode\":401,")
         .append(" \"message\":\"Failed to pass authorisation checks.  ")
         .append((authHeader != null) ? ("Received: " + Utility.escJSON(authHeader)) : "No Authorization header in client request.")
         .append("\" }");

      HttpServletResponse hr = (HttpServletResponse)response;
      hr.setContentType("application/json");
      hr.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
      hr.setContentLength(msg.length());
      hr.getWriter().print(msg);
   }

   synchronized static public void addAuthClient(ServerConfig pConfig, AuthClient pClient) {
      pClient.init(pConfig);
      authClients.add(pClient);
   }

   // Process authentication plugins.

   @Override
   public void parseInterface(ServerConfig pConfig, InterfaceType Interface, Webservice serviceXML) {
      boolean autoAuth = true;

      // Use of the 'enable' option when configuring the authentication interface will enable manual configuration
      // of authentication classes.  Doing so switches off auto-loading of all classes that extend 'AuthClient'.

      List<OptionType> options = Interface.getOption();
      for (OptionType option : options) {
         if ("enable".equals(option.getName())) {
            autoAuth = false;
            try {
               Class<? extends AuthClient> client = (Class<? extends AuthClient>) Class.forName(option.getValue());
               addAuthClient(pConfig, client.newInstance());
            }
            catch (IllegalAccessException | InstantiationException | ClassNotFoundException ex) {
               throw new AppException("Unable to find requested class '" + option.getValue() + "'", ex);
            }
         }
      }

      // This routine will initialise all classes that extend AuthClient.  It will not run if the user has
      // configured at least one AuthClient manually.

      if (autoAuth) {
         Set<Class<? extends AuthClient>> acList = CoreServer.reflections.getSubTypesOf(AuthClient.class);
         for (Class<? extends AuthClient> client : acList) {
            try {
               addAuthClient(pConfig, client.newInstance());
            }
            catch (InstantiationException | IllegalAccessException ex) {
               throw new AppException("Failed to instantiate data source '" + client.getName() + "'", ex);
            }
         }
      }
   }

   @Override
   public void init(FilterConfig filterConfig) throws ServletException { }

   @Override
   public void destroy() { }

   @Override
   public void refreshInterface(InterfaceType pInterface, Webservice pServiceXML) { }
}
