/*

The service builder loads an XML service configuration file and converts it into Java data classes with the help of JAXB.

The JAXB classes are located under com.elsevier.epic.jaxb and are automatically generated.  You can regenerate
these classes (which must be done if the XSD is changed) using the following command from the project folder:

   xjc -d src/main/java -p com.elsevier.epic.jaxb src/main/resources/service-config.xsd

After parsing the service configuration file, the web service itself is built (it resolves URI's
to the classes that provision them).

*/

package com.elsevier.epic.core;

import com.elsevier.epic.types.InterfaceParser;
import com.elsevier.epic.exceptions.AppException;
import com.elsevier.epic.jaxb.*;
import io.dropwizard.setup.Environment;
import org.eclipse.jetty.servlet.FilterHolder;
import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.DispatcherType;
import javax.servlet.FilterRegistration.Dynamic;
import javax.xml.XMLConstants;
import javax.xml.bind.*;
import javax.xml.bind.util.ValidationEventCollector;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class ServiceBuilder {
   private static final Logger LOG = Log.getLogger(ServiceBuilder.class);

   private static Webservice serviceXML = null; // This is an unmodified copy of the web service XML configuration.
   private static Webservice publicXML = null; // This is a sanitised web service definition for the /api interface.
   private static final ArrayList<Object> webResources = new ArrayList(); // List of all registered objects providing web resources
   private static InputStream xsdStream = null;
   private static Schema xsd = null;

   public static AtomicBoolean outputNulls = new AtomicBoolean(true);
   public static AtomicReference<String> dateFormat = new AtomicReference<>("yyyy-mm-dd hh:nn");
   public static AtomicReference<StringStyle> keyStyle = new AtomicReference<>(new StringStyle("lowCamelCase"));
   public static AtomicInteger recordLimit = new AtomicInteger(1000);
   public static final String xsdLocation = "/service-config.xsd"; // Should be stored in src/main/resources
   public static final String xmlLocation = "/schema.xml";
   public static InputStream xmlStream = null; // Location of the service configuration file.

   public static void buildService(ServerConfig pConfig, Environment pEnv) throws AppException {
      LOG.info("ServiceBuilder loading XSD source file from \"" + xsdLocation);

      xsdStream = ServiceBuilder.class.getResourceAsStream(xsdLocation);
      if (xsdStream == null) throw new AppException("Failed to load XSD resource " + xsdLocation);
      xsd = loadSchema(xsdStream);

      Webservice newServiceXML = parseServiceXML(xsd, getServiceStream(pConfig)); // Load the XML and validate it against the XSD.
      Webservice newPublicXML = parseServiceXML(null, getServiceStream(pConfig));

      preparePublicXML(newPublicXML);

      LOG.info("Loaded web service \"" + newServiceXML.getName() + "\" with URI base path \"" + newServiceXML.getBasepath() + "\"");

      pEnv.getApplicationContext().setContextPath(newServiceXML.getBasepath());
      //pEnv.getAdminContext().setContextPath("/admin");

      parseFormats(pEnv, newServiceXML);
      registerServices(pConfig, pEnv, newServiceXML);

      ServiceBuilder.serviceXML = newServiceXML;
      ServiceBuilder.publicXML = newPublicXML;
   }

   public static Webservice getServiceXML() {
      return ServiceBuilder.serviceXML;
   }

   public static Webservice getPublicXML() {
      return ServiceBuilder.publicXML;
   }

   public static String getDateFormat() {
      return ServiceBuilder.dateFormat.get();
   }

   public static StringStyle getKeyStyle() {
      return ServiceBuilder.keyStyle.get();
   }

   /**
    * Refreshing causes the XML schema to be reloaded.  Please note that the services cannot be restarted by
    * this function, so the extent of its usefulness is limited to simple updates to the live environment.
    *
    * @throws IOException
    */

   synchronized static public void refreshConfiguration() throws IOException {
      LOG.info("Refreshing service configuration");

      Webservice newServiceXML = parseServiceXML(xsd, xmlStream); // Load the XML and validate it against the XSD.
      Webservice newPublicXML = parseServiceXML(null, xmlStream);

      preparePublicXML(newPublicXML);

      // Call refreshInterface() for any resource service that supports InterfaceParser.

      for (InterfaceType in : newServiceXML.getInterface()) {
         try {
            Class cl = Class.forName(in.getClazz()); // On-the-fly class resolution...
            for (Object resource : webResources) {
               if ((resource.getClass().equals(cl)) && (resource instanceof InterfaceParser)) {
                  ((InterfaceParser)resource).refreshInterface(in, newServiceXML);
               }
            }
         }
         catch (ClassNotFoundException ex) {
            throw new AppException("Unable to find requested class '" + in.getClazz() + "'", ex);
         }
      }

      ServiceBuilder.serviceXML = newServiceXML;
      ServiceBuilder.publicXML = newPublicXML;
   }


   /**
    * Get the current schema definition, from either the serviceFile absolute definition
    * if defined in the config.yml dropwizard config, or locate on the classpath if
    * not present
    *
    * @param pSchema
    * @return
    * @throws AppException
    */

   static private InputStream getServiceStream(ServerConfig pConfig) {
      InputStream configStream;
      try {
         if (pConfig.getServiceFile() != null) {
            configStream = new FileInputStream(pConfig.getServiceFile());
            if (configStream == null) throw new AppException("Failed to load XML file " + pConfig.getServiceFile());
         } else {
            configStream = ServiceBuilder.class.getResourceAsStream(xmlLocation);
            if (configStream == null) throw new AppException("Failed to load XML resource " + xmlLocation);
         }
         return configStream;
      } catch (FileNotFoundException ex) {
         throw new AppException(ex);
      }
   }

   /**
    *
    * @param pSchema
    * @param pXmlFile
    * @return
    * @throws AppException
    */

   static private Webservice parseServiceXML(Schema pSchema, InputStream pXmlStream) throws AppException {
      ValidationEventCollector vec = null;
      try {
         JAXBContext jc = JAXBContext.newInstance("com.elsevier.epic.jaxb");
         Unmarshaller u = jc.createUnmarshaller();
         if (pSchema != null) {
            u.setSchema(pSchema);
            vec = new ValidationEventCollector();
            u.setEventHandler(vec);
         }

         return (Webservice)u.unmarshal(pXmlStream);
      }
      catch (JAXBException ex) {
         // Inform the user if the XML source file failed XSD validation checks.
         printXSDFailure(vec, ex);
         throw new AppException(ex);
      }
   }

   static private Schema loadSchema(InputStream pSchema) throws AppException {
      if (pSchema == null) return null;

      SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
      try {
         return sf.newSchema(new StreamSource(pSchema));
      }
      catch (org.xml.sax.SAXException ex) {
         throw new AppException(ex);
      }
   }

   /**
    * Print helpful messages when XML files fail to pass their XSD validation check.
    *
    * @param pVEC
    * @param pException
    */

   static public void printXSDFailure(ValidationEventCollector pVEC, Exception pException) {
      if ((pVEC != null) && (pVEC.hasEvents())) {
         for (ValidationEvent ve: pVEC.getEvents()) {
            ValidationEventLocator vel = ve.getLocator();
            LOG.warn(vel.getLineNumber() + "." + vel.getColumnNumber() + ": " + ve.getMessage());
         }
      }
      else LOG.warn(pException.getMessage());
   }

   private static void parseFormats(Environment pEnv, Webservice pRoot) throws AppException {
      OptionsType formats = pRoot.getOptions();
      for (OptionType fmt : formats.getOption()) {
         String value = fmt.getValue();
         if ((value != null) && (!value.isEmpty())) {
            switch (fmt.getName()) {
               case "DEFAULT_COUNTRY": StringStyle.countryStyle.set(Integer.parseInt(value)); break;
               case "DEFAULT_DATE":    dateFormat.set(value); break;
               case "OUTPUT_STYLE":    keyStyle.set(new StringStyle(value)); break;
               case "OUTPUT_NULLS":    outputNulls.set(Boolean.parseBoolean(value)); break;
               case "RECORD_LIMIT":    recordLimit.set(Integer.parseInt(value)); break;
               default: throw new RuntimeException("Unrecognised format parameter '" + fmt.getName() + "'");
            }
         }
      }
   }

   static private class ClassPathHack {
      private static final Class[] parameters = new Class[] { URL.class };

      public static void addFile(String s) throws IOException
      {
        File f = new File(s);
        addFile(f);
      }

      public static void addFile(File f) throws IOException
      {
         addURL(f.toURI().toURL());
      }

      public static void addURL(URL u) throws IOException
      {
         URLClassLoader sysloader = (URLClassLoader) ClassLoader.getSystemClassLoader();
         Class sysclass = URLClassLoader.class;

         try {
            Method method = sysclass.getDeclaredMethod("addURL", parameters);
            method.setAccessible(true);
            method.invoke(sysloader, new Object[] {u});
         }
         catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException t) {
            t.printStackTrace();
            throw new IOException("Error, could not add URL to system classloader");
         }
      }
   }

   /**
    * For every root-level resource under <webservice>, generate the associated class and pass it XML for
    * further configuration (if it implements InterfaceParser).  Note that any classes generated by this function
    * should be located in the com.elsevier.ws package.
    *
    * @param pEnv
    * @param pRoot
    * @throws AppException
    */

   private static void registerServices(ServerConfig pConfig, Environment pEnv, Webservice pRoot) throws AppException {
      for (InterfaceType in : pRoot.getInterface()) {
         String javaClass = in.getClazz();
         String path = in.getPath();

         try {
            LOG.info("Registering service \"" + path + "\" to class " + javaClass);

            Class cl = Class.forName(javaClass);
            if (cl.equals(CrossOriginFilter.class)) { // CORS needs special attention
               initCORS(pEnv, in);
               continue;
            }
            Object webResource = cl.getConstructor(String.class).newInstance(path);

            // If the web resource supports InterfaceParser, we give it the interface to process.
            // The web resource must throw an AppException if the interface fails validity checks.

            if (webResource instanceof InterfaceParser) {
               ((InterfaceParser)webResource).parseInterface(pConfig, in, pRoot);
            }

            // Register the web resource handler with our web server.

            if (webResource instanceof javax.servlet.Filter) {
               javax.servlet.Filter webFilter = (javax.servlet.Filter)webResource;
               pEnv.getApplicationContext().addFilter(new FilterHolder(webFilter), path, EnumSet.of(DispatcherType.REQUEST));
            }
            else {
               pEnv.jersey().register(webResource);
               webResources.add(webResource);
            }
         }
         catch (ClassNotFoundException ex) {
            throw new AppException("Unable to find requested class '" + javaClass + "'", ex);
         }
         catch (InstantiationException | NoSuchMethodException | IllegalAccessException | InvocationTargetException ex) {
            throw new AppException("Class '" + javaClass + "' failed to initialise for resource " + path, ex);
         }
      }
   }

   //FilterHolder corsFilterHolder = pEnv.getApplicationContext().addFilter(cors, "/*", EnumSet.allOf(DispatcherType.class));
   //pEnv.getApplicationContext().addFilter(new FilterHolder(cors), "/*", EnumSet.allOf(DispatcherType.class));

   private static void initCORS(Environment pEnv, InterfaceType pInterface) {
      Dynamic filter = pEnv.servlets().addFilter("CORS", CrossOriginFilter.class);
      filter.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), true, "/*");

      List<OptionType> options = pInterface.getOption();
      for (OptionType option : options) {
         String name = option.getName();
         String value = option.getValue();
         filter.setInitParameter(name, value);
      }
   }

   /**
    * Eliminate schema values that are internal to Elsevier and shouldn't be exposed in the /api interface.
    */

   static private void preparePublicXML(Webservice pXml) {
      for (InterfaceType iface : pXml.getInterface()) {
         iface.setClazz(null);

         for (OptionType opt : iface.getOption()) {
            opt.setName(null);
            opt.setValue(null);
         }

         for (ResourceType res : iface.getResource()) {
            for (SqlType sql : res.getSql()) {
               sql.setName(null);
               sql.setValue(null);
            }
         }
      }
   }
}
