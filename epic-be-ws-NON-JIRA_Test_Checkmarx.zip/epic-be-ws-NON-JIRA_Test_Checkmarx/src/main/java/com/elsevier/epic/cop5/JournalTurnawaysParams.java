package com.elsevier.epic.cop5;

public class JournalTurnawaysParams {
    private Integer accountId;
    private Integer count;
    private String family;
    private String category;

    JournalTurnawaysParams(Integer accountId, Integer count, String family, String category) {
        this.accountId = accountId;
        this.count = count;
        this.family = family;
        this.category = category;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public Integer getMaxNumberOfJournals() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getFamily() {
        if (family.equals("Others")) {
            family = "";
        } else if (family.equals("CellPress")) {
            family = "Cell Press";
        }
        return family;
    }

    public String getCategory() {
        return category;
    }
}
