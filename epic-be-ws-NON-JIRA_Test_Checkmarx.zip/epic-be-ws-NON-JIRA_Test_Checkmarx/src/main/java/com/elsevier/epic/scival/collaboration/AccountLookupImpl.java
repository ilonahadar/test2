package com.elsevier.epic.scival.collaboration;

import com.elsevier.epic.postgres.PostgresClient;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AccountLookupImpl implements AccountLookup {
    private static final Logger LOG = Log.getLogger(AccountLookupImpl.class);

    @Override
    public int getScivalInstitutionId(int accountID) throws UnknownAccountException {
        String errorMessage = "Could not lookup scival institution id for account id " + accountID;
        try (Connection con = PostgresClient.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT sv_id FROM accounts WHERE sis_hq=?");
            ps.setQueryTimeout(60);

            ps.setInt(1, accountID);
            try (ResultSet rst = ps.executeQuery()) {
                if (rst.next()) {
                    return rst.getInt(1);
                } else {
                    throw new UnknownAccountException(accountID);
                }
            }
        }
        catch (SQLException ex) {
            error(errorMessage, ex);
        }

        throw new UnknownAccountException(accountID);
    }

    private void error(String message) {
        LOG.warn(message);
    }

    private void error(String message, Exception exceptions) {
        LOG.warn(message, exceptions);
        throw new RuntimeException(message, exceptions);

    }

}
