package com.elsevier.epic;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class DataLastUpdated implements DataFeed {

    private static final Logger LOG = Log.getLogger(DataLastUpdated.class);
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe

    PreparedStatement getStatement(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement(getResourceString("/data_last_updated.sql"));
        ps.setQueryTimeout(60);
        return ps;
    }

    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {

        ObjectNode jsRoot = jsFactory.objectNode();

        queryCounter(jsRoot);
        return Response.ok(jsRoot).build();
    }

    private void queryCounter(ObjectNode pResult) {
        try (Connection con = PostgresClient.getConnection();
             PreparedStatement ps = getStatement(con)) {

            if (!CoreServer.isProduction()) LOG.info(ps.toString());

            ObjectNode jsUsage = jsFactory.objectNode();

            ps.execute();

            getDataLastUpdatedTimestamp(ps, jsUsage, "DataLastUpdated");

            pResult.set("result", jsUsage);

        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }
    }

    static private void getDataLastUpdatedTimestamp(PreparedStatement ps, ObjectNode jsUsage, String name) throws java.sql.SQLException {

        ResultSet rst = ps.getResultSet();

        ArrayNode rowNode = jsFactory.arrayNode();

        while(rst.next()){

            String appName = rst.getString(1);
            String lastUpdated = rst.getString(2);

            ObjectNode locNode = jsFactory.objectNode();

                locNode.put("app", appName);
                locNode.put("lastUpdated", lastUpdated);

            rowNode.add(locNode);

        }

        jsUsage.set(name, rowNode);
    }

    static private String getResourceString(String pName) {
        // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
        // all available resource files.
        InputStream isResource = String.class.getResourceAsStream(pName);
        if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
        else throw new RuntimeException("Could not find resource '" + pName + "'");
    }
}
