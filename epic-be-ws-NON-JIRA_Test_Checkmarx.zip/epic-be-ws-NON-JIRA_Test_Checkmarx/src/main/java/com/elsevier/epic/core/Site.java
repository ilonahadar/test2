/**
 * The /site interface serves files from the 'site' folder.  Use the RewriteFilter if you need to change the path that
 * will be used to access the files.
 */

package com.elsevier.epic.core;

import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

@Path("/site/{remainder:.+}")
public class Site {
   private static final Logger LOG = Log.getLogger(Site.class);
   final String path;

   public Site(String path) {
      this.path = path;
   }

   @Context
   UriInfo uriInfo;

   @GET
   public Response getFile(@Context HttpServletRequest pRequest,
                           @PathParam("remainder") String pRemainder) {
      InputStream isFile;

      try {
         File file = new File(CoreServer.config.getSiteFolder() + pRemainder);
         isFile = new FileInputStream(file);
      }
      catch (FileNotFoundException ex) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.NOT_FOUND)
            .setMessage("The requested file is not available.")
            .build());
      }

      int dot = pRemainder.lastIndexOf(".");
      String type = null;
      if (dot != -1) {
         switch (pRemainder.substring(dot+1)) {
            case "js":   type = "text/javascript"; break;
            case "html": type = "text/html"; break;
            case "woff": type = "application/x-font-woff"; break;
            case "jpeg": type = "image/jpeg"; break;
            case "jpg":  type = "image/jpeg"; break;
            case "png":  type = "image/png"; break;
            case "ico":  type = "image/x-icon"; break;
            case "xml":  type = "application/xml"; break;
            case "xsl":  type = "text/xsl"; break;
            case "xslt": type = "text/xsl"; break;
            case "css":  type = "text/css"; break;
            case "json": type = "application/json"; break;
            default:
               LOG.warn("No mime type defined for file " + pRemainder);
         }
      }

      if (type != null) return Response.ok(isFile, type).build();
      else return Response.ok(isFile).build();
   }
}
