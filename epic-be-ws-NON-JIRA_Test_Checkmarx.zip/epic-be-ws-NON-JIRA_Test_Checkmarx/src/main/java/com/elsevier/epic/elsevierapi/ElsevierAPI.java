package com.elsevier.epic.elsevierapi;

import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.utility.Utility;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class ElsevierAPI implements DataFeed {
    private static final Logger LOG = Log.getLogger(ElsevierAPI.class);
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe


    PreparedStatement getStatement(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement("select * from getelsevierapiusage(?,?,?,?) order by api_name,year");
        ps.setQueryTimeout(60);
        return ps;
    }


    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
        if (pIDs.size() < 1) throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);

        String paramAccount = pIDs.get(0).value;

        String paramYearStart = pParameters.get("yearstart");
        String paramYearEnd = pParameters.get("yearend");
        String paramContentSource = pParameters.get("contentsource");


        int accountID;
        try {
            accountID = Integer.parseInt(paramAccount);
        } catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
                    .setMessage("Invalid ID '" + paramAccount + "'")
                    .setException(ex)
                    .build());
        }
        Calendar cal = Calendar.getInstance();
        ObjectNode jsRoot = jsFactory.objectNode();

        if(paramYearStart==null) paramYearStart=Integer.toString(cal.get(Calendar.YEAR)-4);
        if(paramYearEnd==null) paramYearEnd=Integer.toString(cal.get(Calendar.YEAR));

        int ys = Utility.readInt(paramYearStart);
        final int yearEnd;
        int ye = Utility.readInt(paramYearEnd);


        int currentYear = cal.get(Calendar.YEAR);
        yearEnd = (ye <= 0) ? currentYear : ye;

        if (ys > currentYear) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Start year "+ys+" cannot be greater than current year "+ currentYear).build();
        }

        if ((ys < 0) || (ys > yearEnd)) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid parameters. Default/Passed parameters startYear:"+paramYearStart+",endYear:"+paramYearEnd).build();
        }

        fetchRecords(jsRoot,accountID,paramContentSource,paramYearStart,paramYearEnd);

        return Response.ok(jsRoot).build();
    }


    private void fetchRecords(ObjectNode pResult, int accountID, String contentSource, String pYearStart, String pYearEnd) {
        String currAPIName="";
        String prevAPIName="";
        ArrayNode yearArrayNode=jsFactory.arrayNode();
        boolean dataFlag=false;
        ObjectNode apiNode=jsFactory.objectNode();
        try (Connection con = PostgresClient.getConnection();
             PreparedStatement ps = getStatement(con)) {
            ps.setQueryTimeout(60);
            ps.setInt(1, accountID);
            ps.setString(2, contentSource);
            if(pYearStart !=null) ps.setInt(3, Integer.parseInt(pYearStart)); else ps.setNull(3, Types.INTEGER);
            if(pYearEnd !=null) ps.setInt(4, Integer.parseInt(pYearEnd)); else ps.setNull(4, Types.INTEGER);

            try(ResultSet rs= ps.executeQuery()) {

                ArrayNode apiArrayNode = jsFactory.arrayNode();
                ObjectNode jsUsage = jsFactory.objectNode();
                jsUsage.put("Account", accountID);
                while (rs.next()) {
                    //vaccountID=rs.getString(1).trim();
                    dataFlag = true;
                    prevAPIName = currAPIName;
                    currAPIName = rs.getString(2);
                    if (!currAPIName.equals(prevAPIName)) {
                        apiNode = jsFactory.objectNode();
                        apiNode.put("Name", currAPIName);
                        yearArrayNode = jsFactory.arrayNode();
                        jsUsage.set(currAPIName, yearArrayNode);

                    }
                    ObjectNode yearNode = jsFactory.objectNode();
                    String year = rs.getString(3).trim();
                    yearNode.put("year", year);
                    yearNode.put("total", rs.getString(4).trim());
                    Map MonthCountMap = new HashMap();
                    String monthList = rs.getString(5);
                    //List<String> monthList =Arrays.asList(rs.getString(5).split(","));
                    //Map<String,String> MonthCountMap= monthList.stream().collect(Collectors.toMap(p -> p.split("~")[0], p -> p.split("~")[1]));
                    int MaxRequestYrMo = rs.getInt(6);
                    assignMonthCountMap(monthList, MonthCountMap);
                    ArrayNode monthArrayNode = jsFactory.arrayNode();
                    for (int i = 1; i <= 12; i++) {

                        String monthCountValue = Integer.parseInt(year + String.format("%02d", i)) > MaxRequestYrMo ? null : MonthCountMap.containsKey(i) ? MonthCountMap.get(i).toString() : "0";
                        monthArrayNode.add(monthCountValue);
                    }
                    yearNode.set("months", monthArrayNode);
                    yearArrayNode.add(yearNode);
                }
                if (!dataFlag)
                    pResult.put("ElsevierUsage", "No data found for the parameters passed");
                else
                    pResult.set("ElsevierUsage", jsUsage);
            }
            catch (SQLException ex) {
                LOG.warn(ex);
                throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                        .setMessage("A server database failure has occurred.")
                        .setException(ex)
                        .build());
            }

        } catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }

    }
        private void assignMonthCountMap(String monthList,Map MonthCountMap){
        String[] monthListArray=monthList.split(",");
        for(int i=0;i<monthListArray.length;i++){
            MonthCountMap.put(Integer.parseInt(monthListArray[i].split("~")[0].trim()),monthListArray[i].split("~")[1].trim());

        }
}



}
