/**
 * Caching module for all things related to Science Direct journals.
 */

package com.elsevier.epic.utility;

import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.Journal;
import com.elsevier.epic.types.JournalCategory;
import com.elsevier.epic.types.JournalFamily;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import static java.util.Objects.isNull;

public class SDJournals {
    private static final Logger LOG = Log.getLogger(SDJournals.class);

    static final Map<String, Journal> journalList = new HashMap<>();
    static final Map<Integer, JournalCategory> categoryList = new TreeMap<>();
    static final ArrayList<String> journalFamilyList = new ArrayList<>();
    static final String sqlJournals =
            "SELECT issn, subscribable, content_type, title, publisher, imprint, type_name AS content_name\n" +
            "FROM journal\n" +
            "LEFT OUTER JOIN sd_content_type ct ON ct.code=journal.content_type";
    static final String sqlCategories = "SELECT code, name FROM journal_categories";
    static final String sqlFamilies = "SELECT distinct journal_family FROM account_top_turnaways_asjc_journal_family_c5";
    private static SDJournals instance = null;
    private final PostgresClient postgresClient;

    SDJournals() {
        postgresClient = PostgresClient.getInstance();
    }

    SDJournals(PostgresClient postgresClient) {
        this.postgresClient = postgresClient;
    }

    public void initialiseAll() throws SQLException {
        loadJournals();
        loadCategories();
        loadFamilies();
    }

    public void loadJournals() throws SQLException {
        try (Connection con = postgresClient.getConnectionPool();
             PreparedStatement psJournals = con.prepareStatement(sqlJournals);
             ResultSet rst = psJournals.executeQuery()) {

            journalList.clear();
            while (rst.next()) {
                Journal j = new Journal();
                j.issn = rst.getString("issn");
                j.subscribable = rst.getBoolean("subscribable");
                j.srcType = rst.getString("content_type");
                j.srcTypeName = rst.getString("content_name");
                j.title = rst.getString("title");
                j.publisher = rst.getString("publisher");
                j.imprint = rst.getString("imprint");

                journalList.put(j.issn, j);
            }
        }

        LOG.info("Loaded " + journalList.size() + " SD journals into cache.");
    }

    public void loadCategories() throws SQLException {
        try (Connection con = postgresClient.getConnectionPool();
             PreparedStatement psJournals = con.prepareStatement(sqlCategories);
             ResultSet rst = psJournals.executeQuery()) {

            categoryList.clear();
            while (rst.next()) {
                JournalCategory j = new JournalCategory();
                j.code = rst.getInt("code");
                j.name = rst.getString("name");

                categoryList.put(j.code, j);
            }
        }

        LOG.info("Loaded " + categoryList.size() + " journal categories into cache.");
    }

    public void loadFamilies() throws SQLException {
        try (Connection con = postgresClient.getConnectionPool();
             PreparedStatement psJournalFamilies = con.prepareStatement(sqlFamilies);
             ResultSet rst = psJournalFamilies.executeQuery()) {

            journalFamilyList.clear();
            while (rst.next()) {
                JournalFamily family = new JournalFamily();
                family.name = rst.getString("journal_family");

                if ("".equals(family.name) || isNull(family.name)) {
                    family.name = "Others";
                }

                journalFamilyList.add(family.name);
            }
        }

        LOG.info("Loaded " + journalFamilyList.size() + " journal families into cache.");
    }

    static public Map<Integer, JournalCategory> allCategories() {
        return categoryList;
    }

    public ArrayList<String> allJournalFamilies() {
        return journalFamilyList;
    }

    /**
     * @deprecated use non-static method
     */
    static public Journal getJournal(String pISSN) {
        return journalList.get(pISSN);
    }

    public Journal getJournals(String pISSN) {
        return journalList.get(pISSN);
    }

    static public JournalCategory getCategory(Integer pCode) {
        return categoryList.get(pCode);
    }

    public static SDJournals getInstance() {
        if (instance == null) {
            instance = new SDJournals();
        }
        return instance;
    }
}

