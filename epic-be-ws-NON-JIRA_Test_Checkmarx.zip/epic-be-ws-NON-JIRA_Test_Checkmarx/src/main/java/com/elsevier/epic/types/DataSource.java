package com.elsevier.epic.types;

import com.elsevier.epic.core.ServerConfig;
import io.dropwizard.setup.Environment;

public interface DataSource {
   public void init(ServerConfig pConfig, Environment pEnv);
}
