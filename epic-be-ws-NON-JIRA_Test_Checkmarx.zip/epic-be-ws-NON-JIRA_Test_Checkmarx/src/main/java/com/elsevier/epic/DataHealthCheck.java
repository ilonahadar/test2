/*

This code checks that the data sources are able to return the data we expect them to contain.

*/

package com.elsevier.epic;

import com.codahale.metrics.health.HealthCheck;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.exceptions.AppException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

public class DataHealthCheck extends HealthCheck {
   private static final Logger LOG = Log.getLogger(DataHealthCheck.class);

   @Override
   protected HealthCheck.Result check() throws Exception {
      Result result = checkPostgresData();
      if (result != null) return result;

      return HealthCheck.Result.healthy("All data sources are returning project dependent data.");
   }

   private static Result checkPostgresData() {
      //LOG.info("Checking Postgres connectivity and schema.");

      try (Connection con = PostgresClient.getConnection()) {
         try {
            testStatement(con, "SELECT pii FROM sdarticle_p LIMIT 1", true);
         }
         catch (Exception ex) {
            return HealthCheck.Result.unhealthy("Failed to run query: " + ex.getMessage());
         }
      }
      catch (Exception ex) {
         return HealthCheck.Result.unhealthy(ex);
      }

      return null;
   }

   private static void testStatement(Connection pConnection, String pStatement, boolean pExpectRow) throws SQLException {
      //LOG.debug("Testing: " + pStatement);

      try (PreparedStatement prepare = pConnection.prepareStatement(pStatement);
           ResultSet rst = prepare.executeQuery()) {
         if (pExpectRow) {
            if (!rst.next()) throw new AppException("No records returned for statement: " + pStatement);
         }
      }
   }
}
