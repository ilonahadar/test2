package com.elsevier.epic.scival.collaboration;

import com.elsevier.epic.postgres.PostgresClient;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CountryNameLookupImpl implements CountryNameLookup {
    private static final Logger LOG = Log.getLogger(CountryNameLookupImpl.class);

    @Override
    public String getCountryName(int countryISONum) throws UnknownCountryException {
        String errorMessage = "Could not resolve country name for ISO code " + countryISONum;

        try (Connection con = PostgresClient.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT country FROM scival_country WHERE country_iso=?");
            ps.setQueryTimeout(60);

            ps.setInt(1, countryISONum);
            try (ResultSet rst = ps.executeQuery()) {
                if (rst.next()) {
                    return rst.getString(1);
                } else {
                    throw new UnknownCountryException(countryISONum);
                }
            }
        }
        catch (SQLException ex) {
            error(errorMessage, ex);
        }

        throw new UnknownCountryException(countryISONum);
    }

    private void error(String message) {
        LOG.warn(message);
    }

    private void error(String message, Exception exceptions) {
        LOG.warn(message, exceptions);
        throw new RuntimeException(message, exceptions);

    }

}
