package com.elsevier.epic.scival.collaboration;

import java.util.Map;

class GetStartAndEndYearFromParameters implements SciValCollaborationByCountry.StartAndEndYear {
    private Map<String, String> parameters;

    public GetStartAndEndYearFromParameters(Map<String, String> parameters) {
        this.parameters = parameters;
    }

    @Override
    public String getStartYear() {
        return parameters.get("yearstart");
    }

    @Override
    public String getEndYear() {
        return parameters.get("yearend");
    }
}
