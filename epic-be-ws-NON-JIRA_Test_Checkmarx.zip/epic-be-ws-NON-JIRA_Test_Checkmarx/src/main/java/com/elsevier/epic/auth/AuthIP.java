package com.elsevier.epic.auth;

import com.elsevier.epic.core.ServerConfig;
import com.elsevier.epic.exceptions.AppException;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.IntBuffer;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AuthIP implements AuthClient {
   private static final Logger LOG = Log.getLogger(AuthToken.class);

   private static final Set<InetAddress> sites = new HashSet<>();
   private static final Set<RangeIP> ranges = new HashSet<>();
   private static final Pattern rangePattern = Pattern.compile("([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3})\\s*-\\s*([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3})");
   private static final Pattern ipPattern = Pattern.compile("[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}");

   static public class RangeIP {
      private final InetAddress start;
      private final InetAddress end;
      private final IntBuffer iStart;
      private final IntBuffer iEnd;

      RangeIP(InetAddress start, InetAddress end) {
         this.start  = start;
         this.end    = end;
         this.iStart = IntBuffer.allocate(4);
         this.iEnd   = IntBuffer.allocate(4);

         byte[] bytes = start.getAddress();
         for (int i=0; i < 4; i++) this.iStart.put(i, bytes[i] & 0xff);

         bytes = end.getAddress();
         for (int i=0; i < 4; i++) this.iEnd.put(i, bytes[i] & 0xff);
      }

      boolean validIP(InetAddress ip) {
         IntBuffer iIP = IntBuffer.allocate(4);
         byte[] bytes = ip.getAddress();
         for (int i=0; i < 4; i++) iIP.put(i, bytes[i] & 0xff);

         if ((iIP.compareTo(iStart) >= 0) && (iIP.compareTo(iEnd) <= 0)) return true;
         else return false;
      }
   }

   /**
    * Ensure that the IP filter list contains only valid strings.
    *
    * @param pList
    */

   static public void validateIPList(List<String> pList) {
      Iterator<String> itIP = pList.iterator();
      while (itIP.hasNext()) {
         String filter = itIP.next();

         try {
            InetAddress address = InetAddress.getByName(filter); // Throws an exception if not a vanilla IP address, although succeeds in odd circumstances like '55'.
            Matcher matcher = ipPattern.matcher(filter);
            if (matcher.matches()) {
               sites.add(address);
               LOG.info("Allowing IP address " + address);
               continue;
            }
         }
         catch (UnknownHostException e) { }

         Matcher matcher = rangePattern.matcher(filter);
         if (matcher.matches()) {
            try {
               InetAddress start = InetAddress.getByName(matcher.group(1));
               InetAddress end = InetAddress.getByName(matcher.group(2));
               ranges.add(new RangeIP(start, end));
               LOG.info("Allowing IP range " + start + " to " + end);
               continue;
            }
            catch (UnknownHostException e) { }
         }

         throw new AppException("IP address range '" + filter + "' is invalid." );
      }
   }

   static public boolean validIP(InetAddress pIP) {
      if (pIP != null) {
         if (sites.contains(pIP)) return true;

         for (RangeIP range : ranges) {
            if (range.validIP(pIP)) return true;
         }
      }

      return false;
   }

   @Override
   public void init(ServerConfig pConfig) {
      List<String> pIPList = pConfig.getAllowedIPs();

      if (pIPList != null) {
         List<String> ips = pIPList;
         validateIPList(ips); // Throws an exception if one of the filter strings is invalid.
      }
   }

   /**
    * If the client is within the IP range, let them through without any further checks.
    *
    * @param hr
    * @param httpRequest
    * @param authHeader
    * @return
    */

   @Override
   public int authenticate(HttpServletResponse hr, HttpServletRequest httpRequest, String authHeader) {
      if (!sites.isEmpty()) {
         InetAddress ipAddress = null;
         String xFor = httpRequest.getHeader("X-Forwarded-For");
         try {
            if (xFor != null) ipAddress = InetAddress.getByName(xFor);
            if (ipAddress == null) ipAddress = InetAddress.getByName(httpRequest.getRemoteAddr());

            if (validIP(ipAddress)) return AuthFilter.AUTH_ACCEPTED;
         }
         catch (UnknownHostException ex) { }
      }

      return AuthFilter.AUTH_CONTINUE;
   }
}
