package com.elsevier.epic.auth;

import com.elsevier.epic.types.IDValue;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;

public class AuthCountryMetrics implements URIAuthorisation {
   @Override
   public void authorise(HttpServletRequest pRequest, ArrayList<IDValue> pIDs) {
      String accountID ="";

      if (pIDs != null) {
         for (IDValue id : pIDs) {
            if (("sisID".equals(id.id.getName())) || ("accountID".equals(id.id.getName()))) {
               accountID = id.value;
               break;
            }
         }
      }
      AuthAccess.checkAccountCountryAccess(pRequest, accountID);
   }
}
