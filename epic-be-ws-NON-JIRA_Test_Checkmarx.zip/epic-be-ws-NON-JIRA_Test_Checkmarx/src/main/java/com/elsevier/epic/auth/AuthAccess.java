package com.elsevier.epic.auth;

import com.elsevier.epic.core.ErrorResponse;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

public class AuthAccess {
   /**
    * Confirms logged in session has access to a particular account.  The customer ID
    * values are checked (we can get away with this because they are unique within the same ID space).
    *
    * @param pRequest
     * @param accountCountryCode
     * @param accountCountry
    * @param customerID
    */
    
      static public void checkAccountCountryAccess(HttpServletRequest pRequest, String accountCountryCode) {

      Map<String, Object> tokenMap = (Map<String, Object>)pRequest.getAttribute("tokenMap");
      if (tokenMap == null) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.FORBIDDEN)
            .setMessage("This interface requires a valid user session.")
            .build());
      }

      // Administrators can see everything
      Integer accessLevel = (Integer)tokenMap.get("al");
      if (accessLevel == UserCredentials.AL_ADMIN) return;

      {
         ArrayList<String> customerID = (ArrayList<String>)tokenMap.get("sis");         

         for (Iterator<String> it = customerID.iterator(); it.hasNext();) {
             String s = String.valueOf(it.next());
         }

         // token should have country and customer id should exist
         // get data TODO: validate that country code is tied to that customer OR do we just trust client?
         String countryCode = (String)tokenMap.get("countryCode");
//         if (!countryCode.isEmpty() && (!customerID.isEmpty()) ) {
         if (!countryCode.isEmpty()  ) {
             return;
         }
  
//         if (countryCode.isEmpty() || customerID.isEmpty() ) {
         if (countryCode.isEmpty() ) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.FORBIDDEN)
               .setMessage("The logged in user has no account access privileges.")
               .build());
         }
      }

      throw new WebApplicationException(ErrorResponse.status(Response.Status.FORBIDDEN)
         .setMessage("The logged in user has no access to account #" + accountCountryCode + " country metrics")
         .build());
   }
 
   static public void checkAccountAccess(HttpServletRequest pRequest, String customerID) {

      Map<String, Object> tokenMap = (Map<String, Object>)pRequest.getAttribute("tokenMap");
      if (tokenMap == null) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.FORBIDDEN)
            .setMessage("This interface requires a valid user session.")
            .build());
      }

      // Administrators can see everything
      Integer accessLevel = (Integer)tokenMap.get("al");
      if (accessLevel == UserCredentials.AL_ADMIN) return;

      {
//         String countryCode = (String)tokenMap.get("countryCode");   

          ArrayList<String> sis = (ArrayList<String>)tokenMap.get("sis");         
//         if (countryCode.isEmpty() || sis.isEmpty()) {
         if ( sis.isEmpty()) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.FORBIDDEN)
               .setMessage("The logged in user does not have any account access privileges.")
               .build());
         }
          // explicity strip off ECR and rewrite request to be a negative number
          // because they can't migrate everything and it'll probably take years so there you have it
          for (Iterator<String> it = sis.iterator(); it.hasNext();) {
              //String s = it.next();
              String s = String.valueOf(it.next());
              if (customerID.equals( s.replace("ECR", ""))) {
                  return;
              }
          }
      }

      throw new WebApplicationException(ErrorResponse.status(Response.Status.FORBIDDEN)
         .setMessage("The logged in user does not have access to account #" + customerID)
         .build());
   }
}