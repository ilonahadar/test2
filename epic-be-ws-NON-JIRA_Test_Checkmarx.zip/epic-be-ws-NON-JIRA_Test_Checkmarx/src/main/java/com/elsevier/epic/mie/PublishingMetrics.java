package com.elsevier.epic.mie;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import javassist.bytecode.stackmap.BasicBlock;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;
import org.glassfish.jersey.server.ParamException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class PublishingMetrics implements DataFeed {

    private static final Logger LOG = Log.getLogger(PublishingMetrics.class);
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

    PreparedStatement getStatement(Connection con) throws SQLException {

        PreparedStatement ps = con.prepareStatement(getResourceString("/mie_publishing_metrics.sql"));
        ps.setQueryTimeout(60);
        return ps;

    }

    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {

        if(pIDs.size() < 1) throw new WebApplicationException(Response.Status.BAD_REQUEST);

        String paramAccountID = pIDs.get(0).value;
        String paramSubjectID = pIDs.get(1).value;

        int accountID = validateIntParams(paramAccountID);
        int subjectID = validateIntParams(paramSubjectID);

        ObjectNode jsRoot = jsFactory.objectNode();
        ObjectNode jsParams = jsFactory.objectNode();

        jsRoot.set("parameters", jsParams);
        jsParams.put("sisid", paramAccountID);
        jsParams.put("subjectid", paramSubjectID);

        queryCounter(jsRoot, accountID, subjectID);
        return Response.ok(jsRoot).build();
    }

    private void queryCounter(ObjectNode pResult, int pSIS, int pSubID){

        try (Connection con = PostgresClient.getConnection();
             PreparedStatement ps = getStatement(con)){

            ps.setInt(1, pSIS);
            ps.setInt(2, pSubID);
            ps.setInt(3, pSIS);
            ps.setInt(4, pSubID);

            if (!CoreServer.isProduction()) LOG.info(ps.toString());

            ObjectNode pubMetrics = jsFactory.objectNode();

            ps.execute();

            topJournalsPublished(ps, pubMetrics, "TopJournals");
            ps.getMoreResults();
            topMembersPublished(ps, pubMetrics, "TopMembers");

            pResult.set("result", pubMetrics);

        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }
    }

    static private void topJournalsPublished(PreparedStatement ps, ObjectNode ReadMetrics, String name) throws java.sql.SQLException {

        ResultSet rst = ps.getResultSet();

        ObjectNode timeNode = jsFactory.objectNode();
        ArrayNode rowNode1 = jsFactory.arrayNode();
        ArrayNode rowNode2 = jsFactory.arrayNode();
        ArrayNode rowNode3 = jsFactory.arrayNode();

        while (rst.next()) {

            String timePeriod = rst.getString(1);
            String issn = rst.getString(2);
            String journalTitle = rst.getString(3);
            String publishedCount = rst.getString(4);
            String rank = rst.getString(5);

            if (timePeriod.equals("All")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("issn", issn);
                locNode.put("journal_title", journalTitle);
                locNode.put("published_count", publishedCount);
                locNode.put("rank", rank);

                rowNode1.add(locNode);

                timeNode.set("All_Time", rowNode1);

            }

            if (timePeriod.equals("This_Year")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("issn", issn);
                locNode.put("journal_title", journalTitle);
                locNode.put("published_count", publishedCount);
                locNode.put("rank", rank);

                rowNode2.add(locNode);

                timeNode.set(timePeriod, rowNode2);

            }

            if (timePeriod.equals("Five_Years")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("issn", issn);
                locNode.put("journal_title", journalTitle);
                locNode.put("published_count", publishedCount);
                locNode.put("rank", rank);

                rowNode3.add(locNode);

                timeNode.set(timePeriod, rowNode3);

            }

        }

        ReadMetrics.set(name, timeNode);

    }

    static private void topMembersPublished(PreparedStatement ps, ObjectNode ReadMetrics, String name) throws java.sql.SQLException {

        ResultSet rst = ps.getResultSet();

        ObjectNode headNode = jsFactory.objectNode();
        ObjectNode timeNode = jsFactory.objectNode();
        ArrayNode rowNode1 = jsFactory.arrayNode();
        ArrayNode rowNode2 = jsFactory.arrayNode();
        ArrayNode rowNode3 = jsFactory.arrayNode();

        while (rst.next()) {

            String timePeriod = rst.getString(1);
            String memberFirstName = rst.getString(2);
            String memberLastName = rst.getString(3);
            String publishedCount = rst.getString(4);
            String rank = rst.getString(5);

            if (timePeriod.equals("All")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("first_name", memberFirstName);
                locNode.put("last_name", memberLastName);
                locNode.put("total_published", publishedCount);
                locNode.put("rank", rank);

                rowNode1.add(locNode);

                timeNode.set("All_Time", rowNode1);

            }

            if (timePeriod.equals("This_Year")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("first_name", memberFirstName);
                locNode.put("last_name", memberLastName);
                locNode.put("total_published", publishedCount);
                locNode.put("rank", rank);

                rowNode2.add(locNode);

                timeNode.set(timePeriod, rowNode2);

            }

            if (timePeriod.equals("Five_Years")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("first_name", memberFirstName);
                locNode.put("last_name", memberLastName);
                locNode.put("total_published", publishedCount);
                locNode.put("rank", rank);

                rowNode3.add(locNode);

                timeNode.set(timePeriod, rowNode3);

            }

            headNode.set("TopMembers", timeNode);
        }

        ReadMetrics.set(name, headNode);

    }

    private int validateIntParams(String pName) {

        int pVal;

        try {
            pVal = Integer.parseInt(pName);
        }
        catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
                    .setMessage("Invalid ID '" + pName + "'")
                    .setException(ex)
                    .build());
        }
        return pVal;
    }

    static private String getResourceString(String pName) {
        // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
        // all available resource files.
        InputStream isResource = String.class.getResourceAsStream(pName);
        if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
        else throw new RuntimeException("Could not find resource '" + pName + "'");
    }

}
