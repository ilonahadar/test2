package com.elsevier.epic.postgres;

import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.core.ServiceBuilder;
import com.elsevier.epic.exceptions.AppException;
import com.elsevier.epic.jaxb.FieldType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.elsevier.epic.utility.Utility;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response.Status;
import java.io.IOException;
import java.sql.Array;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class SQLMap {
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It is thread-safe

   /**
    *
    * @param pColumns Column definitions - required to determine the type of the column being output.
    * @param pField   The field being output, retrieved from the data schema.
    * @param pRow     The row that contains the data for retrieving this field's value.
    * @param pOutput  The key-value for this field and its value will be written here.
    */

   static public void outputField(ResultSetMetaData pColumns, FieldType pField, ResultSet pRow, ObjectNode pOutput) {
      String type    = pField.getType();    // The field type to use for JSON output.
      String outName = pField.getName();    // Nice name for JSON output.
      String col     = pField.getColumn();  // Source column
      boolean hideZeros, hideEmpty;

      if (pField.getHideZeros() != null) hideZeros = pField.getHideZeros().equals("true");
      else hideZeros = false;

      if (pField.getHideEmpty() != null) hideEmpty = pField.getHideEmpty().equals("true");
      else hideEmpty = false;

      String keyType = pField.getKeyType();

      boolean emptyName = false;
      if (outName == null) {
         outName = col;
         emptyName = true;
      }

      if ((col == null) && (outName != null)) {
         // No source column specified.  In this case we will merge the child fields in this section with the
         // node that has been specified by name.  If the referenced node does not already exist, then we create
         // a new node with that name.

         List<FieldType> fields = pField.getField();
         if (fields != null) {
            ObjectNode customNode;
            if (pOutput.has(outName)) { // Does the key already exist in the output?  If so, perform a merge.
               JsonNode existingNode = pOutput.get(outName);
               if (existingNode.isObject()) customNode = (ObjectNode)existingNode;
               else customNode = jsFactory.objectNode(); // Node exists but is not an object.  Overwrite the existing key.
            }
            else customNode = jsFactory.objectNode();
            for (FieldType f : fields) {
               outputField(pColumns, f, pRow, customNode);
            }
            if ((!hideEmpty) || (customNode.size() > 0)) {
               pOutput.set(outName, customNode);
            }
         }
         else if (ServiceBuilder.outputNulls.get() == true) pOutput.putNull(outName);
      }
      else {
         try {
            int colIndex = pRow.findColumn(col);
            int dt = pColumns.getColumnType(colIndex);

            if (type == null) { // If no type is declared in the data schema, we'll use the column type indicated by the driver.
               switch (dt) {
                  case java.sql.Types.BIT:
                  case java.sql.Types.BOOLEAN: {
                     pOutput.put(outName, pRow.getBoolean(colIndex));
                     break;
                  }

                  case java.sql.Types.CHAR:
                  case java.sql.Types.VARCHAR: {
                     String val = pRow.getString(colIndex);
                     if ((val != null) && (val.isEmpty())) val = null;
                     if ((!hideEmpty) || (val != null)) pOutput.put(outName, val);
                     break;
                  }

                  case java.sql.Types.TIMESTAMP: {
                     SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                     pOutput.put(outName, sd.format(new java.util.Date(pRow.getTimestamp(col).getTime())));
                     break;
                  }

                  case java.sql.Types.NUMERIC:
                  case java.sql.Types.BIGINT: {
                     long val = pRow.getLong(colIndex);
                     if ((!hideZeros) || (val != 0)) pOutput.put(outName, val);
                     break;
                  }

                  case java.sql.Types.INTEGER: {
                     int val = pRow.getInt(colIndex);
                     if ((!hideZeros) || (val != 0)) pOutput.put(outName, val);
                     break;
                  }

                  case java.sql.Types.DOUBLE: {
                     double val = pRow.getDouble(colIndex);
                     if ((!hideZeros) || (val != 0)) pOutput.put(outName, val);
                     break;
                  }

                  case java.sql.Types.ARRAY: {
                     Array array = pRow.getArray(colIndex);
                     if (array != null) {
                        ArrayNode jsArray = jsFactory.arrayNode();
                        switch (array.getBaseType()) {
                           case java.sql.Types.INTEGER: {
                              for (Integer v : (Integer[])array.getArray()) jsArray.add(v);
                              break;
                           }
                           case java.sql.Types.CHAR:
                           case java.sql.Types.VARCHAR: {
                              for (String v : (String[])array.getArray()) jsArray.add(v);
                              break;
                           }
                           default:
                              throw new AppException("Unsupported SQL array type '" + array.getBaseTypeName() + "' (" + array.getBaseType());
                        }

                        pOutput.set(outName, jsArray);
                     }
                     break;
                  }

                  default: throw new AppException("Unrecognised type '" + pColumns.getColumnTypeName(colIndex) + "' (" + pColumns.getColumnType(colIndex) + ") in column '" + pColumns.getColumnName(colIndex) + "'");
               }
            }
            else switch (type) {
               case "BOOL":      pOutput.put(outName, pRow.getBoolean(colIndex)); break;
               case "TIMESTAMP": pOutput.put(outName, Utility.outputTimestamp(pRow.getLong(col))); break;
               case "STRING": {
                  String val = pRow.getString(colIndex);
                  if ((val != null) && (val.isEmpty())) val = null;
                  if ((!hideEmpty) || (val != null)) pOutput.put(outName, val);
                  break;
               }
               case "INTEGER": {
                  int val = pRow.getInt(colIndex);
                  if ((!hideZeros) || (val != 0)) pOutput.put(outName, val);
                  break;
               }
               case "BIGINT": {
                  long val = pRow.getLong(colIndex);
                  if ((!hideZeros) || (val != 0)) pOutput.put(outName, val);
                  break;
               }
               case "DOUBLE": {
                  double val = pRow.getDouble(colIndex);
                  if ((!hideZeros) || (val != 0)) pOutput.put(outName, val);
                  break;
               }
               case "JSON":
                  String str = pRow.getString(colIndex);
                  if (str != null) {
                     try {
                        ObjectMapper mapper = new ObjectMapper();
                        JsonNode jsInput = mapper.readTree(str);
                        if (jsInput.size() == 0) jsInput = null;
                        if (emptyName) {
                           if (jsInput != null) {
                              Iterator<Map.Entry<String, JsonNode>> fields = jsInput.fields();
                              while (fields.hasNext()) {
                                 Map.Entry<String, JsonNode> entry = fields.next();
                                 JsonNode val = entry.getValue();
                                 String key = entry.getKey();
                                 if (val.isContainerNode()) {
                                    if (val.size() > 0) {
                                       pOutput.set(key, val);
                                    }
                                 }
                                 else pOutput.set(key, val);
                              }
                           }
                        }
                        else if ((outName != null) && (!outName.isEmpty())) {
                           if ((hideEmpty) && (jsInput == null)); // Do nothing if no data to output;
                           else pOutput.set(outName, jsInput);
                        }
                     }
                     catch (IOException ex) {
                        throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                           .setMessage("Server error.  Failed to parse JSON data from the Elastic Search server.")
                           .setException(ex)
                           .build());
                     }
                  }
                  break;

               case "ARRAY":
                  // <field source="citations" type="ARRAY" object="citation" name="Citations"/>
                  throw new AppException("Support for ARRAY type not yet implemented.");

               default:
                  throw new AppException("Unrecognised type '" + type + "' in field reference for '" + col + "'");
            }
         }
         catch (SQLException ex) {
            throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
               .setMessage("Database failure: " + ex.getMessage())
               .setException(ex)
               .build());
         }
      }

      if (ServiceBuilder.outputNulls.get() == false) {
         // Was the output field value a null?  If so, remove it.
         if (!pOutput.hasNonNull(outName)) pOutput.remove(outName);
      }
   }
}
