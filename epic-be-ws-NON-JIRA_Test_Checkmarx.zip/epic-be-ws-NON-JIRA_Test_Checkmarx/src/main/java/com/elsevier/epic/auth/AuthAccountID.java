package com.elsevier.epic.auth;

import com.elsevier.epic.types.IDValue;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;

public class AuthAccountID implements URIAuthorisation {
   @Override
   public void authorise(HttpServletRequest pRequest, ArrayList<IDValue> pIDs) {
      String accountID ="";

      if ((pIDs != null) && (accountID.isEmpty())) {
         for (IDValue id : pIDs) {
            if ("accountID".equals(id.id.getName())) {
               accountID = id.value;
               break;
            }
         }
      }
      AuthAccess.checkAccountAccess(pRequest, accountID);
   }
}