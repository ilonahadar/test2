package com.elsevier.epic.scival.collaboration;

import com.elsevier.epic.types.IDValue;

import java.util.ArrayList;

public class GetAccountFromIds implements SciValCollaborationByCountry.Account {
    private ArrayList<IDValue> ids;

    public GetAccountFromIds(ArrayList<IDValue> ids) {
        this.ids = ids;
    }

    @Override
    public int getAccountId() {
        return Integer.parseInt(ids.get(0).value);
    }
}
