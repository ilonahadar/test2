
package com.elsevier.epic.scival;

import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.PostgresClient;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.elsevier.epic.utility.Utility;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

public class SciValCollaboration implements DataFeed {
   private static final Logger LOG = Log.getLogger(SciValCollaboration.class);
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

   PreparedStatement getStatement(Connection con) throws SQLException {
      PreparedStatement ps = con.prepareStatement("SELECT sv_id FROM accounts WHERE sis_hq=?");
      ps.setQueryTimeout(60);
      return ps;
   }

   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      if (pIDs.size() < 1) throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);

      String pYearStart = pParameters.get("yearstart");
      if (pYearStart == null) {
         return ErrorResponse.status(Status.BAD_REQUEST).setMessage("A yearStart parameter value is required.").build();
      }

      String pYearEnd = pParameters.get("yearend");
      if (pYearEnd == null) {
         return ErrorResponse.status(Status.BAD_REQUEST).setMessage("A yearEnd parameter value is required.").build();
      }

      int countryCode = Utility.readInt(pParameters.get("countrycode"));
      int yearStart   = Utility.readInt(pYearStart);
      int yearEnd     = Utility.readInt(pYearEnd);
      int accountID   = Integer.parseInt(pIDs.get(0).value);

      int currentYear = Calendar.getInstance().get(Calendar.YEAR);

      if ((yearStart < 1996) || (yearStart > currentYear)) {
         return ErrorResponse.status(Status.BAD_REQUEST).setMessage("The yearStart parameter value is invalid.").build();
      }

      if ((yearStart < 1996) || (yearStart > currentYear)) {
         return ErrorResponse.status(Status.BAD_REQUEST).setMessage("The yearEnd parameter value is invalid.").build();
      }

      ObjectNode jsRoot = jsFactory.objectNode();

      try (Connection con = PostgresClient.getConnection();
           PreparedStatement ps = getStatement(con)) {

         ps.setInt(1, accountID);
         try (ResultSet rst = ps.executeQuery()) {
            if (rst.next()) {
               // Request the data from the SciVal API
               Integer svID = rst.getInt(1);
               if (svID != null) {
                  jsRoot.set("byCountry", SciVal.getSVCollaborationByCountry(svID, yearStart, yearEnd, countryCode));
                  jsRoot.set("byRegion", SciVal.getSVCollaborationByRegion(svID, yearStart, yearEnd));
               }
               else return ErrorResponse.status(Status.NO_CONTENT).setMessage("Unable to retrieve SciVal data for this institution.").build();
            }
            else return ErrorResponse.status(Status.NO_CONTENT).setMessage("Unable to retrieve SciVal data for this institution.").build();
         }
      }
      catch (SQLException ex) {
         LOG.warn(ex);
         return ErrorResponse.status(Status.INTERNAL_SERVER_ERROR).setException(ex).build();
      }

      return Response.ok(jsRoot).build();
   }
}
