/**
 * For the use of the ServiceBuilder class.
 */

package com.elsevier.epic.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

public class StringStyle {
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

   public static AtomicReference<Integer> countryStyle = new AtomicReference<>(0);

   public final int UNDEFINED   = 0;
   public final int UPPER_CAMEL = 1;
   public final int LOW_CAMEL   = 2;
   public final int UNDERSCORE  = 3;

   private int style = UNDEFINED;

   public StringStyle(String pStyle) {
      switch (pStyle) {
         case "lowCamelCase":   this.style = LOW_CAMEL; break;
         case "camelCase":      this.style = UPPER_CAMEL; break;
         case "upperCamelCase": this.style = UPPER_CAMEL; break;
         case "underscore":     this.style = UNDERSCORE; break;
         default:
            throw new IllegalArgumentException("Unrecognised style '" + pStyle + "'");
      }
   }

   public boolean isUndefined()  { return this.style == UNDEFINED; }
   public boolean isUpperCamel() { return this.style == UPPER_CAMEL; }
   public boolean isLowCamel()   { return this.style == LOW_CAMEL; }
   public boolean isUnderscore() { return this.style == UNDERSCORE; }
   public int getStyle() { return this.style; }

   public String restyle(String pValue) {
      return restyle(pValue, null);
   }

   public String restyle(String pValue, String pKeyType) {
      if (pKeyType == null) {
         pValue = pValue.replaceAll("[\\W_]", " "); // Shorten keys by eliminating whitespace
         switch (this.style) {
            case UPPER_CAMEL: return camelCase(pValue);
            case LOW_CAMEL:   return lowCamelCase(pValue);
            case UNDERSCORE:  return lowUnderscore(pValue);
         }
      }
      else {
         if (pKeyType.equals("COUNTRY")) {
            switch (countryStyle.get()) {
               case 0: break; // Do not modify the source key
               case 1: pValue = restyle(pValue, null); // Restyle according to default key rules.
               case 2: break; // 2 letters
               case 3: break; // 3 letters
               case 4: break; // Full name
            }
         }
      }
      return pValue;
   }

   /**
    * Convert all keys in a json object to camel case.
    *
    * @param jsInput
    * @return
    */

   public ObjectNode restyleNode(JsonNode jsInput) {
      if (jsInput == null) return null;

      ObjectNode jsOutput = jsFactory.objectNode();

      Iterator<Map.Entry<String, JsonNode>> fields = jsInput.fields();
      if (fields != null) {
         while (fields.hasNext()) {
            Map.Entry<String, JsonNode> next = fields.next();
            jsOutput.put(restyle(next.getKey()), next.getValue());
         }
      }

      return jsOutput;
   }

   /**
    * Convert a string to lower camel case, that is: First character is lower case; all words start upper case;
    * all whitespace is eliminated.
    *
    * @param pInput
    * @return
    */

   static public String lowCamelCase(String pInput) {
      StringBuilder sb = new StringBuilder();
      boolean ucase = false;
      for (int i=0; i < pInput.length(); i++) {
         int ch = pInput.charAt(i);
         if ((ch <= 0x20) || (ch == '_')) { ucase = true; continue; }
         if (ucase) {
            if ((ch >= 'a') && (ch <= 'z')) ch = ch - 'a' + 'A';
            ucase = false;
         }
         else if ((ch >= 'A') && (ch <= 'Z')) ch = ch - 'A' + 'a';
         sb.append((char)ch);
      }
      return sb.toString();
   }

   /**
    *
    * @param pInput
    * @return
    */

   static public String camelCase(String pInput) {
      StringBuilder sb = new StringBuilder();
      boolean ucase = true;
      for (int i=0; i < pInput.length(); i++) {
         int ch = pInput.charAt(i);
         if ((ch <= 0x20) || (ch == '_')) { ucase = true; continue; }
         if (ucase) {
            if ((ch >= 'a') && (ch <= 'z')) ch = ch - 'a' + 'A';
            ucase = false;
         }
         else if ((ch >= 'A') && (ch <= 'Z')) ch = ch - 'A' + 'a';
         sb.append((char)ch);
      }
      return sb.toString();
   }

   /**
    * Convert the whitespace in a string to single underscores, and ensure that all alphabetic characters are
    * lower case.
    *
    * @param pInput
    * @return
    */

   static public String lowUnderscore(String pInput) {
      int i;
      for (i=0; i < pInput.length(); i++) { // Find the first char to be modified, to determine if restyling is even necessary.
         int ch = pInput.charAt(i);
         if ((ch <= 0x20) || (ch == '_')) break;
         if ((ch >= 'A') && (ch <= 'Z')) break;
      }
      if (i == pInput.length()) return pInput; // Return the original string if it's fine.

      StringBuilder sb = new StringBuilder(pInput.substring(0,i));
      boolean uscore = false;
      for (; i < pInput.length(); i++) {
         int ch = pInput.charAt(i);
         if ((ch <= 0x20) || (ch == '_')) { uscore = true; continue; }
         if (uscore) {
            sb.append("_");
            uscore = false;
         }
         if ((ch >= 'A') && (ch <= 'Z')) ch = ch - 'A' + 'a';
         sb.append((char)ch);
      }
      return sb.toString();
   }
}
