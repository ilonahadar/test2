/*
Please put all calls to the SciVal URI's in this module.

From Barbara Zalac:

The years need to be set according to the ranges available in the Collaboration module, see below:

3 years   2012 to 2014
3 years + current year   2012 to 2015
3 years + current year + beyond current year   2012 to >2015

5 years   2010 to 2014
5 years + current year   2010 to 2015
5 years + current year + beyond current year   2010 to >2015

Unsupported year ranges should not return data (but surprisingly you got results..)

Regarding your question, due to new features that we have implemented in the Collaboration module in June, the
response was changed slightly.

You should be using numOfCollabEntities instead of numOfCollabInstitutions.  numOfCollabInstitutions is no longer used
and should be removed from the response.  This response format is used in different calls, numCitation only has values
for one of these other calls.
*/

package com.elsevier.epic.scival;

import com.elsevier.epic.core.Country;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.Server;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.elsevier.epic.utility.CCLookup;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.TimeZone;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;
import org.apache.commons.codec.digest.*;
import org.glassfish.jersey.client.ClientProperties;

public class SciVal {
   static private final JsonNodeFactory jsFactory = new JsonNodeFactory(false);
   static private final Logger LOG = Log.getLogger(com.elsevier.epic.scival.SciVal.class);

   static final int CONNECT_TIMEOUT = 1000;
   static final int READ_TIMEOUT = 2000;

   static final SimpleDateFormat svDateFormat;
   static {
      svDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.000-0000");
      svDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
   }

   public static Client svClient() {
      final Client client = ClientBuilder.newClient();
      client.property(ClientProperties.CONNECT_TIMEOUT, CONNECT_TIMEOUT);
      client.property(ClientProperties.READ_TIMEOUT, READ_TIMEOUT);
      return client;
   }

   public static String genSVHash(String pURI, String pTimestamp, String userID, String userToken) {
      final String sign = "GET\n" + pTimestamp + "\n" + pURI + "\n";
      final byte[] hash = HmacUtils.hmacSha256(userToken, sign);
      return userID + ":" + java.util.Base64.getEncoder().encodeToString(hash);
   }

   /**
    * Make a call to SciVal using their implementation of HMAC authentication.
    *
    * @param pTarget
    * @return
    */

   static private Invocation.Builder signRequest(WebTarget pTarget) {
      final String userID = Server.config.getSVUser();
      final String userToken = Server.config.getSVUserToken();
      if ((userID.isEmpty()) || (userToken.isEmpty())) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
            .setMessage("Server not configured for SciVal access.")
            .build());
      }

      final String timestamp = svDateFormat.format(new Date());
      final String sig = genSVHash(pTarget.getUri().toString(), timestamp, userID, userToken);

      return pTarget.request()
         .header("accept", "application/json")
         .header("hmac-auth-date", timestamp)
         .header("hmac-auth-signature", sig);
   }

   static public String requestContent(WebTarget pTarget) {
      try {
         return signRequest(pTarget).get(String.class);
      }
      catch (javax.ws.rs.ProcessingException ex) {
         LOG.warn(ex);
         throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_GATEWAY)
            .setMessage("Failed to receive a response in time from SciVal web services.")
            .setException(ex)
            .build());
      }
      catch (WebApplicationException ex) {
         LOG.warn(ex);
         throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_GATEWAY)
            .setMessage("Failed to retrieve data from SciVal, received error response " + ex.getResponse().getStatus())
            .setException(ex)
            .build());
      }
   }

   /**
    *
    * @return
    * @throws java.text.ParseException
    * @throws java.io.IOException
    */

   static public SVLastUpdate getLastUpdate() throws ParseException, IOException, WebApplicationException {
      final String site = Server.config.getSVSite();
      final String uri = "https://" + site + "/api/Configuration/ScopusDataCut";

      final String content = requestContent(svClient().target(uri));

      final JsonNode jsInput = new ObjectMapper().readTree(content);
      if (jsInput != null) {
         final long lastUpdated = jsInput.path("lastUpdated").asLong(-1); // Example:  2016-01-12T11:52:00Z
         // yes, it's call "yearRangeYear". Ask Scival Team :)
         final long yearRangeYear = jsInput.path("yearRangeYear").asLong(-1); // Example:  2017

         if ((lastUpdated == -1) || (yearRangeYear == -1)) {
            throw new ParseException("Data retrieved from SciVal is not in the expected format.", -1);
         }
         return new SVLastUpdate(lastUpdated, yearRangeYear);
      }
      else throw new ParseException("Data retrieved from SciVal is not in the expected format.", -1);
   }

   /**
    * Retrieve collaboration by country for a specific institute in SciVal.
    *
    * @param pSV
    * @param pYearStart
    * @param pYearEnd
    * @param pCountryFormat
    * @return
    */

   static public ObjectNode getSVCollaborationByCountry(int pSV, int pYearStart, int pYearEnd, int pCountryFormat) {
      final String site = Server.config.getSVSite();

      final StringBuilder sbURI = new StringBuilder()
         .append("https://" + site + "/api/CollaborationMetric/CollabByLocation")
         .append("?entities=Institution/").append(pSV)
         .append("&years=").append(pYearStart).append("-").append(pYearEnd)
         .append("&level=Country")
         .append("&collabType=currentCollaboration");

      final String content = requestContent(svClient().target(sbURI.toString()));

      try {
         final JsonNode jsMap = new ObjectMapper().readTree(content);

         final JsonNode jsCollab = jsMap.get("collabDetails");
         if (jsCollab.isArray()) {
            final ObjectNode jsCountries = jsFactory.objectNode();

            Iterator<JsonNode> itDetails = jsCollab.elements();
            while (itDetails.hasNext()) {
               JsonNode jsDetail = itDetails.next();
               JsonNode jsLocation = jsDetail.get("location");
               JsonNode jsDocuments = jsDetail.get("numOfCollabDocuments");
               JsonNode jsInstitutions = jsDetail.get("numOfCollabEntities");

               Integer isoCode;
               try {
                  isoCode = Integer.parseInt(jsLocation.asText(null));
               }
               catch (NumberFormatException ex) {
                  isoCode = null;
                  LOG.warn("Failed to parse ISO code '" + jsLocation.asText() + "' from SciVal.");
               }

               if (isoCode != null) {
                  // Change the country codes to those requested.

                  int count = jsInstitutions.asInt(0);
                  Country ctry = CCLookup.codeToCountry(isoCode);
                  if (ctry == null) {
                     LOG.warn("Failed to lookup ISO country code " + isoCode);
                     jsCountries.put(Integer.toString(isoCode), count);
                  }
                  else {
                     switch (pCountryFormat) {
                        case 1: jsCountries.put(Integer.toString(ctry.code), count); break;
                        case 2: jsCountries.put(ctry.two.toLowerCase(), count); break;
                        case 3: jsCountries.put(ctry.three.toLowerCase(), count); break;
                        case 4: jsCountries.put(ctry.name, count); break;
                        default: jsCountries.put(Integer.toString(ctry.code), count); break;
                     }
                  }
               }
            }
            return jsCountries;
         }
         else throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_GATEWAY)
            .setMessage("Data retrieved from SciVal is not in the expected format.")
            .build());
      }
      catch (IOException ex) {
         LOG.warn(ex);
         throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_GATEWAY)
            .setMessage("Failed to process data retrieved from SciVal.")
            .setException(ex)
            .build());
      }
   }

   /**
    * Retrieve collaboration by region for a specific institute in SciVal.
    *
    * @param pSV Institute SciVal ID.
    * @param pYearStart
    * @param pYearEnd
    * @return
    */

   static public ObjectNode getSVCollaborationByRegion(int pSV, int pYearStart, int pYearEnd) {
      final String site = Server.config.getSVSite();

      final String sbURI = "https://" + site + "/api/CollaborationMetric/CollabByLocation"
         + "?level=Region&entities=Institution/" + pSV + "&collabType=currentCollaboration"
         + "&years=" + pYearStart + "-" + pYearEnd;

      final String content = requestContent(svClient().target(sbURI));

      try {
         final JsonNode jsMap = new ObjectMapper().readTree(content);

         final JsonNode jsCollab = jsMap.get("collabDetails");
         if (jsCollab.isArray()) {
            final ObjectNode jsRegions = jsFactory.objectNode();

            Iterator<JsonNode> itDetails = jsCollab.elements();
            while (itDetails.hasNext()) {
               JsonNode jsDetail = itDetails.next();
               JsonNode jsLocation = jsDetail.get("location");
               JsonNode jsDocuments = jsDetail.get("numOfCollabDocuments");
               JsonNode jsEntities = jsDetail.get("numOfCollabEntities");

               jsRegions.put(jsLocation.asText().toLowerCase(), jsEntities.asInt(0));
            }
            return jsRegions;
         }
         else throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_GATEWAY)
            .setMessage("Data retrieved from SciVal is not in the expected format.")
            .build());
      }
      catch (IOException ex) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_GATEWAY)
            .setMessage("Failed to process data retrieved from SciVal.")
            .build());
      }
   }
   
      /**
    * Retrieve affiliation information for a specific institute in SciVal.
    *
    * @param pSV Institute SciVal ID.
    * @return
    */

   /* for new story coming in 
   static public ObjectNode getSVAffiliationIds(int pSV) {
      final String site = Server.config.getSVSite();

      final String sbURI = "https://" + site + "/api/CollaborationMetric/CollabByLocation"
         + "?=" + pSV + "&collabType=currentCollaboration"
         + "&years=" ;

      final String content = requestContent(svClient().target(sbURI));

      try {
         final JsonNode jsMap = new ObjectMapper().readTree(content);

         final JsonNode jsCollab = jsMap.get("collabDetails");
         if (jsCollab.isArray()) {
            final ObjectNode jsRegions = jsFactory.objectNode();

            Iterator<JsonNode> itDetails = jsCollab.elements();
            while (itDetails.hasNext()) {
               JsonNode jsDetail = itDetails.next();
               JsonNode jsLocation = jsDetail.get("location");
               JsonNode jsDocuments = jsDetail.get("numOfCollabDocuments");
               JsonNode jsEntities = jsDetail.get("numOfCollabEntities");

               jsRegions.put(jsLocation.asText().toLowerCase(), jsEntities.asInt(0));
            }
            return jsRegions;
         }
         else throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_GATEWAY)
            .setMessage("Data retrieved from SciVal is not in the expected format.")
            .build());
      }
      catch (IOException ex) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_GATEWAY)
            .setMessage("Failed to process data retrieved from SciVal.")
            .build());
      }
   }
*/
}
