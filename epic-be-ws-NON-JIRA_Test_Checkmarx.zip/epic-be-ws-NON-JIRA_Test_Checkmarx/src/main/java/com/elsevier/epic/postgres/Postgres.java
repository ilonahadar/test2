/*

The /data resource is a dynamic interface that is defined by an external XML file (you should be able to find
working examples in the data folder of this project).  The XML file is validated against an XSD document to ensure
that it is safe to use before being parsed.

All discovered interfaces are registered for live processing by the getResource() function.

NB: Pay careful attention to the generated CQL.  The dynamic portions of each query must be suitably escaped.

*/

package com.elsevier.epic.postgres;

import com.codahale.metrics.Timer;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.types.InterfaceParser;
import com.elsevier.epic.types.PostProcess;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.WebAssist;
import com.elsevier.epic.jaxb.*;
import com.elsevier.epic.validation.SQLValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Path("/data{remainder:.+}")
@Produces(MediaType.APPLICATION_JSON)
public class Postgres implements InterfaceParser {
   private static final Logger LOG = Log.getLogger(Postgres.class);
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe

   private final String interfacePath;

   /**
    * Each resource accessible via /data is registered as a DataResource object, alongside its relevant URI pattern
    * matcher.
    */

   static class DataResource {
      ResourceType resource;
      Map<String, Timer> timers = null;
      String metricPattern;
      Timer timer;

      DataResource(ResourceType pResource) {
         this.resource = pResource;

         this.metricPattern = pResource.getMetricPattern();
         if (this.metricPattern == null) {
            String id = pResource.getId();
            if (id == null) id = pResource.getMethod() + pResource.getPath();
            this.timer = CoreServer.metrics.timer(id);
         }
         else {
            this.metricPattern = this.metricPattern.toLowerCase();
            this.timers = new HashMap<>();
         }
      }

      public Timer.Context getTimer(Map<String, String> pParams, ArrayList<IDValue> pIDs) {
         if (timer != null) return timer.time();

         String path = this.metricPattern;

         for (IDValue id : pIDs) {
            path = path.replace("{" + id.id.getName() + "}", id.value);
         }

         for (Map.Entry<String, String> entry : pParams.entrySet()) {
            String replace = "{" + entry.getKey() + "}";
            path = path.replace(replace, entry.getValue());
         }

         path = this.resource.getMethod() + path;

         if (!this.timers.containsKey(path)) {
            Timer tm = CoreServer.metrics.timer(path);
            this.timers.put(path, tm);
         }

         return this.timers.get(path).time();
      }
   }

   // Use a LinkedHashMap because order preservation is important.  This is thread-safe as long as the Map isn't
   // modified during read operations.
   private Map<Pattern, DataResource> resources;

   // This upper limit ensures that queries are strictly limited in their generation of root-level records.
//   private final int recordLimit = 10000;

   private final SQLValidator sqlValidator;

   public Postgres(String path) { // Main constructor
      this.sqlValidator = new SQLValidator();
      this.resources = new LinkedHashMap<>();
      this.interfacePath = path;
   }

   @Context
   UriInfo uriInfo;

   // This is a dynamic function for retrieving resources in the /data area.  It matches the client's request
   // to the correct resource in the data schema.  It is then passed to execResource() for further processing.

   @GET
   public Response getResource(@Context HttpServletRequest pRequest) {
      String reqPath = "/" + uriInfo.getPath(false);

      // Find and execute the associated resource for this URI.

      for (Map.Entry<Pattern, DataResource> entry : this.resources.entrySet()) {
         Pattern resourcePattern = entry.getKey();
         //LOG.debug("Check " + key.pattern());
         if (resourcePattern.matcher(reqPath).matches()) {
            DataResource dr = entry.getValue();

            Map<String, String> params = extractParameters(dr.resource, pRequest);
            ArrayList<IDValue> ids = extractIdentifiers(reqPath, dr.resource, resourcePattern);

            try (Timer.Context time = dr.getTimer(params, ids)) {
               WebAssist.checkResourceAuthentication(dr.resource, pRequest, ids);

               // Do the bulk of the query processing
               Response response = execResource(pRequest, reqPath, dr.resource, resourcePattern, ids, params);

               // Is post-processing of the data required?
               PostprocessType pp = dr.resource.getPostprocess();
               if (pp != null) postProcess(pp, response, ids, params);

               return response;
            }
         }
      }

      throw new WebApplicationException(ErrorResponse.status(Status.NOT_FOUND)
         .setMessage("Resource path '" + reqPath + "' is not recognised.")
         .build());
   }

   /**
    *
    * @param pProcess
    * @param pResponse
    */

   void postProcess(PostprocessType pProcess, Response pResponse, ArrayList<IDValue> pPathParams, Map<String, String> pQueryParams) {
      String className = pProcess.getClazz();
      if (className == null) throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR).build());

      try {
         Class cl = Class.forName(className); // On-the-fly class resolution...
         Object obj = cl.getConstructor().newInstance();
         if (obj instanceof PostProcess) {
            PostProcess pp = (PostProcess)obj;
            pp.postProcess(pProcess, pResponse, pPathParams, pQueryParams);
         }
      }
      catch (ClassNotFoundException | NoSuchMethodException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
         throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
            .setMessage("Schema error - failed to process PostProcess class " + className)
            .setException(ex)
            .build());
      }
   }

   /**
    * Convert SQL templates into valid statements that can be executed against the database.
    *
    * @param pResource The web resource that is being queried.
    * @param pIDs List of ID values that are needed to build the query.
    * @return A group of executable query statements is returned.
    */

   private Map<String, RunQuery> buildSQL(ResourceType pResource, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      Map<String, RunQuery> queries = new LinkedHashMap<>();
      for (SqlType sqlTag : pResource.getSql()) {
         String sql = translateSQL(sqlTag.getValue(), pIDs, pParameters);
         String name = sqlTag.getName();
         String key = (name == null) ? "." + sqlTag.toString() : name;
         queries.put(key, new PostgresQuery(name, sql, sqlTag.getStore(), sqlTag.getSrc()));
      }
      return queries;
   }

   private String translateSQL(String pSQL, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      for (IDValue id : pIDs) {
         String paramReplace = "{param:" + id.id.getName() + "}";
         pSQL = pSQL.replace(paramReplace, escapeSQL(id.value));
      }
      for (Map.Entry<String, String> entry : pParameters.entrySet()) {
         String paramReplace = "{param:" + entry.getKey() + "}";
         pSQL = pSQL.replace(paramReplace, escapeSQL(entry.getValue()));
      }
      pSQL = pSQL.replace("{std:sort}", ""); // TODO: Sorting isn't supported yet.
      pSQL = pSQL.replace("{std:filter}", ""); // TODO: Filtering isn't supported yet.
    //  pSQL = pSQL.replace("{std:limit}", "LIMIT " + Integer.toString(recordLimit)); // TODO: If there's a limit parameter supplied with the URI, use that as the limit value.
      return pSQL;
   }

   /**
    * Extract the identifier values from the resource path so that we can use them in the SQL.  Note that it is a
    * requirement that the identifiers are listed in the order that they appear in the path.
    *
    * @param pPath The URI that was received from the client.  It contains the ID values to be extracted.
    * @param pResource The web resource that describes the identifiers.
    * @param pPattern The regex pattern that will be used to extract the ID values.
    * @return A list of extracted values is returned.
    */

   public ArrayList<IDValue> extractIdentifiers(String pPath, ResourceType pResource, Pattern pPattern) {
      // Process resources in the URI path.
      IdentifiersType ids = pResource.getIdentifiers();
      ArrayList<IDValue> idValues = new ArrayList<>();
      if (ids != null) {
         List<IdType> idList = ids.getId();
         Matcher m = pPattern.matcher(pPath);
         int i = 0;
         while (m.find()) {
            for (int g=1; g <= m.groupCount (); g++) {
               IdType id = idList.get(i++);
               String value = m.group(g);
               if (value.contains("%")) {
                  try {
                     value = URLDecoder.decode(value, "UTF-8");
                  }
                  catch (UnsupportedEncodingException ex) {
                     throw new WebApplicationException(ex);
                  }
               }

               String valueCase = id.getCase();
               if (valueCase != null) {
                  switch(valueCase) {
                     case "LOWER": value = value.toLowerCase(); break;
                     case "UPPER": value = value.toUpperCase(); break;
                  }
               }

               String pattern = id.getPattern(); // Optional - regex check on value.
               if (pattern != null) checkParameterValue(id.getName(), pattern, value);

               idValues.add(new IDValue(id, value));
            }
         }

         if (idList.size() != idValues.size()) {
            throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
               .setMessage("Expected to extract " + idList.size() + " identifiers from the path, got " + idValues.size())
               .build());
         }
      }
      return idValues;
   }

   /**
    * Process and validate query parameters.
    *
    * @param pResource  The resource that matched the URI request.
    * @param pRequest
    * @return
    */

   public Map<String, String> extractParameters(ResourceType pResource, HttpServletRequest pRequest) {
      Map<String, String> resultMap = new HashMap<>();
      ParametersType params = pResource.getParameters();
      if (params == null) return resultMap; // Return an empty map if there aren't any parameters for this interface.

      List<ParamType> plist = params.getParam();

      // Set any parameter defaults specified in the data schema.
      for (ParamType p : plist) {
         String def = p.getDef();
         if (def != null) resultMap.put(p.getName().toLowerCase(), def);
      }

      Map<String, String[]> parameterMap = sqlValidator.validate(pRequest.getParameterMap());
      for (Map.Entry<String, String[]> entry : parameterMap.entrySet()) {
         String pName = entry.getKey().toLowerCase();
         String[] pvalues = entry.getValue();
         boolean foundParameter = false;

         for (ParamType p : plist) {
            if (p.getName().toLowerCase().equals(pName)) {
               foundParameter = true;
               switch (p.getType()) { // TODO: Validate the type associated with the parameter.
                  case "INTEGER": break;
                  case "HEX": break;
                  case "STRING": break;
               }
               resultMap.put(pName, pvalues[0]);
               break;
            }
         }

         if (!foundParameter) {
            throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
               .setMessage("Parameter '" + pName + "' is unrecognised.")
               .build());
         }
      }

      return resultMap;
   }

   /**
    * Main function for controlling the execution of database queries and marshaling the results into
    * JSON/XML data suitable for returning to the client.
    *
    * @param pPath        The URI requested by the client.
    * @param pResource    The resource that matched the URI request.
    * @param pPattern     The pattern that matched the requested pPath to the pResource
    * @param pPathParams  Path parameters received from the client.
    * @param pQueryParams Query parameters received from the client.
    * @return
    */

   private Response execResource(HttpServletRequest pRequest, String pPath, ResourceType pResource, Pattern pPattern, ArrayList<IDValue> pPathParams, Map<String, String> pQueryParams) {
      if (pResource.getDatafeed() != null) {
         return execDataFeed(pRequest, pResource, pPathParams, pQueryParams);
      }
      else if (pResource.getSql() != null) {
         Map<String, RunQuery> queries = buildSQL(pResource, pPathParams, pQueryParams);
         JsonNode jsResult = execQueries(pResource, queries, pPathParams, pQueryParams);

         if ((jsResult == null) || (jsResult.size() == 0)) {
            return noResults(pResource, pPathParams, pQueryParams);
         }

         return WebAssist.configureResponse(pResource, Response.ok(jsResult)).build();
      }
      else {
         return ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                             .setMessage("Schema error - no SQL queries defined for this interface.").build();
      }
   }

   /**
    * This method is called when there are no results in the database to be returned to the client.
    *
    * If a PostProcess class is referenced in the schema, call the PostProcess.noResults() method in case there is any
    * custom code that needs to be run when no results are found.
    *
    * @param pResource    The resource that matched the URI request.
    * @param pPathParams  Path parameters received from the client.
    * @param pQueryParams Query parameters received from the client.
    * @return
    */

   private Response noResults(ResourceType pResource, ArrayList<IDValue> pPathParams, Map<String, String> pQueryParams) {
      PostprocessType pp = pResource.getPostprocess();
      if (pp != null) {
         String className = pp.getClazz();
         if (className == null) throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR).build());

         try {
            Object obj = Class.forName(className).getConstructor().newInstance();
            if (obj instanceof PostProcess) {
               ResponseBuilder rb = (((PostProcess)obj).noResults(pPathParams, pQueryParams));
               if (rb != null) return WebAssist.configureResponse(pResource, rb).build();
            }
         }
         catch (ClassNotFoundException | NoSuchMethodException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
               .setMessage("Schema error - failed to configure PostProcess class " + className)
               .setException(ex)
               .build());
         }
      }

      LOG.debug("Empty result from database.");
      return ErrorResponse.status(Status.NOT_FOUND).setMessage("The requested resource was not found.").build();
   }

   /**
    *
    * @param pResource  The resource that matched the URI request.
    * @param pIDS
    * @return
    */

   private Response execDataFeed(HttpServletRequest pRequest, ResourceType pResource, ArrayList<IDValue> pIDS, Map<String, String> pParameters) {
      DatafeedType df = pResource.getDatafeed();
      if (df != null) {
         try {
            Class cl = Class.forName(df.getClazz()); // On-the-fly class resolution...
            Object obj = cl.getConstructor().newInstance();
            if (obj instanceof DataFeed) {
               DataFeed dataFeed = (DataFeed)obj;
               return dataFeed.query(pRequest, pIDS, pParameters);
            }
         }
         catch (ClassNotFoundException | NoSuchMethodException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | IOException ex) {
            return ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
               .setMessage("Schema error - failed to process DataFeed class " + df.getClazz())
               .setException(ex)
               .build();
         }
      }
      else {
         return ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
            .setMessage("Internal schema error - there are no queries defined for this interface.")
            .build();
      }
      return null;
   }

   /**
    * Execute queries.  Failures here are considered internal (500) and must propagate to the admin.
    *
    * @param pResource  The resource that matched the URI request.
    * @param pQueries
    * @return
    */

   private JsonNode execQueries(ResourceType pResource, Map<String, RunQuery> pQueries, ArrayList<IDValue> pPathParams, Map<String, String> pQueryParams) {
      boolean sqlResults = false;

      for (RunQuery query : pQueries.values()) {
         String sql = query.sql;

         // Throw a trantrum if there are parameters that are unconverted.

         if (sql.contains("{param:")) {
            sql = translateSQL(sql, pPathParams, pQueryParams);

            if (sql.contains("{param:")) {
               LOG.info("Invalid SQL: " + sql);
               throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
                  .setMessage("Some of the required parameters were not provided.  Please check the API documentation.")
                  .build());
            }
         }

         //LOG.debug("Executing " + query.src + " statement: " + sql);

         sqlResults = true;
         ObjectNode jsRoot = jsFactory.objectNode();

         try (Connection con = PostgresClient.pool.getConnection()) {
            try (ResultSet rst = con.createStatement().executeQuery(sql)) {
               ArrayNode jsArray = jsFactory.arrayNode();
               //int limit = recordLimit;

               int totalColumns = rst.getMetaData().getColumnCount();
               ResultSetMetaData cols = rst.getMetaData();

               List<FieldType> fields = pResource.getResult().getField();
        //       while ((--limit >= 0) && (rst.next())) {
               while ( (rst.next())) {
                  ObjectNode output = jsFactory.objectNode();
                  for (FieldType field : fields) {
                     String sqlSource = field.getSql();
                     if ((sqlSource == null) || (sqlSource.equals(query.name))) {
                        SQLMap.outputField(cols, field, rst, output);
                     }
                  }
                  jsArray.add(output);
               }

               if (jsArray.size() > 1) {
             //     if (limit <= 0) {
                     jsRoot.put("offsetKey", (String)null); // Define this if the results are offset from a particular record ID.
                     jsRoot.put("moreRecords", rst.next());
               //   }
                  jsRoot.put("totalRecords", jsArray.size());
                  jsRoot.set("results", jsArray);
               }
               else if (jsArray.size() == 1) jsRoot.setAll((ObjectNode)jsArray.get(0));

               return (JsonNode)jsRoot;
            }
         }
         catch (SQLException ex) {
             LOG.warn(ex);
             throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
               .setMessage("Internal database failure during query process.")
               .setException(ex)
               .build());
         }
      }


      throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
         .setMessage("The configuration of this REST interface is not defined correctly.")
         .build());
   }

   /**
    * Called during server initialisation or refresh, this code processes the resources declared under the '/data' interface.
    *
    * Regarding validation, the XSD file is the right place to set the validation rules, particularly as it will
    * indicate the line number and column that the error occurred.
    *
    * @param pConfig
    * @param pInterface The interface that is being registered
    * @param pServiceXML The service that is being parsed (root-level POJO)
    */

   @Override
   public void parseInterface(com.elsevier.epic.core.ServerConfig pConfig, InterfaceType pInterface, Webservice pServiceXML) {
      refreshInterface(pInterface, pServiceXML);
   }

   @Override
   public void refreshInterface(InterfaceType pInterface, Webservice pServiceXML) {
      Map<Pattern, DataResource> newResources = new LinkedHashMap<>();

      List<ResourceType> reslist = pInterface.getResource();
      for (ResourceType res : reslist) {
         String resPath = res.getPath();
         IdentifiersType ids = res.getIdentifiers();

         if (!("GET".equals(res.getMethod()))) {
            throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
               .setMessage("Only GET methods can be used by /data resources.")
               .build());
         }

         // Convert the path to a regex pattern, as we will use patterns to match incoming calls.

         if (ids != null) {
            if (!resPath.matches(".+\\{\\w+\\}.*")) {
               throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                  .setMessage("Resource " + resPath + " declares identifiers that the path does not reference.")
                  .build());
            }

            String regex = (this.interfacePath + resPath).replace("/", "\\/");

            for (IdType id : ids.getId()) {
               String match;
               String idPattern = id.getPattern();

               if (idPattern != null) { // Always prefer the customised pattern in the data model.
                  match = "(" + idPattern + ")";
               }
               else {
                  switch (id.getType().toUpperCase()) {
                     case "INTEGER": match = "(\\-?[0-9]+)"; break;
                     case "HEX":     match = "([0-9A-Za-z]+)"; break;
                     case "STRING":  match = "(.+)"; break;
                     default:        match = "(.+)";
                  }
               }

               regex = regex.replace("{" + id.getName() + "}", match);
            }

            LOG.debug("Resource '" + resPath + "' resolves to pattern " + regex);
            newResources.put(Pattern.compile(regex), new DataResource(res));
         }
         else {
            LOG.debug("Resource '" + resPath + "' registered.");
            newResources.put(Pattern.compile(Pattern.quote(this.interfacePath + resPath)), new DataResource(res));
         }
      }

      this.resources = newResources;
   }

   private static void checkParameterValue(String name, String regex, String value) {
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(value);
      if (!matcher.matches()) {
         throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
            .setMessage("Value for '" + name + "' of '" + value + "' does not match required pattern '" + regex + "'")
            .build());
      }
   }

   private String escapeSQL(String pSQL) {
      return pSQL.replace("'", "''");
   }
}
