package com.elsevier.epic;

import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.scival.SVLastUpdate;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.scival.SciVal;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.Scanner;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import static org.apache.commons.lang3.math.NumberUtils.toInt;

public class LastUpdate implements DataFeed {
   static private final Logger LOG = Log.getLogger(LastUpdate.class);
   static private final JsonNodeFactory jsFactory = new JsonNodeFactory(false);
   static private final long UPDATE_FREQUENCY = 1000 * 60 * 60;
   static ObjectNode jsUpdates = null;
   static long lastUpdate = 0;

   static final SimpleDateFormat sdfLong = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
   //static final SimpleDateFormat sdfShort = new SimpleDateFormat("yyyy-MM-dd");
   //static final SimpleDateFormat sdfShortYear = new SimpleDateFormat("yyyy");

   static {
      sdfLong.setTimeZone(TimeZone.getTimeZone("UTC"));
     // sdfShort.setTimeZone(TimeZone.getTimeZone("UTC"));
     // sdfShortYear.setTimeZone(TimeZone.getTimeZone("UTC"));
   }

   /**
    *
    * @return Returns a map of updated tables and the time they were last updated.
    * @throws SQLException
    */

   static public ObjectNode getUpdates() {
      if (jsUpdates == null || (System.currentTimeMillis() - lastUpdate) > UPDATE_FREQUENCY) {
         try (Connection con = PostgresClient.getConnection()) {
            try (PreparedStatement ps = con.prepareStatement(getResourceString("/select_latest_audit.sql"))) {
               try (ResultSet rst = ps.executeQuery()) {
                  final Map<String, Long> mapUpdates = new ConcurrentHashMap<>();
                  while (rst.next()) {
                     java.sql.Timestamp importDate = rst.getTimestamp(2);
                     java.sql.Timestamp sourceDate = rst.getTimestamp(3);
                     mapUpdates.put(rst.getString(1), (sourceDate != null) ? sourceDate.getTime() : importDate.getTime());
                  }

                  jsUpdates = new JsonNodeFactory(false).objectNode();
                  jsUpdates.put("recommender", outputTimestamp(mapUpdates.get("recommender")));
                  jsUpdates.put("articles", outputTimestamp(mapUpdates.get("sdarticle_p")));
                  jsUpdates.put("topArticlesWeekly", outputTimestamp(mapUpdates.get("top_articles_weekly")));
                  // keeping this hacked until we do scopus usage metricdata available.
                  // https://scival.atlassian.net/browse/EPIC-3753
                  jsUpdates.put("counter", "2019-03-01 00:00:00");
                  jsUpdates.put("sccontent_journal_demand_inst", outputTimestamp(mapUpdates.get("sccontent_journal_demand_inst")));
               }
            }
            int sccontent_complete_year = 0;
            final int sccontent_complete_year_fallback = 2020;
            LOG.info("Starting sccontent complete year fetch");
            try (final ResultSet rs = con.createStatement().executeQuery(
                    "select value from sccontent_metadata where name = 'sccontent_source_complete_year'")){
               LOG.info("Trying to get value from DB.");
               if(rs.next()){
                  LOG.info("Getting value from DB.");
                  sccontent_complete_year = toInt(rs.getString("value"));
                  LOG.info("Value from DB: {}", sccontent_complete_year);
               }
            }
            catch (SQLException ex) {
               LOG.warn(ex);
               throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
                                                              .setMessage("Internal database failure during query process.")
                                                              .setException(ex)
                                                              .build());
            }
            finally {
               jsUpdates.put("sccontent_source_complete_year",
                             sccontent_complete_year == 0 ? sccontent_complete_year_fallback : sccontent_complete_year);
               LOG.info("sccontent_source_complete_year: {}", jsUpdates.get("sccontent_source_complete_year"));
               lastUpdate = System.currentTimeMillis();
            }
         }
         catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
               .setMessage("A database server connection failure has occurred.")
               .setException(ex)
               .build());
         }

         // The SciVal 'last update' is special - we need to call the SciVal API to get that value.

         try {
            SVLastUpdate lu = SciVal.getLastUpdate();
            jsUpdates.put("scival", outputTimestamp(lu.lastUpdated));
            // yearRangeYear is passed to the front end to do their year range calculations
            // to understand its meaning, speak to SciVal team. We talked about doing the 
            // business calculation here, but we are giving it to front end to do (in case there is
            // a front end change
            jsUpdates.put("scivalYearRangeYear", lu.yearRangeYear);
         }
         catch (ParseException | IOException | WebApplicationException ex) {
            // If data retrieval from SciVal fails, set the SciVal field to null in order to indicate a failure for
            // that particular data source.
            jsUpdates.put("scival", (String)null);
                        jsUpdates.put("scival", (String)null);

         }
      }

      return jsUpdates;
   }

   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      String resource = null;
      if ((pIDs != null) && (pIDs.size() >= 1)) resource = pIDs.get(0).value;

      if ((resource == null) || (resource.isEmpty())) { // No resource specified - show all.
         return Response.ok(getUpdates()).build();
      }
      else { // Specific resource specified - return just that one.
         ObjectNode jsRoot = jsFactory.objectNode();
         jsRoot.put("resource", resource);
         jsRoot.put("lastUpdate", getUpdates().path(resource).asText(null));
         return Response.ok(jsRoot).build();
      }
   }

   static private String getResourceString(String pName) {
      // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
      // all available resource files.
      InputStream isResource = String.class.getResourceAsStream(pName);
      if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
      else throw new RuntimeException("Could not find resource '" + pName + "'");
   }

   static public String outputTimestamp(Long pTimestamp) {
      if (pTimestamp == null) return null;
      return sdfLong.format(new Date(pTimestamp));
   }
}
