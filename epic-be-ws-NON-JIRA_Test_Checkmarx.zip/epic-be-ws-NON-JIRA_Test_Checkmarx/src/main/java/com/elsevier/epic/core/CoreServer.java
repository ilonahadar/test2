/*
Main entry point for the universal web service.

The initialisation process is primarily handled by DropWizard and the ServiceBuilder class.

*/

package com.elsevier.epic.core;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.health.HealthCheck;
import com.elsevier.epic.types.DataSource;
import com.elsevier.epic.email.EmailServer;
import com.elsevier.epic.exceptions.AppException;
import com.elsevier.epic.exceptions.RuntimeExceptionMapper;
import com.elsevier.epic.exceptions.WebAppExceptionMapper;
import com.elsevier.epic.scival.SVInstitute;
import io.dropwizard.Application;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.lifecycle.Managed;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;
import org.reflections.Reflections;

import java.util.Set;

public class CoreServer extends Application<ServerConfig> {
   private static final Logger LOG = Log.getLogger(CoreServer.class);
   static public MetricRegistry metrics = null;
   public static String extServerAddress = null;
   public static Reflections reflections = null;
   public static ServerConfig config = null;
   public static EmailServer emailServer = null;

   public static void main(String[] args) throws Exception {
      new CoreServer().run(args);
   }

   @Override
   public String getName() {
      return "webservice";
   }

   @Override
   public void initialize(Bootstrap<ServerConfig> pBootstrap) {
      pBootstrap
              .setConfigurationSourceProvider(new SubstitutingSourceProvider(pBootstrap.getConfigurationSourceProvider(),
                                                                               new EnvironmentVariableSubstitutor(false)));
   }

   // NB: If you would like to add new configuration parameters to the YAML file, you must modify
   // the ServerConfig class to support them.

   @Override
   public void run(ServerConfig pConfig, Environment pEnv) throws AppException {
      LOG.info("Configuring environment");

      pEnv.jersey().register(new WebAppExceptionMapper());
      pEnv.jersey().register(new RuntimeExceptionMapper());

      if (pConfig.getEnvironment().equals("prod")) production = true;

      CoreServer.config = pConfig;
      CoreServer.metrics = pEnv.metrics();
      CoreServer.extServerAddress = pConfig.getExtServerAddress();

      try {
         if (EmailServer.configured()) {
            CoreServer.emailServer = new EmailServer();
         }
      }
      catch (Exception e) {
         LOG.warn("Failed to configure an email server.  The web service will run without support for outgoing email.", e);
      }

      reflections = new Reflections("com.elsevier");

      initDataSources(pConfig, pEnv);
      initWebService(pConfig, pEnv);
      initHealthChecks(pEnv);
      SVInstitute.generateCache(true, false);
   }

   /**
    * Initialise all DataSource classes.
    */

   private void initDataSources(ServerConfig pConfig, Environment pEnv) {
      Set<Class<? extends DataSource>> dataSources = reflections.getSubTypesOf(DataSource.class);
      for (Class<? extends DataSource> cl : dataSources) {
         try {
            DataSource ds = cl.newInstance();
            ds.init(pConfig, pEnv);
            pEnv.lifecycle().manage((Managed)ds);
         }
         catch (InstantiationException | IllegalAccessException ex) {
            throw new AppException("Failed to instantiate data source '" + cl.getName() + "'", ex);
         }
      }
   }

   /**
    * Initialise all HealthCheck classes
    */

   private void initHealthChecks(Environment pEnv) {
      Set<Class<? extends HealthCheck>> healthChecks = reflections.getSubTypesOf(HealthCheck.class);
      for (Class<? extends HealthCheck> cl : healthChecks) {
         try {
            HealthCheck hc = cl.newInstance();
            pEnv.healthChecks().register(cl.getName(), hc);
         }
         catch (InstantiationException | IllegalAccessException ex) {
            throw new AppException("Failed to instantiate health check class '" + cl.getName() + "'", ex);
         }
      }
   }

   /**
    * Use the ServiceBuilder class to create the web service RESTful end points.
    */

   private void initWebService(ServerConfig pConfig, Environment pEnv) {
      ServiceBuilder.buildService(pConfig, pEnv);
   }

   /**
    * Returns true if the server is running in a production environment.
    *
    * @return True or false
    */

   static public boolean isProduction() {
      return production;
   }

   private static boolean production = false;
}
