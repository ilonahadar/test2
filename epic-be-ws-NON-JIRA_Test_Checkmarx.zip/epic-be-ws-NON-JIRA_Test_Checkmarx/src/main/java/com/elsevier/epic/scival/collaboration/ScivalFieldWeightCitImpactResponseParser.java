package com.elsevier.epic.scival.collaboration;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

/**
 * Created by greend on 14/04/2016.
 */
public class ScivalFieldWeightCitImpactResponseParser {
    public final float value;

    public ScivalFieldWeightCitImpactResponseParser(String json) {
        JsonObject fwciJsonObject = new JsonParser().parse(json).getAsJsonArray().get(0).getAsJsonObject();
        try {
            value = fwciJsonObject.get("value").getAsFloat();
        } catch (NullPointerException e) {
            throw new JsonSyntaxException("Scival Fwci impact endpoint returned unrecognised json");
        }
    }
}
