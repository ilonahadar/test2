package com.elsevier.epic.core;

public class Country {
   public int code;
   public String name;
   public String two;
   public String three;
   
   public Country(String pName, String pTwo, String pThree, int pCode) {
      this.name  = pName;
      this.two   = pTwo;
      this.three = pThree;
      this.code  = pCode;
   }
}
