package com.elsevier.epic.auth;

import com.elsevier.epic.core.ServerConfig;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface AuthClient {
   public int authenticate(HttpServletResponse hr, HttpServletRequest httpRequest, String authHeader);
   public void init(ServerConfig pConfig);
}
