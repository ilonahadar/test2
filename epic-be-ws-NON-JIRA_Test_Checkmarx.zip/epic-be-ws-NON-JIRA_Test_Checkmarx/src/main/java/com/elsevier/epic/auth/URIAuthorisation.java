package com.elsevier.epic.auth;

import com.elsevier.epic.types.IDValue;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;

public interface URIAuthorisation {
   public void authorise(HttpServletRequest pRequest, ArrayList<IDValue> pIDs);
}
