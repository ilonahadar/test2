package com.elsevier.epic.scival.collaboration;

public class UnknownAccountException extends Exception {
    public UnknownAccountException(int accountId) {
        super(String.format("Unknown account %d", accountId));
    }
}
