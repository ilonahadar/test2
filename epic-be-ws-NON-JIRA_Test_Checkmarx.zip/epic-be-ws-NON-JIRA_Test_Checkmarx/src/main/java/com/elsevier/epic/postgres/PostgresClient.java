package com.elsevier.epic.postgres;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ServerConfig;
import com.elsevier.epic.core.ServiceBuilder;
import com.elsevier.epic.exceptions.AppException;
import com.elsevier.epic.jaxb.InterfaceType;
import com.elsevier.epic.jaxb.ResourceType;
import com.elsevier.epic.types.DataSource;
import com.elsevier.epic.utility.SDJournals;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import io.dropwizard.lifecycle.Managed;
import io.dropwizard.setup.Environment;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;
import org.skife.jdbi.v2.DBI;
import org.skife.jdbi.v2.tweak.ConnectionFactory;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

public class PostgresClient implements Managed, DataSource {
    private static final Logger LOG = Log.getLogger(PostgresClient.class);
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe
    private static PostgresClient instance = null;
    static ComboPooledDataSource pool;
    static DBI dbi;

    Environment env;
    String server;
    String schema;
    String user;
    String password;
    int connectTimeout;
    int queryTimeout;
    int loginTimeout;
    boolean doWarmup;

    public PostgresClient() { }

    public static PostgresClient getInstance() {
        if (instance == null) {
            instance = new PostgresClient();
        }
        return instance;
    }

    /**
     * @deprecated use non-static method
     */
    static public Connection getConnection() throws SQLException {
        Connection con = pool.getConnection();
        con.setReadOnly(true);
        return con;
    }

    public Connection getConnectionPool() throws SQLException {
        Connection con = pool.getConnection();
        con.setReadOnly(true);
        return con;
    }

    static public Connection getConnectionTempTable() throws SQLException {
        Connection con = pool.getConnection();
        return con;
    }

    static public DBI getDBI() {
        return dbi;
    }

    public DBI getDatabaseClient() {
        return dbi;
    }

    /**
     * Interfaces in the schema can define 'warm-up' SQL clauses that
     *
     * @param pConfig
     * @param pEnv
     */

    static void warmup() {
        LOG.info("Running warmup statements...");
        try (Connection con = getConnection()) {
            for (InterfaceType in : ServiceBuilder.getServiceXML().getInterface()) {
                for (ResourceType res : in.getResource()) {
                    String warmup = res.getWarmup();
                    if (warmup != null) {
                        LOG.info(warmup);
                        try (PreparedStatement ps = con.prepareStatement(warmup)) {
                            try (ResultSet rst = ps.executeQuery()) {
                                for (int c = 0; (c < 1000) && (rst.next()); c++);
                            }
                        } catch (SQLException ex) {
                            LOG.warn("Warmup statement failed: " + warmup);
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            LOG.warn(ex);
            throw new AppException("Failed to open connection to Postgres database.");
        }
    }

    @Override
    public void init(ServerConfig pConfig, Environment pEnv) {

        if (instance == null) {

            String ps = pConfig.getPostgresServer();
            if (ps != null) {
                instance = this;

                this.env = pEnv;
                this.server = ps;
                this.doWarmup = pConfig.getWarmup();
                this.schema = pConfig.getPostgresSchema();
                this.user = pConfig.getPostgresUser();
                this.password = pConfig.getPostgresPassword();
                // Note that a timeout of '0' is allowed and informs the driver that no timeout is applicable.
                this.connectTimeout = pConfig.getDBConnectTimeout();
                this.loginTimeout = pConfig.getDBLoginTimeout();
                this.queryTimeout = pConfig.getDBQueryTimeout();

                PostgresClient.dbi = new DBI(new ConnectionFactory() {
                    @Override
                    public Connection openConnection() throws SQLException {
                        return PostgresClient.getConnection();
                    }
                });
            } else {
                throw new AppException("Postgres driver requires configuration in the server YAML file.");
            }
        } else {
            throw new AppException("Attempt to re-initialise the Postgres driver detected.");
        }
    }

    @Override
    public void start() throws Exception {
        LOG.info("Connecting to Postgres server: " + server + ", schema '" + schema + "' as user '" + user + "'");

        if (PostgresClient.pool == null) {
            int port = 5432;

            if (Proxy.proxyRequired()) {
                Proxy.connect(server, port, 54320);
                server = "127.0.0.1";
                port = 54320;
            }

            pool = new ComboPooledDataSource();
            pool.setDriverClass("org.postgresql.Driver"); //loads the jdbc driver
            pool.setAcquireRetryAttempts(
                    10); // Maximum retry attempts before failing (keep in mind the typical user's patience levels before they hit the refresh button!)
            pool.setAcquireRetryDelay(2); // Retry latency of 2 seconds between attempts
            pool.setInitialPoolSize(5);
            pool.setAcquireIncrement(5);
            pool.setMinPoolSize(5);
            pool.setMaxPoolSize(80);
            pool.setMaxIdleTime(900); // Terminate unused connections after N seconds have passed
            pool.setMaxIdleTimeExcessConnections(50);

            pool.setJdbcUrl("jdbc:postgresql://" + server + ":" + port + "/" + schema);
            pool.setAutoCommitOnClose(false);
            pool.setCheckoutTimeout(60 * 1000); // Max time to wait before a connection attempt fails.
            pool.setUser(user);
            pool.setPassword(password);

            if (doWarmup) {
                warmup();
            }

            SDJournals.getInstance().initialiseAll();
        }
    }

    @Override
    public void stop() throws Exception {
        pool.close();
        pool = null;
    }

    /**
     * Convert months in a Postgres HStore field to a JSON int array of 12 months.
     *
     * @param hMonths
     * @return
     */

    static public ArrayNode hsMonthsToJson(Map<String, String> hMonths) {
        if (hMonths == null) {
            return jsFactory.arrayNode();
        }

        ArrayNode jsMonths = jsFactory.arrayNode();
        int[] output = new int[12];
        for (Map.Entry<String, String> entry : hMonths.entrySet()) {
            output[readInt(entry.getKey()) - 1] += readInt(entry.getValue());
        }
        for (int o : output) {
            jsMonths.add(o);
        }
        return jsMonths;
    }

    /**
     * Convert a string to an integer, with no chance of throwing an exception (returns 0 on parsing errors).
     *
     * @param str
     * @return
     */

    static private int readInt(String str) {
        if ((str == null) || (str.isEmpty())) {
            return 0;
        }
        try {
            return Integer.parseInt(str);
        } catch (Exception e) {
            return 0;
        }
    }

    public static class Proxy {
        final static org.slf4j.Logger LOG = LoggerFactory.getLogger(Proxy.class);
        static public com.jcraft.jsch.Session jSession = null;

        static private class LoggerProxy implements com.jcraft.jsch.Logger { // For JSch
            @Override
            public boolean isEnabled(int level) {
                return true;
            }

            @Override
            public void log(int level, String message) {
                String levelStr;
                switch (level) {
                    case INFO:
                        LOG.info(message);
                        break;
                    case WARN:
                        LOG.warn(message);
                        break;
                    case ERROR:
                        LOG.error(message);
                        break;
                    case FATAL:
                        LOG.error(message);
                        break;
                    case DEBUG:
                    default:
                        LOG.debug(message);
                        break;
                }
            }
        }

        /**
         * Returns true if the user has configured proxy settings.
         *
         * @return
         */

        static public boolean proxyRequired() {
            String proxyHost = CoreServer.config.getProxyHost();

            if ((proxyHost != null) && (!proxyHost.isEmpty())) {
                return true;
            }
            return false;
        }

        /**
         * Setup a SOCKS connection to a remote machine's port.
         *
         * @param pRemoteHost The name or IP address of the remote machine.
         * @param pRemotePort The target port of the remote machine.
         * @param pLocalPort  The local port to use for connecting to the remote machine.
         * @throws AppException
         */

        static public void connect(String pRemoteHost, int pRemotePort, int pLocalPort) throws AppException {
            LOG.info("Proxy connection requested for " + pRemoteHost + ":" + pRemotePort);

            try {
                if (jSession != null) {
                    jSession.setPortForwardingL(pLocalPort, pRemoteHost, pRemotePort);
                } else {
                    String proxyUser = CoreServer.config.getProxyUser();
                    String proxyHost = CoreServer.config.getProxyHost();
                    String proxyPassword = CoreServer.config.getProxyPassword();
                    String proxyKeyFile = CoreServer.config.getProxyKeyFile();
                    int aliveInterval = CoreServer.config.getProxyAliveInterval();

                    JSch jsch = new JSch();
                    JSch.setLogger(new LoggerProxy());

                    if (proxyPassword != null) {
                        jsch.addIdentity(proxyKeyFile, proxyPassword);
                    } else {
                        jsch.addIdentity(proxyKeyFile);
                    }

                    jSession = jsch.getSession(proxyUser, proxyHost, 22);
                    jSession.setConfig("StrictHostKeyChecking", "no");
                    jSession.setConfig("PreferredAuthentications", "publickey");
                    jSession.setConfig("ConnectTimeout", "5000");
                    if (aliveInterval > 0) {
                        jSession.setServerAliveInterval(aliveInterval);
                    }
                    jSession.connect(5000);

                    jSession.setPortForwardingL(pLocalPort, pRemoteHost, pRemotePort);
                }
            } catch (JSchException e) {
                if (jSession != null) {
                    jSession.disconnect();
                    jSession = null;
                }
                throw new AppException("Failed to connect to proxy.", e);
            }
        }
    }
}
