package com.elsevier.epic.scival;

import com.elsevier.epic.Server;
import static com.elsevier.epic.scival.SciVal.requestContent;
import static com.elsevier.epic.scival.SciVal.svClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

public class SVInstitute {
   static private final Logger LOG = Log.getLogger(com.elsevier.epic.scival.SVInstitute.class);
   static long recacheTime = System.currentTimeMillis();

   public int id;
   public String sector;
   public String name;
   public int countryID;
   public int affiliationCount;
   public double latitude;
   public double longitude;

   private static final Map<Integer, SVInstitute> svInst = new ConcurrentHashMap<>();

   public SVInstitute() { }

   static public void generateCache(boolean pBackground, final boolean pInternal) {
      recacheTime = System.currentTimeMillis() + (60 * 60 * 1000); // Throttle recache attempts to once an hour

      if (pBackground) {
         // Building the institution cache can take 20 seconds, so it's best done in a thread.

         Thread svThread = new Thread(new Runnable() {
             @Override
             public void run(){
                cache(pInternal);
            }
         });

         svThread.start();
      }
      else cache(pInternal);
   }

   static private synchronized void cache(boolean pInternal) {
      final String site = Server.config.getSVSite();
      final String uri = "https://" + site + "/api/Institution";

      try {
         JsonNode jsMap;

         if (pInternal) {
            jsMap = new ObjectMapper().readTree(getResourceString("/sv_institutes.json"));
         }
         else {
            try {
               jsMap = new ObjectMapper().readTree(requestContent(svClient().target(uri)));
            }
            catch (Exception ex) { // Fall-back to the internally saved version as a last resort
               if (svInst.isEmpty()) {
                  jsMap = new ObjectMapper().readTree(getResourceString("/sv_institutes.json"));
               }
               else return;
            }
         }

         if (jsMap.isArray()) {
            Iterator<JsonNode> itDetails = jsMap.elements();
            while (itDetails.hasNext()) {
               SVInstitute inst = new SVInstitute();
               JsonNode jsDetail = itDetails.next();
               //inst.uri          = jsDetail.get("uri");
               inst.id           = jsDetail.path("id").asInt(0);
               inst.name         = jsDetail.get("name").asText(null);
               inst.countryID    = jsDetail.get("countryId").asInt();
               inst.sector       = jsDetail.get("sector").asText(null);
               inst.latitude     = jsDetail.get("latitude").asDouble();
               inst.longitude    = jsDetail.get("longitude").asDouble();
               inst.affiliationCount = jsDetail.get("affilCnt").asInt();
               if (inst.id != 0) svInst.put(inst.id, inst);
            }
         }
         else LOG.warn("Institutional information from SciVal is not in expected format.");
      }
      catch (IOException ex) {
         LOG.warn("Failed to acquire institutional information from SciVal.", ex);
      }

      recacheTime = System.currentTimeMillis() + (8 * 60 * 60 * 1000); // Every 8 hours is enough

      LOG.info("SV institution cache is ready.");
   }

   static public SVInstitute getSVInstitute(Integer pID) {
      if (pID == null) return null;
      if (System.currentTimeMillis() >= recacheTime) generateCache(true, false);
      return svInst.get(pID);
   }

   static private String getResourceString(String pName) {
      // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
      // all available resource files.
      InputStream isResource = String.class.getResourceAsStream(pName);
      if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
      else throw new RuntimeException("Could not find resource '" + pName + "'");
   }
}
