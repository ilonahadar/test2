// Helper code for evs country code services

package com.elsevier.epic.utility;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;

import com.elsevier.epic.postgres.PostgresClient;


import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;


import javax.ws.rs.WebApplicationException;

import javax.ws.rs.core.Response.Status;

import java.sql.*;

public class CountryCode{
   private static final Logger LOG = Log.getLogger(CountryCode.class);




   static PreparedStatement getMetricsStatement(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement("select  numeric_code from country_code where alpha_code=?");
        ps.setQueryTimeout(60);
        return ps;
    }
    public static int getNumericCountryCode(String alphacode){
   int numericCountryCode=-1;

    try(Connection con = PostgresClient.getConnection();
        PreparedStatement ps = getMetricsStatement(con)){

        ps.setQueryTimeout(60);
        ps.setString(1, alphacode);
        if (!CoreServer.isProduction()) LOG.info(ps.toString());
        //ps.execute();
        try (ResultSet rst = ps.executeQuery()){
            while (rst.next()) {
                numericCountryCode= rst.getInt(1);

            }
        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }

    }
     catch (SQLException ex) {
                LOG.warn(ex);
                throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                        .setMessage("A server database failure has occurred.")
                        .setException(ex)
                        .build());
            }

    return numericCountryCode;
    }

}
