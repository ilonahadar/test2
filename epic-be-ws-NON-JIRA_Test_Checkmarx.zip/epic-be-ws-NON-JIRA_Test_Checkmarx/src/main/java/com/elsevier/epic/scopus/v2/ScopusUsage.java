// Support for scopus usage v3/account/[inst id]/sc/usage

package com.elsevier.epic.scopus.v2;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.utility.Utility;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.io.InputStream;
import java.sql.*;
import java.util.*;

public class ScopusUsage implements DataFeed {
   private static final Logger LOG = Log.getLogger(ScopusUsage.class);
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe

   static final int MIN_YEAR = 2014;

   PreparedStatement getStatement(Connection con) throws SQLException {
      PreparedStatement ps = con.prepareStatement(getResourceString("/scopus_usagev2.sql"));
      ps.setQueryTimeout(60);
      return ps;
   }

   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      if (pIDs.size() < 1) throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);

      String paramAccount  = pIDs.get(0).value;

      String paramReport;
      paramReport = "SUM";

      String paramYearStart  = pParameters.get("yearstart");
      String paramYearEnd    = pParameters.get("yearend");
      String paramDepartmentId    = pParameters.get("departmentid");
      String childAccounId  = pParameters.get("childaccountid");
      if (childAccounId == null)
         childAccounId =paramAccount;
      else
         childAccounId=childAccounId.replace("ECR","");

      int accountID;
      try { accountID = Integer.parseInt(childAccounId); }
      catch (NumberFormatException ex) {
         throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
            .setMessage("Invalid ID '" + childAccounId + "'")
            .setException(ex)
            .build());
      }

      ObjectNode jsRoot = jsFactory.objectNode();
      ObjectNode jsParams = jsFactory.objectNode();
      jsRoot.set("parameters", jsParams);
      jsParams.put("id", paramAccount)
              .put("report", paramReport.toUpperCase());

      if (paramYearStart != null) jsParams.put("yearStart", paramYearStart);
      if (paramYearEnd != null) jsParams.put("yearEnd", paramYearEnd);

      int ys = Utility.readInt(paramYearStart);
      final int yearEnd;
      int y = Utility.readInt(paramYearEnd);

      Calendar cal = Calendar.getInstance();
      int currentYear = cal.get(Calendar.YEAR);
      yearEnd = (y <= 0) ? currentYear : y;

      if (ys > currentYear) {
         return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid year parameter " + ys).build();
      }

      if ((ys < 0) || (ys > yearEnd)) {
         return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid year parameters " + ys + " to " + yearEnd).build();
      }

      final int yearStart = (ys < MIN_YEAR) ? MIN_YEAR : ys;

      int departmentId = Utility.readInt(paramDepartmentId);
      queryCounter(jsRoot, accountID, paramReport, yearStart, yearEnd,departmentId);
      return Response.ok(jsRoot).build();
   }

   private void queryCounter(ObjectNode pResult, int pSIS, String pReport, int pYearStart, int pYearEnd,int pDepartmentId) {
      try (Connection con = PostgresClient.getConnection();
           PreparedStatement ps = getStatement(con)) {
         ps.setQueryTimeout(60);
         ps.setInt(1, pSIS);
         ps.setInt(2, pDepartmentId);
         ps.setInt(3, pYearStart);
         ps.setInt(4, pYearEnd);
         ps.setInt(5, pSIS);
         ps.setInt(6, pSIS);

         if (!CoreServer.isProduction()) LOG.info(ps.toString());

         ObjectNode jsUsage = jsFactory.objectNode();

         ps.execute();
         processUsageResultSet(ps, jsUsage);
         processSubjectPrevYearResultSet(ps, pResult);
         processSubjectPrevYearResultSet_v2(ps, pResult);
         pResult.set("usage", jsUsage);
      }
      catch (SQLException ex) {
         LOG.warn(ex);
         throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
            .setMessage("A server database failure has occurred.")
            .setException(ex)
            .build());
      }
   }

   static private void processUsageResultSet(PreparedStatement ps, ObjectNode jsUsage) throws SQLException{
      ResultSet rst = ps.getResultSet();
      ResultSetMetaData rsmd = rst.getMetaData();
      int columnCount = rsmd.getColumnCount();
      Map<String, ArrayNode> colMap = loadColumnMap(columnCount, rsmd);

      while (rst.next()) {
         int year = rst.getInt(1);
         for (int col = 2; col<=columnCount; col++) {
            ObjectNode jsEntry = produceYearToMetric(rst, col, year);
            colMap.get(rsmd.getColumnName(col)).add(jsEntry); //add to Map
         }
      }
      addTojsUsage(jsUsage, colMap);
   }
   static private void processSubjectResultSet(PreparedStatement ps, ArrayNode jsUsage) throws SQLException{
      if ( !ps.getMoreResults() ) return;
      ResultSet rst = ps.getResultSet();
      ResultSetMetaData rsmd = rst.getMetaData();
      int columnCount = rsmd.getColumnCount();
      Map<String, ObjectNode> rowMap = new HashMap<String, ObjectNode>();
      Map<String, ArrayNode> records = new HashMap<String, ArrayNode>();

      while (rst.next()) {
         int year = rst.getInt(1);
         long sum = 0;
         String subjName = rst.getString(3);
         if (!rowMap.containsKey(subjName)) {
            ObjectNode oNode = jsFactory.objectNode();
            oNode.put(rsmd.getColumnName(2), rst.getInt(2));
            rowMap.put(subjName, oNode);
            records.put(subjName, jsFactory.arrayNode());

         }
         ObjectNode jsEntry = jsFactory.objectNode();
         jsEntry.put("year",year);
         for (int col = 4; col<=columnCount; col++) {
            long val = rst.getLong(col);
            //jsEntry.put(rsmd.getColumnName(col), val);
            sum+=val;
         }
         jsEntry.put("total",sum);
         records.get(subjName).add(jsEntry);
      }
      ArrayNode objs = jsFactory.arrayNode();
      for(String key :rowMap.keySet()){
         ObjectNode oNode = rowMap.get(key);
         oNode.set(key, records.get(key));
         objs.add(oNode);
      }
      ObjectNode locObj = jsFactory.objectNode();
      locObj.set("subjects", objs);
   }

   static private void processSubjectPrevYearResultSet(PreparedStatement ps, ObjectNode pResult) throws SQLException{
      if ( !ps.getMoreResults() ) return;
      ResultSet rst = ps.getResultSet();
      ResultSetMetaData rsmd = rst.getMetaData();
      int columnCount = rsmd.getColumnCount();

      ObjectNode obj = jsFactory.objectNode();
      while (rst.next()) {
         obj.put(rst.getString(1),rst.getLong(2));
      }
      pResult.set("subjects", obj);
   }

   static private void processSubjectPrevYearResultSet_v2(PreparedStatement ps, ObjectNode pResult) throws SQLException{
      if ( !ps.getMoreResults() ) return;
      ResultSet rst = ps.getResultSet();
      ResultSetMetaData rsmd = rst.getMetaData();
      int columnCount = rsmd.getColumnCount();

      ObjectNode obj = jsFactory.objectNode();
      HashMap<String, SubjectHierarchy> subjHash = new HashMap<String, SubjectHierarchy>();
      while (rst.next()) {
         String parent_name = rst.getString(1);
         String subject_name = rst.getString(2);
         Long value = rst.getLong(3);
         if (!subjHash.containsKey(parent_name)){
            subjHash.put(parent_name, new SubjectHierarchy(parent_name));
         }
         SubjectHierarchy tmp = subjHash.get(parent_name);
         tmp.addSubject(subject_name, value);
      }

      List<SubjectHierarchy>  lstOrder = new ArrayList<SubjectHierarchy>(subjHash.values());
       Collections.sort(lstOrder, new Comparator<SubjectHierarchy>(){
         public int compare(SubjectHierarchy o1, SubjectHierarchy o2 )
         {
            //reverse order
            return ( o2.getTotal()).compareTo( o1.getTotal() );
         }
      });

      for(SubjectHierarchy sh : lstOrder){
         // "high level" :{ "Total": 1234, "Subjects": [] ... }
         ObjectNode subjNode = jsFactory.objectNode();

         //[ {"medicine":1234}, {"engineering", 3459} ..]
         ArrayNode jSubjects = jsFactory.arrayNode();
         LinkedHashMap<String, Long> subjects = sh.getSubjects();
         for(String subName : subjects.keySet()){
            // {"medicine":1234}
            ObjectNode subObj = jsFactory.objectNode();
            subObj.put(subName, subjects.get(subName));
            jSubjects.add(subObj);
         }
         subjNode.put("Total", sh.getTotal());
         subjNode.set("Subjects", jSubjects);
         obj.set(sh.getName(), subjNode);
      }

      pResult.set("SubjectsHierarchy", obj);
   }



   static private ArrayNode processArray(Long[] arr){
      ArrayNode jsMonths = jsFactory.arrayNode();
      for (long v : arr) jsMonths.add(v);
      return jsMonths;
   }

   static private Map<String, ArrayNode> loadColumnMap(int columnCount, ResultSetMetaData rsmd) throws SQLException{
      //create a map of column name to arraynode <"sessions",[obj,obj,....]
      Map<String, ArrayNode> colMap = new HashMap<String,ArrayNode>();
      for(int ii=2; ii<=columnCount; ii++ ) {
         ArrayNode jsColumn = jsFactory.arrayNode();
         colMap.put(rsmd.getColumnName(ii), jsColumn);
      }
      return colMap;
   }

   static private ObjectNode produceYearToMetric(ResultSet rst, int col, int year) throws SQLException {
      //calculate single object {year:xxx,total:xxx,months:[]}
      ObjectNode jsEntry = jsFactory.objectNode();
      jsEntry.put("year", year);
      Long[] arr = (Long[]) rst.getArray(col).getArray();
      long sum = 0;
      for (long l : arr) sum += l; //total for year

      jsEntry.put("total", sum);

      ArrayNode jsMonths = processArray(arr);
      jsEntry.set("months", jsMonths);
      //jsUsage.add(jsEntry);
      return jsEntry;
   }


   static private void addTojsUsage(ObjectNode js, Map<String,ArrayNode> colMap){
      //add all of the metric objects to the usage array
      for (Map.Entry<String, ArrayNode> entry : colMap.entrySet())
      {
         js.set(entry.getKey(),entry.getValue());
      }
      return;
   }

   static private String getResourceString(String pName) {
      // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
      // all available resource files.
      InputStream isResource = String.class.getResourceAsStream(pName);
      if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
      else throw new RuntimeException("Could not find resource '" + pName + "'");
   }
}

class SubjectHierarchy {
   private String lname;
   private Long total = 0L;
   private LinkedHashMap<String, Long> subjects;
   SubjectHierarchy(String name) {
      lname = name;
      subjects = new LinkedHashMap<String, Long>();
   }

   public void addSubject(String name, Long value){
      total += value;
      subjects.put(name, value);
   }

   public Long getTotal(){
      return total;
   }

   public LinkedHashMap<String, Long> getSubjects(){
      return subjects;
   }

   public String getName(){
      return lname;
   }
}
