package com.elsevier.epic.scival.collaboration;

/**
 * Resolves a Scival institution ID from an MIS accountID
 */
public interface AccountLookup {
    int getScivalInstitutionId(int accountID) throws UnknownAccountException;
}
