package com.elsevier.epic.postgres;

public abstract class RunQuery {
   final public String name;   // The name/identifier for the query, as declared in the XML data schema.
   final public String sql;    // The SQL/CQL to execute for the query
   final public String store;  // For queries that perform lookups
   final public String src;

   public RunQuery(String name, String sql, String store, String src) {
      this.name = name;
      this.sql = sql;
      this.store = store;
      this.src = src;
   }
}
