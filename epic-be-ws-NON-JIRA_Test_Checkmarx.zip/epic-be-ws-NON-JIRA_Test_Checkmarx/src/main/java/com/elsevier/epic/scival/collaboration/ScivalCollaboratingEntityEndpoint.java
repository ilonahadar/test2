package com.elsevier.epic.scival.collaboration;

/**
 * Encapsulates the https://cert.api.scival.com/api/CollaborationMetric/CollaboratingEntity endpoint
 */
public interface ScivalCollaboratingEntityEndpoint {
    ScivalCallResponse call(int scivalInstitutionId, int isoCountryCode, int startYear, int endYear);

}
