package com.elsevier.epic;

import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.PostgresClient;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.sql.*;
import java.util.ArrayList;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response.Status;

public class SearchSources implements DataFeed {
   static private final JsonNodeFactory jsFactory = new JsonNodeFactory(false);
   private final PostgresClient postgresClient;

   public SearchSources() {
      postgresClient = new PostgresClient();
   }

   public SearchSources(final PostgresClient postgresClient) {
      this.postgresClient = postgresClient;
   }

   static private ObjectNode outputJournal(ResultSet pRst) throws SQLException {
      ObjectNode jsEntry = jsFactory.objectNode();
      jsEntry.put("issn", pRst.getString(1));
      jsEntry.put("title", pRst.getString(2));
      jsEntry.put("publisher", pRst.getString(3));
      jsEntry.put("imprint", pRst.getString(4));
      jsEntry.put("type", pRst.getString(5));
      jsEntry.put("typeName", pRst.getString(6));
      jsEntry.put("subscribable", "Y".equals(pRst.getString(7)) ? true : false);
      jsEntry.put("elsevierPub", pRst.getBoolean(8));
      return jsEntry;
   }

   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      if (pIDs.size() < 1) throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);

      String type  = pIDs.get(0).value;
      String paramQuery = pParameters.get("q");
      String paramLimit = pParameters.get("limit");

      if (("issn".equals(type)) || ("all".equals(type)) || ("title".equals(type)));
      else throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
         .setMessage("Invalid type in path - expected 'all', 'issn' or 'title'.")
         .build());

      if ((paramQuery == null) || (paramQuery.length() < 3)) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
            .setMessage("At least 3 characters are required to perform a search.")
            .build());
      }

      final int MAX_CHARS = 120;
      if (paramQuery.length() > MAX_CHARS) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
            .setMessage("The query exceeds the limit of " + MAX_CHARS + " characters.")
            .build());
      }

      int limit;
      try {
         if (paramLimit != null) {
            limit = Integer.parseInt(paramLimit);
            if (limit > 1000) limit = 1000;
            else if (limit <= 0) throw new NumberFormatException("Limit cannot be <= 0");
         }
         else limit = 50;
      }
      catch (NumberFormatException ex) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
            .setMessage("Invalid value in limit parameter.")
            .build());
      }

      ArrayNode jsArray = jsFactory.arrayNode();

      // Special handling for \ _ % due to use of the ILIKE (case insensitive) clause.

      String search = paramQuery.replace("\\", "\\\\")
         .replace("_", "\\_")
         .replace("%", "\\%")
         .replace("'", "\'");

      try (Connection con = postgresClient.getConnectionPool()) {
         final String likePattern = "%" + search + "%";
         if ("all".equals(type)) {
            final String query = "SELECT issn, title, publisher, imprint, content_type, type_name, subscribable, elsevier_pub\n" +
                                 "FROM vw_journals AS j\n" +
                                 "WHERE ((issn ILIKE ?) OR (title ILIKE ?))\n" +
                                 "ORDER BY levenshtein(?, title), issn LIMIT ?";

            try (PreparedStatement ps = con.prepareStatement(query)) {
               ps.setQueryTimeout(60);
               ps.setString(1, likePattern);
               ps.setString(2, likePattern);
               ps.setString(3, search);
               ps.setInt(4, limit);
               try (ResultSet rst = ps.executeQuery()) {
                  while (rst.next()) {
                     jsArray.add(outputJournal(rst));
                  }
               }
            }
         }
         else if ("issn".equals(type)) {
            final String query = "SELECT issn, title, publisher, imprint, content_type, type_name, subscribable, elsevier_pub\n" +
                                 "FROM vw_journals AS j\n" +
                                 "WHERE (avail_title) AND (issn ILIKE ?)\n" +
                                 "ORDER BY issn LIMIT ?";

            try (PreparedStatement ps = con.prepareStatement(query)) {
               ps.setQueryTimeout(60);
               ps.setString(1, likePattern);
               ps.setInt(2, limit);
               try (ResultSet rst = ps.executeQuery()) {
                  while (rst.next()) {
                     jsArray.add(outputJournal(rst));
                  }
               }
            }
         }
         else {
            final String query = "SELECT issn, title, publisher, imprint, content_type, type_name, subscribable, elsevier_pub\n" +
                                 "FROM vw_journals\n" +
                                 "WHERE title ILIKE ?\n" +
                                 "ORDER BY levenshtein(?, title), issn LIMIT ?";

            try (PreparedStatement ps = con.prepareStatement(query)) {
               ps.setQueryTimeout(60);
               ps.setString(1, "%" + paramQuery + "%" );
               ps.setString(2, search);
               ps.setInt(3, limit);
               try (ResultSet rst = ps.executeQuery()) {
                  while (rst.next()) {
                     jsArray.add(outputJournal(rst));
                  }
               }
            }
         }
      }
      catch (SQLException ex) {
         throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
            .setMessage("Internal database error: " + ex.getMessage())
            .setException(ex)
            .build());
      }

      return Response.ok(jsArray).build();
   }
}
