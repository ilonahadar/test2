package com.elsevier.epic.scopus.v2;
// Support for Journal Value v3/account/{accountID}/journalvalue/top/{count}/
//--getJournalValue(sis bigint, beginYear integer, endYear integer, asjc integer, title text, publisher text, sortyear int, nrows int)

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.utility.Utility;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.io.InputStream;
import java.sql.*;
import java.util.*;


public class JournalValue implements DataFeed {
    private static final Logger LOG = Log.getLogger(ScopusUsage.class);
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe

    static final int MIN_YEAR = 2014;

    PreparedStatement getStatement(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement(getResourceString("/scopus_journal_demand.sql"));
        ps.setQueryTimeout(60);
        return ps;
    }

    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
        if (pIDs.size() < 1) throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);

        String paramAccount = pIDs.get(0).value;
        String paramRownum = pIDs.get(1).value;

        String paramYearStart = pParameters.get("yearstart");
        String paramYearEnd = pParameters.get("yearend");
        String paramTitle = pParameters.get("title");
        String paramSubject =  pParameters.get("subject");
        String paramPublisher =  pParameters.get("publisher");
        String paramFilterYear  = pParameters.get("sortyear");
        String paramISSN = pParameters.get("issn");

        int accountID;
        int rownum;
        try {
            accountID = Integer.parseInt(paramAccount);
            rownum = Integer.parseInt(paramRownum);
        } catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
                    .setMessage("Invalid ID '" + paramAccount + "'" + " or Number of Rows '"+ paramRownum +"'")
                    .setException(ex)
                    .build());
        }

        ObjectNode jsRoot = jsFactory.objectNode();
        ObjectNode jsParams = jsFactory.objectNode();
        jsRoot.set("parameters", jsParams);
        jsParams.put("id", paramAccount)
                .put("rownum", paramRownum);

        if (paramYearStart != null){
            jsParams.put("yearStart", paramYearStart);
        }
        if (paramYearEnd != null){
            jsParams.put("yearEnd", paramYearEnd);
        }

        int ys = Utility.readInt(paramYearStart);
        final int yearEnd;
        int y = Utility.readInt(paramYearEnd);

        Calendar cal = Calendar.getInstance();
        int currentYear = cal.get(Calendar.YEAR);
        yearEnd = (y <= 0) ? currentYear : y;

        if (ys > currentYear) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid year parameter " + ys).build();
        }

        if ((ys < 0) || (ys > yearEnd)) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid year parameters " + ys + " to " + yearEnd).build();
        }

        final int yearStart = (ys < MIN_YEAR) ? MIN_YEAR : ys;

        Integer asjc  = intCheck(paramSubject, "subject");
        Integer sortyear = intCheck(paramFilterYear, "sortyear");

        queryCounter(jsRoot, accountID, yearStart, yearEnd, asjc, paramTitle, paramPublisher, paramISSN, sortyear, rownum );
        return Response.ok(jsRoot).build();
    }

    private int yearCheck(String field, String fieldName){
        int year = Calendar.getInstance().get(Calendar.YEAR);
        if (field != null){
            year = intCheck(field, fieldName);
        }
        return year;
    }

    private Integer intCheck(String field, String fieldName){
        Integer loc;

        if (field == null)  loc = null;
        else {
            try {
                loc = Integer.parseInt(field);
            } catch (NumberFormatException ex) {
                throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
                        .setMessage("Invalid "+ fieldName +" '" + field + "'" )
                        .setException(ex)
                        .build());
            }
        }
        return loc;
    }

    private void queryCounter(ObjectNode pResult, int pSIS
            , int pYearStart, int pYearEnd, Integer asjc
            , String title, String publisher, Integer sortyear, int nrows) {
        //(sis bigint, beginYear integer, endYear integer, asjc integer, title text, publisher text, sortyear int, nrows int)
        ArrayList<Integer> years = new ArrayList<Integer>();
        try (Connection con = PostgresClient.getConnectionTempTable();
             PreparedStatement ps = getStatement(con)) {
            ps.setInt(1, pSIS);
            ps.setInt(2, pYearStart);
            ps.setInt(3, pYearEnd);
            if (asjc == null) ps.setNull(4, Types.INTEGER); else ps.setInt(4,asjc);
            ps.setString(5, title);
            ps.setString(6,publisher);
            if (sortyear == null) ps.setNull(7, Types.INTEGER); else ps.setInt(7,sortyear);
            ps.setInt(8, nrows);

            if (!CoreServer.isProduction()) LOG.info(ps.toString());

            ObjectNode jsUsage = jsFactory.objectNode();

            ps.execute();
            processJournalValue(ps, jsUsage, years);
            pResult.set("usage", jsUsage);
        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }
    }

    private void queryCounter(ObjectNode pResult, int pSIS
            , int pYearStart, int pYearEnd, Integer asjc
            , String title, String publisher, String issn, Integer sortyear, int nrows) {
        //(sis bigint, beginYear integer, endYear integer, asjc integer, title text, publisher text, sortyear int, nrows int)
        ArrayList<Integer> years = new ArrayList<Integer>();

        for (int yr = pYearStart; yr <= pYearEnd; yr++){
            years.add(yr);
        }

        try (Connection con = PostgresClient.getConnectionTempTable();
             PreparedStatement ps = getStatement(con)) {
            ps.setQueryTimeout(60);
            ps.setInt(1, pSIS);
            ps.setInt(2, pYearStart);
            ps.setInt(3, pYearEnd);
            if (asjc == null) ps.setNull(4, Types.INTEGER); else ps.setInt(4,asjc);
            ps.setString(5, title);
            ps.setString(6, publisher);
            ps.setString(7,issn);
            if (sortyear == null) ps.setNull(8, Types.INTEGER); else ps.setInt(8,sortyear);
            ps.setInt(9, nrows);

            if (!CoreServer.isProduction()) LOG.info(ps.toString());

            ObjectNode jsUsage = jsFactory.objectNode();

            ps.execute();
            processJournalValue(ps, jsUsage, years);
            pResult.set("usage", jsUsage);
        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }
    }

    static private String getResourceString(String pName) {
        // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
        // all available resource files.
        InputStream isResource = String.class.getResourceAsStream(pName);
        if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
        else throw new RuntimeException("Could not find resource '" + pName + "'");
    }

    static private void processJournalValue(PreparedStatement ps, ObjectNode jsUsage, ArrayList<Integer> years) throws SQLException {
        ResultSet rst = ps.getResultSet();
        ResultSetMetaData rsmd = rst.getMetaData();
        int columnCount = rsmd.getColumnCount();
        String report  = "";
        ArrayNode currNode = null;
        //Note: the order is set in the query...
        while(rst.next()){
            String currReport = rst.getString("report_type");
            if (currReport == null) currReport = "NoData";
            if (currReport != null && currReport.compareTo(report) !=0) {
                if (currNode != null){
                    jsUsage.set(report, currNode);
                }
                report = currReport;
                currNode = jsFactory.arrayNode();
            }
            ObjectNode locNode = jsFactory.objectNode();
            int rnum = rst.getInt("rownum");
            long source_id = rst.getLong("source_id");
            /*issn array*/
            String[] all_issn = (String[]) rst.getArray("all_issn").getArray();
            ArrayNode a_issn = jsFactory.arrayNode();
            for(String issn : all_issn) a_issn.add(issn);
            String source_title = rst.getString("sourcetitle");
            HashMap<String,String> citescore = (HashMap<String, String>) rst.getObject( "citescore" );
            HashMap<String,String> reference = (HashMap<String, String>) rst.getObject( "reference" );
            HashMap<String,String> source = (HashMap<String, String>) rst.getObject( "source" );
            locNode.put("rownum",rnum);
            locNode.put("source_id", source_id);
            locNode.set("all_issn", a_issn);
            locNode.put("title",source_title);

            locNode.set("citescore", processHashMap(citescore, years));
            locNode.set("reference", processHashMap(reference, years));
            locNode.set("source", processHashMap(source, years));
            currNode.add(locNode);
        }
        jsUsage.set(report, currNode);
    }

    static private ArrayNode processHashMap(HashMap<String, String> map, ArrayList<Integer> years){
        ArrayNode anode = jsFactory.arrayNode();
        if (map == null) return anode;
        for (Integer yr: years){
            ObjectNode onode = jsFactory.objectNode();
            onode.put("year", yr);
            Double dble = 0d;
            String sDble = map.get(yr.toString());
            if(sDble != null) dble = Double.parseDouble(sDble);
            onode.put("total", dble );
            anode.add(onode);
        }
        return anode;
    }
}
