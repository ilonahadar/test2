/*
This class specifies the configuration parameters that we can support in the server YAML file.
*/

package com.elsevier.epic.core;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.dropwizard.Configuration;

import java.util.List;

public class ServerConfig extends Configuration {
   private List<String> cassandraServer;
   private List<String> elasticSearch;
   private List<String> elasticSearchDriver;
   private List<String> allowedIPs;
   private boolean cassandraPersist;
   private String cassandraKeyspace;
   private String cassandraConsistency;
   private String cassandraUser;
   private String cassandraPassword;
   private List<String> globalToken;
   private String environment;
   private String postgresServer;
   private String postgresSchema;
   private String postgresUser;
   private String postgresPassword;
   private int dbConnectTimeout;
   private int dbQueryTimeout;
   private int dbLoginTimeout;
   private String extServerAddress;
   private String mailServer;
   private String mailPort;
   private String mailSender;
   private String mailLogin;
   private String mailPassword;
   private String mailType;
   private String mailAdmin;
   private String siteFolder;
   private String svUser;
   private String svUserToken;
   private String svSite;
   private boolean warmup;

   private String proxyUser;
   private String proxyHost;
   private String proxyKeyFile;
   private String proxyPassword;
   private int proxyAliveInterval;
   private String serviceFile;
   private String awsSecretsCredential;

   public ServerConfig() {
      this.siteFolder = "site/";
      this.svSite = "api.scival.com";
      this.warmup = true;
   }
   @JsonProperty
   public String getAwsSecretsCredential() {
      return this.awsSecretsCredential;
   }

   @JsonProperty
   public List<String> getElasticSearch() {
      return this.elasticSearch;
   }

   @JsonProperty
   public String getCassandraConsistency() {
      return this.cassandraConsistency;
   }

   @JsonProperty
   public void setCassandraConsistency(String value) {
      this.cassandraConsistency = value;
   }

   @JsonProperty
   public boolean getCassandraPersist() {
      return this.cassandraPersist;
   }

   @JsonProperty
   public String getCassandraKeyspace() {
      return this.cassandraKeyspace;
   }

   @JsonProperty
   public void setCassandraKeyspace(String value) {
      this.cassandraKeyspace = value;
   }

   @JsonProperty
   public String getCassandraUser() {
      return this.cassandraUser;
   }

   @JsonProperty
   public void setCassandraUser(String value) {
      this.cassandraUser = value;
   }

   @JsonProperty
   public String getCassandraPassword() {
      return this.cassandraPassword;
   }

   @JsonProperty
   public void setCassandraPassword(String value) {
      this.cassandraPassword = value;
   }

   @JsonProperty
   public List<String> getCassandraServer() {
      return this.cassandraServer;
   }

   @JsonProperty
   public void setCassandraServer(List<String> value) {
      this.cassandraServer = value;
   }

   @JsonProperty
   public List<String> getAllowedIPs() {
      return this.allowedIPs;
   }

   @JsonProperty
   public void setAllowedIPs(List<String> value) {
      this.allowedIPs = value;
   }

   @JsonProperty
   public List<String> getGlobalToken() {
      return this.globalToken;
   }

   @JsonProperty
   public void setGlobalToken(List<String> value) {
      this.globalToken = value;
   }

   @JsonProperty
   public String getServiceFile() {
      return this.serviceFile;
   }



   @JsonProperty
   public void setServiceFile(String value) {
      this.serviceFile = value;
   }

   @JsonProperty
   public List<String> getElasticSearchDriver() {
      return elasticSearchDriver;
   }

   @JsonProperty
   public void setElasticSearchDriver(List<String> value) {
      this.elasticSearchDriver = value;
   }

   public String getEnvironment() {
      return this.environment;
   }



   @JsonProperty
   public void setEnvironment(String value) {
      if ((value.equals("test")) || (value.equals("prod"))) {
         this.environment = value;
      }
      else throw new IllegalArgumentException("Unrecognised environment setting '" + value + "'");
   }

   @JsonProperty
   public String getPostgresServer() {
      return this.postgresServer;
   }

   @JsonProperty
   public void setPostgresServer(String value) {
      this.postgresServer = value;
   }

   @JsonProperty
   public String getPostgresSchema() {
      return this.postgresSchema;
   }

   @JsonProperty
   public void setPostgresSchema(String value) {
      this.postgresSchema = value;
   }

   @JsonProperty
   public int getDBConnectTimeout() {
      return this.dbConnectTimeout;
   }

   @JsonProperty
   public void setDBConnectTimeout(int value) {
      this.dbConnectTimeout = value;
   }

   @JsonProperty
   public int getDBLoginTimeout() {
      return this.dbLoginTimeout;
   }

   @JsonProperty
   public void setDBLoginTimeout(int value) {
      this.dbLoginTimeout = value;
   }

   @JsonProperty
   public int getDBQueryTimeout() {
      return this.dbQueryTimeout;
   }

   @JsonProperty
   public void setDBQueryTimeout(int value) {
      this.dbQueryTimeout = value;
   }

   @JsonProperty
   public String getPostgresUser() {
      return this.postgresUser;
   }

   @JsonProperty
   public void setPostgresUser(String value) {
      this.postgresUser = value;
   }

   @JsonProperty
   public String getSVSite() {
      return this.svSite;
   }

   @JsonProperty
   public void setSVSite(String value) {
      this.svSite = value;
   }

   @JsonProperty
   public String getSVUser() {
      return this.svUser;
   }

   @JsonProperty
   public void setSVUser(String value) {
      this.svUser = value;
   }

   @JsonProperty
   public String getSVUserToken() {
      return this.svUserToken;
   }

   @JsonProperty
   public void setSVUserToken(String value) {
      this.svUserToken = value;
   }

   @JsonProperty
   public String getPostgresPassword() {
      return this.postgresPassword;
   }

   @JsonProperty
   public void setPostgresPassword(String value) {
      this.postgresPassword = value;
   }

   @JsonProperty
   public String getProxyUser() {
      return this.proxyUser;
   }

   @JsonProperty
   public void setProxyUser(String value) {
      this.proxyUser = value;
   }

   @JsonProperty
   public String getProxyHost() {
      return this.proxyHost;
   }

   @JsonProperty
   public void setProxyHost(String value) {
      this.proxyHost = value;
   }

   @JsonProperty
   public String getProxyKeyFile() {
      return this.proxyKeyFile;
   }

   @JsonProperty
   public void setProxyKeyFile(String value) {
      this.proxyKeyFile = value;
   }

   @JsonProperty
   public int getProxyAliveInterval() {
      return this.proxyAliveInterval;
   }

   @JsonProperty
   public void setProxyAliveInterval(int value) {
      this.proxyAliveInterval = value;
   }

   @JsonProperty
   public String getProxyPassword() {
      return this.proxyPassword;
   }

   @JsonProperty
   public void setProxyPassword(String value) {
      this.proxyPassword = value;
   }

   @JsonProperty
   public String getExtServerAddress() {
      return this.extServerAddress;
   }

   @JsonProperty
   public void setExtServerAddress(String value) {
      this.extServerAddress = value;
   }

   @JsonProperty
   public String getMailServer() {
      return this.mailServer;
   }

   @JsonProperty
   public void setMailServer(String value) {
      this.mailServer = value;
   }

   @JsonProperty
   public String getMailPort() {
      return this.mailPort;
   }

   @JsonProperty
   public void setMailPort(String value) {
      this.mailPort = value;
   }

   @JsonProperty
   public String getMailSender() {
      return this.mailSender;
   }

   @JsonProperty
   public void setMailSender(String value) {
      this.mailSender = value;
   }

   @JsonProperty
   public String getMailLogin() {
      return this.mailLogin;
   }

   @JsonProperty
   public void setMailLogin(String value) {
      this.mailLogin = value;
   }

   @JsonProperty
   public String getMailPassword() {
      return this.mailPassword;
   }

   @JsonProperty
   public void setMailPassword(String value) {
      this.mailPassword = value;
   }

   @JsonProperty
   public String getMailType() {
      return this.mailType;
   }

   @JsonProperty
   public void setMailType(String value) {
      this.mailType = value;
   }

   @JsonProperty
   public String getMailAdmin() {
      return this.mailAdmin;
   }

   @JsonProperty
   public void setMailAdmin(String value) {
      this.mailAdmin = value;
   }

   @JsonProperty
   public String getSiteFolder() {
      return this.siteFolder;
   }

   @JsonProperty
   public void setSiteFolder(String value) {
      this.siteFolder = value;
   }

   @JsonProperty
   public boolean getWarmup() {
      return this.warmup;
   }
}
