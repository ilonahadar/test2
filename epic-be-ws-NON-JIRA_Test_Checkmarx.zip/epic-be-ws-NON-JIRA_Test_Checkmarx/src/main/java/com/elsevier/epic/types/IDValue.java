package com.elsevier.epic.types;

import com.elsevier.epic.jaxb.IdType;

public class IDValue {
  public IdType id;
  public String value; // The value extracted out of the resource.
  
  public IDValue(IdType id, String value) {
     this.id = id;
     this.value = value;
  }
};
