package com.elsevier.epic.turnaways;

import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.types.Journal;
import com.elsevier.epic.utility.SDJournals;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TopJournalTurnawaysByCategory implements DataFeed {
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

   static class QueryResult {
      final Integer year;
      final Integer month;
      final Integer code;
      final String[] list;

      public QueryResult(Integer pYear, Integer pMonth, Integer pCode, java.sql.Array pList) throws SQLException {
         this.year = pYear;
         this.month = pMonth;
         this.code = pCode;

         if (pList != null) this.list = (String[])pList.getArray();
         else this.list = null;
      }
   }

   static interface Query {
      static class QueryMap implements ResultSetMapper<QueryResult> {
          @Override
          public QueryResult map(int row, ResultSet rst, StatementContext ctxStatement) throws SQLException {
              return new QueryResult(rst.getInt("year"), rst.getInt("month"), rst.getInt("code"), rst.getArray("values"));
          }
      }

       @Mapper(QueryMap.class)
         @SqlQuery("SELECT year, month, code, values FROM vw_account_top_turnaways_asjc WHERE sis=:accountId AND code=:code;")
         List<QueryResult> runQuery(@Bind("accountId") int accountId, @Bind("code") int code);
   }

   // Entry point for querying top N turnaways

   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
       int accountId = Integer.parseInt(pIDs.get(0).value);
       int count = Integer.parseInt(pIDs.get(1).value);
       int code = Integer.parseInt(pIDs.get(2).value);

      List<QueryResult> results = PostgresClient.getDBI().onDemand(Query.class).runQuery(accountId, code);

      ArrayNode jsResults = jsFactory.arrayNode();
      int totalRecords = 0;
      for (QueryResult entry : results) {
         for (String record : entry.list) {
            ObjectNode obj = jsResults.addObject();
            String issn = record.substring(0, record.indexOf(":"));
            int total = Integer.parseInt(record.substring(record.indexOf(":")+1));
            obj.put("issn", issn);
            Journal journal = SDJournals.getJournal(issn);
            if (journal != null) obj.put("title", journal.title);
            obj.put("total", total);
            totalRecords++;
            if (--count <= 0) break;
         }
      }

      /* totalRecords = 0 EPIC-*/
      ObjectNode jsRoot = jsFactory.objectNode();
      jsRoot.put("totalRecords", totalRecords);
      if (totalRecords > 0) {
         jsRoot.put("reportDate", String.format("%04d-%02d-01", results.get(0).year, results.get(0).month)); /* "01" is hard-coded? */
         jsRoot.put("period", 12); /* hard-coded ? */
         jsRoot.put("interval", "monthly");
      }
      jsRoot.set("results", jsResults);

      return Response.ok(jsRoot).build();
   }
}
