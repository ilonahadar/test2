package com.elsevier.epic.scival;

import java.text.ParseException;
import java.util.Date;

public class SVLastUpdate {
   public long lastUpdated;
    public long yearRangeYear;

   SVLastUpdate(String pLastUpdated, Long pYearRangeYear) throws ParseException {
      Date result = SciVal.svDateFormat.parse(pLastUpdated);
      this.lastUpdated = result.getTime();
      this.yearRangeYear = pYearRangeYear;
   }

   SVLastUpdate(Long pLastUpdated, Long pYearRangeYear) {
      this.lastUpdated = pLastUpdated;
      this.yearRangeYear = pYearRangeYear;
   }
}
