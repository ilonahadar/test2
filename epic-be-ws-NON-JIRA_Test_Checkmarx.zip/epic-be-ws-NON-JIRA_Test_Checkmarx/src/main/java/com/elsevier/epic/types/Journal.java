package com.elsevier.epic.types;

public class Journal {
   public String issn;
   public String title;
   public boolean subscribable;
   public boolean serial;
   public String srcType;
   public String srcTypeName;
   public String publisher;
   public String imprint;
   public int totalUsage;
}
