/**
 * This class acts as a container for email server information.  Refer to the Email class for the code that sends
 * emails.
 */

package com.elsevier.epic.email;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.exceptions.AppException;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

public class EmailServer {
   private static final Logger LOG = Log.getLogger(EmailServer.class);

   final public String smtpServer;
   final public int smtpPort;
   final public String sender;
   final public String login;
   final public String password;
   final public String loginType;
   final public int antiSpamInterval = 60 * 1000;

   final static private Map<String, Long> antiSpam = new ConcurrentHashMap<>();

   static public boolean configured() {
      if (CoreServer.config == null) return false;
      if (CoreServer.config.getMailServer() == null) return false;
      return true;
   }

   /**
    * Initialise an email object with custom server settings.
    *
    * @param pServer
    * @param pPort
    * @param pSender
    * @param pLogin
    * @param pPassword
    * @param pServerType
    */

   public EmailServer(String pServer, int pPort, String pSender, String pLogin, String pPassword, String pServerType) {
      if (pServer == null)   throw new IllegalArgumentException("The Server parameter is null.");
      if (pPort <= 0)        throw new IllegalArgumentException("The Port parameter is invalid.");
      if (pSender == null)   throw new IllegalArgumentException("The Sender parameter is null.");
      if (pLogin == null)    throw new IllegalArgumentException("The Login parameter is null.");
      if (pPassword == null) throw new IllegalArgumentException("The Password parameter is null.");

      this.smtpServer = pServer;
      this.smtpPort   = pPort;
      this.sender     = pSender;
      this.login      = pLogin;
      this.password   = pPassword;

      if (pServerType == null) this.loginType = "TLS";
      else if (!pServerType.matches("SSL|TLS")) throw new IllegalArgumentException("The ServerType options are SSL or TLS.");
      else this.loginType = pServerType;
   }

   /**
    * Initialise an email object with default settings from the Server YAML file.
    */

   public EmailServer() {
      this(CoreServer.config.getMailServer(),
           Integer.parseInt(CoreServer.config.getMailPort()),
           CoreServer.config.getMailSender(),
           CoreServer.config.getMailLogin(),
           CoreServer.config.getMailPassword(),
           CoreServer.config.getMailType());
   }

   /**
    * Convert the internal server settings into a properties object that can be used by the javax.mail API.
    *
    * @return
    */

   private Properties getProperties() {
      Properties props = new Properties();
      props.put("mail.from", sender);
      props.put("mail.smtp.host", smtpServer);
      props.put("mail.smtp.port", smtpPort);
      props.put("mail.smtp.connectionpooltimeout", "3000");
      props.put("mail.smtp.connectiontimeout", "3000");
      props.put("mail.smtp.timeout", "3000");

      if (loginType.equalsIgnoreCase("TLS")) {
         props.put("mail.smtp.auth", "true");
         props.put("mail.smtp.starttls.enable", "true");
      }
      else if (loginType.equalsIgnoreCase("SSL")) {
         props.put("mail.smtp.auth", "true");
         props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
         props.put("mail.smtp.socketFactory.port", smtpPort);
      }

      return props;
   }

   /**
    * Send an email message.  Please note that it may not be delivered if the anti-spam rules are triggered.
    *
    * @param pMessage
    * @throws AppException
    */

   public void sendMessage(EmailMessage pMessage) throws AppException {
      sendMessage(pMessage, false);
   }

   /**
    * Send a message through the configured server environment.
    *
    * @param pMessage Must refer to a fully configured EmailMessage object.
    * @param pForce   Set to true if anti-spam checks must be ignored.
    * @throws AppException
    */

   public void sendMessage(EmailMessage pMessage, boolean pForce) throws AppException {
      if (!pForce) {
         // Anti-spam checks
         if (antiSpam.containsKey(pMessage.recipient)) {
            if (System.currentTimeMillis() - antiSpam.get(pMessage.recipient) < antiSpamInterval) {
               LOG.info("Skipped sending message to " + pMessage.recipient + " (anti-spam rules)");
               return;
            }
         }
      }

      LOG.info("Sending an email to " + pMessage.recipient);

      javax.mail.Session session = javax.mail.Session.getInstance(getProperties(), new javax.mail.Authenticator() {
         @Override
         protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(login, password);
         }
      });

      try {
         Transport.send(pMessage.getMimeMessage(session));
         antiSpam.put(pMessage.recipient, System.currentTimeMillis());
      }
      catch (MessagingException e) {
         throw new AppException(e.getMessage(), e);
      }
   }

   /**
    * Check a string for validity as an email address.
    *
    * @param pEmail
    * @return
    */

   static public boolean validAddress(String pEmail) {
      if ((pEmail == null) || (pEmail.isEmpty())) return false;

      // The string must not contain whitespace or control codes.

      for (int ei=0; ei < pEmail.length(); ei++) {
         if (pEmail.charAt(ei) <= 0x20) return false;
      }

      // Break the string down into its name, domain and suffix.

      int i = pEmail.indexOf('@');
      if (i == -1) return false;
      String name = pEmail.substring(0, i);

      int j = pEmail.indexOf('.', i);
      String domain = pEmail.substring(i+1, j);
      String suffix = pEmail.substring(j);

      // Validate the email parts separately.  We can't actually do too much
      // because of the potential for unicode characters.

      if (name.length() > 64) return false;
      if (name.length() < 1) return false;

      if (domain.length() < 1) return false;
      if (domain.length() > 64) return false;

      if (suffix.length() < 1) return false;
      if (suffix.length() > 32) return false;
      if (!suffix.matches("[a-zA-Z\\.]+"))return false;

      return true;
   }
}
