package com.elsevier.epic.evs;

import com.elsevier.epic.DataLastUpdated;
import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.utility.CountryCode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class EvsCountryMetricsByCountry implements DataFeed{

     private static final Logger LOG = Log.getLogger(DataLastUpdated.class);
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe

    PreparedStatement getStatement(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement(getResourceString("/evs_country_metrics.sql"));
        ps.setQueryTimeout(60);
        return ps;
    }

    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {

        if (pIDs.size() < 1) throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);

        String paramAccountID  = pIDs.get(0).value;
        String paramSubjectID = pIDs.get(1).value;
        String paramTopN = pIDs.get(2).value;

        int accountID = CountryCode.getNumericCountryCode(paramAccountID);
        int subjectID = validateIntParams(paramSubjectID);
        int topN = validateIntParams(paramTopN);

        ObjectNode jsRoot = jsFactory.objectNode();
        ObjectNode jsParams = jsFactory.objectNode();
        jsRoot.set("parameters", jsParams);
        jsParams.put("countrycode", accountID);
        jsParams.put("subjectid", paramSubjectID);

        queryCounter(jsRoot, accountID, subjectID, topN);
        return Response.ok(jsRoot).build();
    }

    private void queryCounter(ObjectNode pResult, int pSIS, int pSubID, int pTopN){

        try (Connection con = PostgresClient.getConnection();
             PreparedStatement ps = getStatement(con)){

            ps.setInt(1, pSIS);
            ps.setInt(2, pSubID);
            ps.setInt(3, pSIS);
            ps.setInt(4, pSubID);
            ps.setInt(5, pSIS);
            ps.setInt(6, pSubID);
            ps.setInt(7, pSIS);
            ps.setInt(8, pSubID);
            ps.setInt(9, pSIS);
            ps.setInt(10, pSubID);
            ps.setInt(11, pTopN);
            ps.setInt(12, pSIS);
            ps.setInt(13, pSubID);
            ps.setInt(14, pTopN);
            ps.setInt(15, pSIS);
            ps.setInt(16, pSubID);
            ps.setInt(17, pTopN);
            ps.setInt(18, pSIS);
            ps.setInt(19, pSubID);
            ps.setInt(20, pTopN);


            if (!CoreServer.isProduction()) LOG.info(ps.toString());

            ObjectNode headNode = jsFactory.objectNode();

            ps.execute();

            getTotalCountries(ps, headNode, "total_countries_impact");
            ps.getMoreResults();
            getTotalCountries(ps, headNode, "total_countries_input");
            ps.getMoreResults();
            getTotalCountries(ps, headNode, "total_countries_output");
            ps.getMoreResults();
            getTotalCountries(ps, headNode, "total_countries_patcit");
            ps.getMoreResults();
            getTopCountries(ps, headNode, "top_countries_impact");
            ps.getMoreResults();
            getTopCountries(ps, headNode, "top_countries_input");
            ps.getMoreResults();
            getTopCountries(ps, headNode, "top_countries_output");
            ps.getMoreResults();
            getTopCountries(ps, headNode, "top_countries_patcit");

            pResult.set("result", headNode);
        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }
    }
    static private void getTotalCountries(PreparedStatement ps, ObjectNode jsUsage, String name) throws SQLException {

        ResultSet rst = ps.getResultSet();

        while (rst.next()) {

            String all = rst.getString(1);
            String all_notoa = rst.getString(2);
            String fc = rst.getString(3);
            String fc_notoa = rst.getString(4);

            ObjectNode locNode = jsFactory.objectNode();

            locNode.put("all", all);
            locNode.put("all_notoa", all_notoa);
            locNode.put("fc", fc);
            locNode.put("fc_notoa", fc_notoa);

            jsUsage.set(name, locNode);

        }

    }

        static private void getTopCountries(PreparedStatement ps, ObjectNode jsUsage, String name) throws SQLException {

        ResultSet rst = ps.getResultSet();

        ObjectNode contentNode = jsFactory.objectNode();
        ArrayNode rowNode1 = jsFactory.arrayNode();
        ArrayNode rowNode2 = jsFactory.arrayNode();
        ArrayNode rowNode3 = jsFactory.arrayNode();
        ArrayNode rowNode4 = jsFactory.arrayNode();

        while (rst.next()) {

            String content = rst.getString(1);
            String countries = rst.getString(2);
            String total = rst.getString(3);

            if (content.equals("all")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("countries", countries);
                locNode.put("total", total);

                rowNode1.add(locNode);

                contentNode.set(content, rowNode1);
            }

            if (content.equals("all_notoa")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("countries", countries);
                locNode.put("total", total);

                rowNode2.add(locNode);

                contentNode.set(content, rowNode2);
            }

            if (content.equals("fc")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("countries", countries);
                locNode.put("total", total);

                rowNode3.add(locNode);

                contentNode.set(content, rowNode3);
            }

            if (content.equals("fc_notoa")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("countries", countries);
                locNode.put("total", total);

                rowNode4.add(locNode);

                contentNode.set(content, rowNode4);
            }
        }

        jsUsage.set(name, contentNode);
    }

    static private int validateIntParams(String pName) {

        int pVal;

        try {
            pVal = Integer.parseInt(pName);
        }
        catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
                    .setMessage("Invalid ID '" + pName + "'")
                    .setException(ex)
                    .build());
        }
        return pVal;
    }

    static private String getResourceString(String pName) {
        // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
        // all available resource files.
        InputStream isResource = String.class.getResourceAsStream(pName);
        if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
        else throw new RuntimeException("Could not find resource '" + pName + "'");
    }
}
