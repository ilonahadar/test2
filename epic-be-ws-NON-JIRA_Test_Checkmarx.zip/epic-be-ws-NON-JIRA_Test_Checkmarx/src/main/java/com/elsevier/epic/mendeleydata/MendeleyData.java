package com.elsevier.epic.mendeleydata;

import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.postgres.PostgresClient;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.*;
import javax.ws.rs.WebApplicationException;
import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

public class MendeleyData implements DataFeed {
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);
   
    // datasets created and published
    static class MendeleyDataYrMonthCountResult {
        final int dsYear;
        final int dsMonth;
        final int createdCount;
        final int publishedCount;
        
        public MendeleyDataYrMonthCountResult( int dsYear, int dsMonth, int createdCount, int publishedCount) {
            this.dsYear = dsYear;
            this.dsMonth = dsMonth;
            this.createdCount = createdCount;
            this.publishedCount = publishedCount;
        }
    }
    
    // dataset sizes
    static class MendeleyDatasetSizesResult {
        final long total;
        final Boolean draft;
        
        public MendeleyDatasetSizesResult( long total, Boolean draft) {
            this.total = total;
            this.draft = draft;
        }
    }

    //Mendeley last updated date

    static class MendeleyDatasetLastUpdatedDateResult {
        final String lastupdated;
       public MendeleyDatasetLastUpdatedDateResult(String lastupdated) {
            this.lastupdated = lastupdated;
        }
    }

    // dataset's author views / most views datasets
    static class MendeleyDatasetViewResult {
        final String datasetName;
        final String[] authors;
        final int views;
        final String id;
        
        public MendeleyDatasetViewResult( String datasetName, java.sql.Array authors, int views, String id) throws SQLException {
            this.datasetName = datasetName;
            if (authors != null)
                this.authors = (String[])authors.getArray();
            else this.authors = null;
            this.views = views;
            this.id = id;
        }
    }
    
        // top datasets by storage
    static class MendeleyDatasetStorageResult {
        final String datasetName;
        final String[] authors;
        final long storageUsed;
        final String id;
        
        public MendeleyDatasetStorageResult( String datasetName, java.sql.Array authors, long storageUsed, String id) throws SQLException {
        this.datasetName = datasetName;
            if (authors != null)
                this.authors = (String[])authors.getArray();
            else this.authors = null;            
            this.storageUsed = storageUsed;
            this.id = id;
        }
    }
        
    // top authors by storage
    static class MendeleyDatasetAuthorStorageResult {
        final String authors;
        final long storageUsed;
        
        public MendeleyDatasetAuthorStorageResult(  String authors, long storageUsed) {
            this.authors = authors;
            this.storageUsed = storageUsed;
        }
    }
    
    /* Get dataset counts for draft/published per institution */
    interface GetDatasetYrMonthCounts {
        class DatasetYrMonthCounts implements ResultSetMapper<MendeleyDataYrMonthCountResult> {
            @Override
            public MendeleyDataYrMonthCountResult map(int row, ResultSet rst, StatementContext ctxStatement) throws SQLException {
                return new MendeleyDataYrMonthCountResult(rst.getInt(1), rst.getInt(2), rst.getInt(3), rst.getInt(4));
            }
        }
        @Mapper(DatasetYrMonthCounts.class)
        @SqlQuery("select year, month, \n" +
            "sum(case when draft_dataset = true then ds_count else 0 end) as created_count,\n" +
            "sum(case when draft_dataset = false then ds_count else 0 end) as published_count\n" +
            "from vw_mendeley_ds_counts\n" +
            "where year > 1994\n" +
            "and scival_id in (select sv_id as scival_id from accounts where sis_hq = :accountId)\n" + 
            "group by year, month\n" +
            "order by year, month;")
        List<MendeleyDataYrMonthCountResult> getMendeleyDatasetYrMonthCountData(@Bind("accountId") int accountId);
    }
    
    /* GET DATASET SIZES FOR MENDELEY */
    interface GetDatasetSizes {
        class DatasetSizes implements ResultSetMapper<MendeleyDatasetSizesResult> {
            @Override
            public MendeleyDatasetSizesResult map(int row, ResultSet rst, StatementContext ctxStatement) throws SQLException {
                return new MendeleyDatasetSizesResult(rst.getLong(1), rst.getBoolean(2));
            }
        }
        @Mapper(DatasetSizes.class)
        @SqlQuery("select sum(total_file_size) as total, draft_dataset\n" +
            "from mendeley_data\n" +
            "where (scival_id in (select sv_id as scival_id from accounts where sis_hq = :accountId))\n" +
            "group by draft_dataset;")
                        List<MendeleyDatasetSizesResult> getMendeleyDatasetSizesData(@Bind("accountId") int accountId);
    }
    interface GetLastUpdatedDate {
        class DatasetLastUpdatedDate implements ResultSetMapper<MendeleyDatasetLastUpdatedDateResult> {
            @Override
            public MendeleyDatasetLastUpdatedDateResult map(int row, ResultSet rst, StatementContext ctxStatement) throws SQLException {
                return new MendeleyDatasetLastUpdatedDateResult(rst.getDate(1).toString());
            }
        }
        @Mapper(DatasetLastUpdatedDate.class)
        @SqlQuery("select lastupdated from epic_data_lastupdated where app='mendeley_data'")
        List<MendeleyDatasetLastUpdatedDateResult> getMendeleyLastUpdatedDate();
    }

    // most viewed
        interface GetDatasetViews {
        class DatasetViews implements ResultSetMapper<MendeleyDatasetViewResult> {
            @Override
            public MendeleyDatasetViewResult map(int row, ResultSet rst, StatementContext ctxStatement) throws SQLException {
                return new MendeleyDatasetViewResult(rst.getString(1), rst.getArray(2), rst.getInt(3), rst.getString(4));
            }
        }
        @Mapper(DatasetViews.class)
        @SqlQuery("select dataset_name, contributor_names, views, id\n" +
                "from mendeley_data\n" +
                "where (scival_id in (select sv_id as scival_id from accounts where sis_hq = :accountId))\n" +
                "and views >0\n" +
                "order by views desc\n" +
                "limit 10;")
                List<MendeleyDatasetViewResult> getMendeleyDatasetViewData(@Bind("accountId") int accountId);
    }
        
        // top datasets by storage
        interface GetDatasetStorage {
        class DatasetStorage implements ResultSetMapper<MendeleyDatasetStorageResult> {
            @Override
            public MendeleyDatasetStorageResult map(int row, ResultSet rst, StatementContext ctxStatement) throws SQLException {
                return new MendeleyDatasetStorageResult(rst.getString(1), rst.getArray(2), rst.getLong(3), rst.getString(4));
//                return new MendeleyDatasetStorageResult(rst.getString(1), rst.getString(2), rst.getLong(3), rst.getString(4));
            }
        }
        @Mapper(DatasetStorage.class)
        @SqlQuery("select dataset_name, contributor_names, total_file_size, id\n" +
                "from mendeley_data\n" +
                "where (scival_id in (select sv_id as scival_id from accounts where sis_hq = :accountId))\n" +
                "and total_file_size >0\n" +
                "and contributor_names is not null\n" +
                "order by total_file_size desc\n" +
                "limit 10;")
                List<MendeleyDatasetStorageResult> getMendeleyDatasetStorageData(@Bind("accountId") int accountId);
    }
    
     // top authors by storage
        interface GetDatasetAuthorStorage {
        class AuthorStorage implements ResultSetMapper<MendeleyDatasetAuthorStorageResult> {
            @Override
            public MendeleyDatasetAuthorStorageResult map(int row, ResultSet rst, StatementContext ctxStatement) throws SQLException {
                return new MendeleyDatasetAuthorStorageResult(rst.getString(1), rst.getLong(2));
            }
        }
        @Mapper(AuthorStorage.class)
        @SqlQuery("select author, sum(total_file_size) as tot_size\n" +
                "from (  select distinct unnest (contributor_names) as author, total_file_size\n" +
                "from mendeley_data\n" +
                "where (scival_id in (select sv_id as scival_id from accounts where sis_hq = :accountId))\n" +
                "order by author ) as x\n" +
                "group by author\n" +
                "order by tot_size desc\n" +
                "LIMIT 10;")
        List<MendeleyDatasetAuthorStorageResult> getMendeleyDatasetAuthorStorageData(@Bind("accountId") int accountId);
    }
        
    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
        int accountId = Integer.parseInt(pIDs.get(0).value);

        GetDatasetYrMonthCounts datasetCountQuery = PostgresClient.getDBI().onDemand(GetDatasetYrMonthCounts.class);
        List<MendeleyDataYrMonthCountResult> DSCounts = datasetCountQuery.getMendeleyDatasetYrMonthCountData(accountId);
        //
        GetDatasetSizes datasetSizeQuery = PostgresClient.getDBI().onDemand(GetDatasetSizes.class);
        List<MendeleyDatasetSizesResult> DSSizes = datasetSizeQuery.getMendeleyDatasetSizesData(accountId);
        //
        GetLastUpdatedDate datasetLastUpdatedDate = PostgresClient.getDBI().onDemand(GetLastUpdatedDate.class);
        List<MendeleyDatasetLastUpdatedDateResult> LastUpdatedDate = datasetLastUpdatedDate.getMendeleyLastUpdatedDate();


        GetDatasetViews datasetViewsQuery = PostgresClient.getDBI().onDemand(GetDatasetViews.class);
        List<MendeleyDatasetViewResult> DSMostViewed = datasetViewsQuery.getMendeleyDatasetViewData(accountId);
        
        GetDatasetStorage datasetStorageQuery = PostgresClient.getDBI().onDemand(GetDatasetStorage.class);
        List<MendeleyDatasetStorageResult> DSMostStorageUsed = datasetStorageQuery.getMendeleyDatasetStorageData(accountId);
        
        GetDatasetAuthorStorage datasetAuthorStorageQuery = PostgresClient.getDBI().onDemand(GetDatasetAuthorStorage.class);
        List<MendeleyDatasetAuthorStorageResult> DSMostStorageUsedByAuthor = datasetAuthorStorageQuery.getMendeleyDatasetAuthorStorageData(accountId);
        
        if (DSCounts.isEmpty() ) {
      // most viewed with live was 10....
      // Commenting out per Mendeley Data as ritense is awaiting final feedback on a pull request (as of 21-Mar-18)
//        if (DSCounts.isEmpty() || DSSizes.isEmpty() /* || DSMostViewed.isEmpty() */|| DSMostStorageUsed.isEmpty() || DSMostStorageUsedByAuthor.isEmpty()) {
            // Maybe these should be broke up but OPEN QUESTION to product as this is one api call?
            throw new WebApplicationException(ErrorResponse.status(Response.Status.NO_CONTENT)
                    .setMessage("No data available for the queried institution.")
                    .build());
        }
        ObjectNode jsRoot = jsFactory.objectNode();
        String EpicLastUpdateDate= LastUpdatedDate.get(0).lastupdated;
        /* NOW START BUILDING UP JSON DATA */
        ArrayNode jsResults = jsFactory.arrayNode();
        for (MendeleyDataYrMonthCountResult entry : DSCounts) {
            ObjectNode jsObject = jsResults.addObject();
            jsObject.put("year", entry.dsYear);
            jsObject.put("month", entry.dsMonth);
            jsObject.put("created_datasets", entry.createdCount);
            jsObject.put("published_datasets", entry.publishedCount);
        }
        jsRoot.set("datasets_created_and_published", jsResults);
        
        
        // Total sizes for published/draft
        for (MendeleyDatasetSizesResult entry : DSSizes) {
            long datasetSize = entry.total; // could be empty
            if(entry.draft) {
                jsRoot.put("drafted_dataset_size", datasetSize);
            } else {
                jsRoot.put("published_dataset_size", datasetSize);
            }
        }
        jsRoot.put("last_updated_date", EpicLastUpdateDate);

        // most viewed datasets
        ArrayNode jsViewResults = jsFactory.arrayNode();
        for (MendeleyDatasetViewResult entry : DSMostViewed) {
                
            ObjectNode jsObject = jsViewResults.addObject();
            jsObject.put("title", entry.datasetName);

             ArrayNode authorArrayNode = jsObject.putArray("authors");
            for (String author : entry.authors) {
                authorArrayNode.add(author);
            }

            jsObject.put("view_count", entry.views);
            jsObject.put("id", entry.id);
        }
        jsRoot.set("most_viewed_datasets", jsViewResults);

        // top  datasets by storage used
        // title | storageused | auth array
        ArrayNode jsDatasetStorageResults = jsFactory.arrayNode();
        for (MendeleyDatasetStorageResult entry : DSMostStorageUsed) {
                
            ObjectNode jsObject = jsDatasetStorageResults.addObject();
            jsObject.put("title", entry.datasetName);
            jsObject.put("storage_used", entry.storageUsed);
            jsObject.put("id", entry.id);
            
            ArrayNode authorArrayNode = jsObject.putArray("authors");
                for (String author : entry.authors) {
                    authorArrayNode.add(author);
                }
        }

        jsRoot.set("top_datasets_by_storage", jsDatasetStorageResults);      
        
        // highest storage used by authors
        ArrayNode jsAuthStorageResults = jsFactory.arrayNode();
        for (MendeleyDatasetAuthorStorageResult entry : DSMostStorageUsedByAuthor) {
            ObjectNode jsObject = jsAuthStorageResults.addObject();
            jsObject.put("author", entry.authors);
            jsObject.put("storage_used", entry.storageUsed);
        }
        jsRoot.set("top_authors_by_storage", jsAuthStorageResults);
        
        return Response.ok(jsRoot).build();
    }
}