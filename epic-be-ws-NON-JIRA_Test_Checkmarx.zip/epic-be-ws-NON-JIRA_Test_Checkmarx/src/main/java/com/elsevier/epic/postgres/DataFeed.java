/**
 * The DataFeed class is implemented by API interfaces that need to supply their own custom data feed.
 *
 * They can be referenced from the data schema as in the following example:
 *
 * <resource ...>
 *   <datafeed class="com.elsevier.ws.extensions.RMDArticle"/>
 * </resource>
 *
 * Please refer to the PostProcess interface for workers that are applied after data retrieval.
 */

package com.elsevier.epic.postgres;

import com.elsevier.epic.types.IDValue;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

public interface DataFeed {
   Response query(HttpServletRequest pRequest, ArrayList<IDValue> ids, Map<String, String> parameters) throws IOException;
}
