/**
 * The /test/ resources are used (primarily) for integration testing.
 *
 * The /test/noresponse interface never sends a response to the client.  For example, you can use it to test how a
 * load balancer deals with a server that is alive but unresponsive.
 *
 * The /test/exception interface generates a server exception.  Depending on the configuration, this will normally
 * result in an email being sent to the administrator and a status health check being triggered.
 */

package com.elsevier.epic.core;

import com.elsevier.epic.exceptions.AppException;
import com.elsevier.epic.jaxb.InterfaceType;
import com.elsevier.epic.jaxb.Webservice;
import com.elsevier.epic.types.InterfaceParser;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

@Path("/test")
@Produces(MediaType.APPLICATION_JSON)
public class TestFilter implements InterfaceParser {
   private static final Logger LOG = Log.getLogger(TestFilter.class);

   final String interfacePath;
   public TestFilter(String path) throws InstantiationException {
      this.interfacePath = path;
   }

   @Path("/exception")
   @GET
   public Response getException(@Context HttpServletRequest pRequest) {
      throw new AppException("This exception was manually generated for testing purposes.");
   }

   @Path("noresponse")
   @GET
   public Response getResource(@Context HttpServletRequest pRequest) {
      String paramPause = pRequest.getParameter("pause");

      if ((paramPause != null) && (!paramPause.isEmpty())) {
         try {
            int pause = Integer.parseInt(paramPause);
            Thread.sleep(pause * 1000);
         }
         catch (InterruptedException ex) { }

         return Response.ok().build();
      }
      else {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
            .setMessage("The 'pause' parameter is required.")
            .build());
      }
   }

   @Override
   public void parseInterface(ServerConfig pConfig, InterfaceType pInterface, Webservice pServiceXML) {
      refreshInterface(pInterface, pServiceXML);
   }

   @Override
   public void refreshInterface(InterfaceType pInterface, Webservice pServiceXML) {

   }
}
