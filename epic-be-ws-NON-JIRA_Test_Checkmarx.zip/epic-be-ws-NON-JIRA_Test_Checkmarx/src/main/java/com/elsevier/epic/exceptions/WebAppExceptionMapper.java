/*
This exception mapper ensures that there is consistency in the output of our HTTP responses.  It does this by
converting the WebApplicationException to an ErrorResponse object, which is returned to the HTTP client as a JSON
message.  Please refer to the ErrorResponse class for further information.
*/

package com.elsevier.epic.exceptions;

import com.elsevier.epic.core.ErrorResponse;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class WebAppExceptionMapper implements ExceptionMapper<WebApplicationException> {
   @Override
   public Response toResponse(WebApplicationException pException) {
      return ErrorResponse.status(Status.fromStatusCode(pException.getResponse().getStatus()))
         .setException(pException)
         .setMessage(pException.getMessage())
         .build();
   }
}
