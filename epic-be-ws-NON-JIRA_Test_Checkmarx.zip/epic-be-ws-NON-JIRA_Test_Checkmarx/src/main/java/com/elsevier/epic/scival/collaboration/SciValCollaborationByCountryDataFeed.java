package com.elsevier.epic.scival.collaboration;

import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.types.IDValue;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Map;

/**
 * No arg builder for SciValCollaborationByCountry.  This is needed because DataFeeds are created via reflection and so no easy way to inject collaborators for testing.
 * Therefore I extract all logic into SciValCollaborationByCountry and delegate from this instance.
 */
public class SciValCollaborationByCountryDataFeed implements DataFeed {
   private final SciValCollaborationByCountry strategy = new SciValCollaborationByCountry(
         new ScivalCollaboratingEntityEndpointCall(),
         new ScivalFieldWeightCitImpactEndpointCall(),
         new CountryNameLookupImpl(),
         new AccountLookupImpl(),
         new CurrentYearImpl()
   );

   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> ids, Map<String, String> parameters) {
      return strategy.query(new GetAccountFromIds(ids), new GetCountryFromIds(ids), new GetStartAndEndYearFromParameters(parameters));
   }
}
