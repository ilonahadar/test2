package com.elsevier.epic.scival.collaboration;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

public class GetFWCIForInstitution {
    private final ScivalFieldWeightCitImpactEndpoint scivalFieldWeightCitImpactEndpoint;

    private ScivalCallResponse scivalCallResponse;

    private float fwci;
    public GetFWCIForInstitution(ScivalFieldWeightCitImpactEndpoint scivalFieldWeightCitImpactEndpoint) {
        this.scivalFieldWeightCitImpactEndpoint = scivalFieldWeightCitImpactEndpoint;
    }

    public void call(int scivalInstitutionId, int startYear, int endYear) {
        scivalCallResponse = scivalFieldWeightCitImpactEndpoint.call(scivalInstitutionId, startYear, endYear);
        if (scivalCallResponse.success) {
            ScivalFieldWeightCitImpactResponseParser parser = new ScivalFieldWeightCitImpactResponseParser(scivalCallResponse.json);
            fwci = parser.value;
        }
    }

    public float getFwci() {
        return fwci;
    }

    public ScivalCallResponse getScivalCallResponse() {
        return scivalCallResponse;
    }
}
