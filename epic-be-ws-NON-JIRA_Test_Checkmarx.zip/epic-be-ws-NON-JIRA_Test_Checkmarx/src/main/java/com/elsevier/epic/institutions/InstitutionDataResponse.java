package com.elsevier.epic.institutions;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.google.common.base.Objects;

import java.util.List;
import java.util.Map;

@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class InstitutionDataResponse {
    private int svId;

    private String svName;

    private String instName;

    private String segment;

    private String customerId;

    private String country;

    private String superAccountType;

    private List<Integer> accountId;

    private List<Map<String, Object>> acctIdInfo;

    private List<String> platform;

    private List<Map<String, String>> affiliations;

    private List<Map<String, String>> metricDataAvailable;

    public void setSvId(final int svId) {
        this.svId = svId;
    }

    public void setSvName(final String svName) {
        this.svName = svName;
    }

    public void setInstName(final String instName) {
        this.instName = instName;
    }

    public void setSegment(final String segment) {
        this.segment = segment;
    }

    public void setCustomerId(final String customerId) {
        this.customerId = customerId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(final String country) {
        this.country = country;
    }

    public void setSuperAccountType(final String superAccountType) {
        this.superAccountType = superAccountType;
    }

    public void setAccountId(final List<Integer> accountId) {
        this.accountId = accountId;
    }

    public void setAcctIdInfo(final List<Map<String, Object>> acctIdInfo) {
        this.acctIdInfo = acctIdInfo;
    }

    public void setPlatform(final List<String> platform) {
        this.platform = platform;
    }

    public void setAffiliations(final List<Map<String, String>> affiliations) {
        this.affiliations = affiliations;
    }

    public List<Map<String, String>> getMetricDataAvailable() {
        return metricDataAvailable;
    }

    public void setMetricDataAvailable(final List<Map<String, String>> metricDataAvailable) {
        this.metricDataAvailable = metricDataAvailable;
    }

    public int getSvId() {
        return svId;
    }

    public String getSvName() {
        return svName;
    }

    public String getInstName() {
        return instName;
    }

    public String getSegment() {
        return segment;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getSuperAccountType() {
        return superAccountType;
    }

    public List<Integer> getAccountId() {
        return accountId;
    }

    public List<Map<String, Object>> getAcctIdInfo() {
        return acctIdInfo;
    }

    public List<String> getPlatform() {
        return platform;
    }

    public List<Map<String, String>> getAffiliations() {
        return affiliations;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        InstitutionDataResponse that = (InstitutionDataResponse) o;
        return svId == that.svId &&
               Objects.equal(svName, that.svName) &&
               Objects.equal(instName, that.instName) &&
               Objects.equal(segment, that.segment) &&
               Objects.equal(customerId, that.customerId) &&
               Objects.equal(country, that.country) &&
               Objects.equal(superAccountType, that.superAccountType) &&
               Objects.equal(accountId, that.accountId) &&
               Objects.equal(acctIdInfo, that.acctIdInfo) &&
               Objects.equal(platform, that.platform) &&
               Objects.equal(affiliations, that.affiliations) &&
               Objects.equal(metricDataAvailable, that.metricDataAvailable);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(svId, svName, instName, segment, customerId, country, superAccountType, accountId, acctIdInfo, platform, affiliations,
                                metricDataAvailable);
    }
}
