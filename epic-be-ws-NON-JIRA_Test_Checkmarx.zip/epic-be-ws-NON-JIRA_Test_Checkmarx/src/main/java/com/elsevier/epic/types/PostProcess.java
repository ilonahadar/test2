/**
 * The PostProcess interface is implemented by classes that manipulate data after its retrieval or generation.
 *
 * Such an interface can be referenced from the data schema as in the following example:
 *
 * <resource ...>
 *   <postprocess class="com.elsevier.ws.extensions.CountryCode">
 *     <option name="customOption">value</option>
 *   </postprocess>
 * </resource>
 *
 * Please refer to the DataFeed interface for on-the-fly, custom data generation.
 */

package com.elsevier.epic.types;

import com.elsevier.epic.jaxb.PostprocessType;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import java.util.ArrayList;
import java.util.Map;

public interface PostProcess {
   void postProcess(PostprocessType postProcess, Response pResponse, ArrayList<IDValue> pPathParams, Map<String, String> pQueryParams);
   ResponseBuilder noResults(ArrayList<IDValue> pPathParams, Map<String, String> pQueryParams);
}
