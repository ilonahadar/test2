package com.elsevier.epic.mie;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class JournalMetrics implements DataFeed {

    private static final Logger LOG = Log.getLogger(JournalMetrics.class);
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

    PreparedStatement getStatement(Connection con) throws SQLException {

        PreparedStatement ps = con.prepareStatement(getResourceString("/mie_journal_metrics.sql"));
        ps.setQueryTimeout(60);
        return ps;
    }

    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {

        if (pIDs.size() < 1) throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);

        String paramAccountID  = pIDs.get(0).value;
        String issn = pIDs.get(1).value;
        String paramSubjectID = pIDs.get(2).value;

        int accountID = validateIntParams(paramAccountID);
        int subjectID = validateIntParams(paramSubjectID);

        ObjectNode jsRoot = jsFactory.objectNode();
        ObjectNode jsParams = jsFactory.objectNode();
        jsRoot.set("parameters", jsParams);
        jsParams.put("sisid", paramAccountID);
        jsParams.put("issn", issn);
        jsParams.put("subjectid", paramSubjectID);

        queryCounter(jsRoot, accountID, issn, subjectID);
        return Response.ok(jsRoot).build();
    }

    private void queryCounter(ObjectNode pResult, int pSIS, String pISSN, int pSubID){

        try (Connection con = PostgresClient.getConnection();
             PreparedStatement ps = getStatement(con)){

            ps.setInt(1, pSIS);
            ps.setString(2, pISSN);
            ps.setInt(3, pSubID);
            ps.setInt(4, pSIS);
            ps.setString(5, pISSN);
            ps.setInt(6, pSubID);

            if (!CoreServer.isProduction()) LOG.info(ps.toString());

            ObjectNode journalMetrics = jsFactory.objectNode();

            ps.execute();

            ReaderJournalMetrics(ps, journalMetrics, "ArticlesReadOverTime");
            ps.getMoreResults();
            AuthorJournalMetrics(ps, journalMetrics, "ArticlesPublishedOverTime");


            pResult.set("result", journalMetrics);
        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }
    }

    static private void ReaderJournalMetrics(PreparedStatement ps, ObjectNode ArticlesRead, String name) throws java.sql.SQLException {

        ResultSet rst = ps.getResultSet();

        ArrayNode rowNode = jsFactory.arrayNode();

        while (rst.next()) {

            String year = rst.getString(1);
            String month = rst.getString(2);
            String total = rst.getString(3);

            ObjectNode locNode = jsFactory.objectNode();

            locNode.put("Year", year);
            locNode.put("Month", month);
            locNode.put("Total", total);

            rowNode.add(locNode);

        }

        ArticlesRead.set(name, rowNode);
    }

    static private void AuthorJournalMetrics(PreparedStatement ps, ObjectNode ArticlesRead, String name) throws java.sql.SQLException {

        ResultSet rst = ps.getResultSet();

        ArrayNode rowNode = jsFactory.arrayNode();

        while (rst.next()) {

            String year = rst.getString(1);
            //String month = rst.getString(2);
            String total = rst.getString(2);

            ObjectNode locNode = jsFactory.objectNode();

            locNode.put("Year", year);
            //locNode.put("Month", month);
            locNode.put("Total", total);

            rowNode.add(locNode);

        }

        ArticlesRead.set(name, rowNode);
    }

    static private int validateIntParams(String pName) {

        int pVal;

        try {
            pVal = Integer.parseInt(pName);
        }
        catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
                    .setMessage("Invalid ID '" + pName + "'")
                    .setException(ex)
                    .build());
        }
        return pVal;
    }

    static private String getResourceString(String pName) {
        // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
        // all available resource files.
        InputStream isResource = String.class.getResourceAsStream(pName);
        if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
        else throw new RuntimeException("Could not find resource '" + pName + "'");
    }

}
