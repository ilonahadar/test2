package com.elsevier.epic.cop5;

import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.types.Journal;
import com.elsevier.epic.utility.SDJournals;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.skife.jdbi.v2.DBI;
import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TopJournalTurnawaysByFamilyAndCategory implements DataFeed {
    private final JsonNodeFactory jsFactory = new JsonNodeFactory(false);
    private final DBI postgresClient;
    private final SDJournals sdJournals;

    public TopJournalTurnawaysByFamilyAndCategory() {
        postgresClient = PostgresClient.getInstance().getDatabaseClient();
        sdJournals = SDJournals.getInstance();
    }

    public TopJournalTurnawaysByFamilyAndCategory(DBI postgresClient, SDJournals sdJournals) {
        this.postgresClient = postgresClient;
        this.sdJournals = sdJournals;
    }

    static class QueryResult {
        final Integer year;
        final Integer month;
        final String issn;
        final Integer total;

        QueryResult(final Integer pYear,
                    final Integer pMonth,
                    final String pIssn,
                    final Integer pTotal) {
            this.year = pYear;
            this.month = pMonth;
            this.issn = pIssn;
            this.total = pTotal;
        }
    }

    interface Query {
        class QueryMap implements ResultSetMapper<QueryResult> {
            @Override
            public QueryResult map(final int row,
                                   final ResultSet rst,
                                   final StatementContext ctxStatement) throws SQLException {
                return new QueryResult(rst.getInt("year"), rst.getInt("month"), rst.getString("issn"), rst.getInt("total"));
            }
        }

        @Mapper(Query.QueryMap.class)
        @SqlQuery("SELECT year, month, issn, SUM(total) as total FROM vw_account_top_turnaways_asjc_journal_family_c5 WHERE sis=:accountId AND code=:code GROUP BY year, month, issn ORDER BY total DESC;")
        List<QueryResult> filterByCategoryCode(@Bind("accountId") int accountId, @Bind("code") int code);

        @Mapper(Query.QueryMap.class)
        @SqlQuery("SELECT distinct year, month, issn, SUM(total) as total FROM vw_account_top_turnaways_asjc_journal_family_c5 WHERE sis=:accountId AND journal_family=:journal_family GROUP BY year, month, issn, code ORDER BY total DESC;")
        List<QueryResult> filterByJournalFamily(@Bind("accountId") int accountId, @Bind("journal_family") String family);

        @Mapper(Query.QueryMap.class)
        @SqlQuery("SELECT year, month, issn, SUM(total) as total FROM vw_account_top_turnaways_asjc_journal_family_c5 WHERE sis=:accountId AND journal_family=:journal_family AND code=:code GROUP BY year, month, issn ORDER BY total DESC;")
        List<QueryResult> filterByCategoryAndJournalFamily(@Bind("accountId") int accountId,
                                                           @Bind("journal_family") String journalFamily,
                                                           @Bind("code") int code);
    }

    @Override
    public Response query(final HttpServletRequest pRequest,
                          final ArrayList<IDValue> pIDs,
                          final Map<String, String> pParameters) {

        final JournalTurnawaysParams params = getParameters(pIDs);

        final List<QueryResult> results = getResultsSet(params);
        Integer maxNumberOfJournalsRequested = params.getMaxNumberOfJournals();
        Integer numberOfJournals = results.size() >= maxNumberOfJournalsRequested ? maxNumberOfJournalsRequested : results.size();

        ArrayNode jsResults = jsFactory.arrayNode();

        for (int index = 0; index < numberOfJournals; index++) {
            ObjectNode obj = jsResults.addObject();
            String issn = results.get(index).issn;
            obj.put("issn", issn);
            Journal journal = sdJournals.getJournals(issn);
            int total = results.get(index).total;
            obj.put("total", total);
            if (journal != null) {
                obj.put("title", journal.title);
            }
        }

        ObjectNode jsRoot = jsFactory.objectNode();
        jsRoot.put("totalRecords", numberOfJournals);
        if (numberOfJournals > 0) {
            jsRoot.put("reportDate", String.format("%04d-%02d-01", results.get(0).year, results.get(0).month)); /* "01" is hard-coded? */
            jsRoot.put("period", 12); /* hard-coded ? */
            jsRoot.put("interval", "monthly");
        }
        jsRoot.set("results", jsResults);
        return Response.ok(jsRoot).build();
    }

    private JournalTurnawaysParams getParameters(ArrayList<IDValue> pIDs) {
        int accountId = Integer.parseInt(pIDs.get(0).value);
        int count = Integer.parseInt(pIDs.get(1).value);
        String family = pIDs.get(2).value;
        String category = pIDs.get(3).value;

        return new JournalTurnawaysParams(accountId, count, family, category);
    }

    private List<QueryResult> getResultsSet(final JournalTurnawaysParams parameters) {
        String journalFamily = parameters.getFamily();
        String journalCategory = parameters.getCategory();
        Integer accountId = parameters.getAccountId();

        List<QueryResult> results;

        if (journalFamily.equals("All") && !journalCategory.equals("All")) {
            results = postgresClient.onDemand(Query.class).filterByCategoryCode(accountId, Integer.parseInt(journalCategory));
        } else if (journalCategory.equals("All") && !journalFamily.equals("All")) {
            results = postgresClient.onDemand(Query.class).filterByJournalFamily(accountId, journalFamily);
        } else {
            results = postgresClient.onDemand(Query.class).filterByCategoryAndJournalFamily(accountId, journalFamily,
                                                                                            Integer.parseInt(journalCategory));
        }

        return results;
    }
}
