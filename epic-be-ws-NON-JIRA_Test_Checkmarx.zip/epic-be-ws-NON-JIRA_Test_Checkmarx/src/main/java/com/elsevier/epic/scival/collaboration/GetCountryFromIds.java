package com.elsevier.epic.scival.collaboration;

import com.elsevier.epic.types.IDValue;

import java.util.ArrayList;

public class GetCountryFromIds implements SciValCollaborationByCountry.Country {

    private ArrayList<IDValue> ids;

    public GetCountryFromIds(ArrayList<IDValue> ids) {
        this.ids = ids;
    }

    @Override
    public int getCountryISONumber() {
        return Integer.parseInt(ids.get(1).value);
    }
}
