/**
 * User credential storage class.  This is for storage only and does not have any bearing on the actual authorisation
 * methodology that is in use.
 */

package com.elsevier.epic.auth;

import org.apache.commons.codec.digest.DigestUtils;
import org.glassfish.jersey.message.internal.ReaderWriter;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

public class UserCredentials {
   public final String realm;
   public final Map<String, String> authKeys;
   public final String bodyMD5;
   public final String method;
   public String uid = null;
   public String firstName = null;
   public String surname = null;
   public String email = null;
   public String serverSignature = null;
   public ArrayList<Integer> sis = null; // Set when authentication is confirmed.  Retrieved from database user table.
   public int accessLevel; // Set when authentication is confirmed.  Retrieved from database user table.

   public static final int AL_USER = 0;
   public static final int AL_SUPER_USER = 1;
   public static final int AL_ELSEVIER = 2;
   public static final int AL_ADMIN = 3;

   public UserCredentials(String pRealm, Map<String, String> pKeys, HttpServletRequest pRequest) throws IOException {
      this.authKeys = pKeys;
      this.realm    = pRealm;
      this.method   = pRequest.getMethod();
      if ("auth-int".equals(pKeys.get("qop"))) this.bodyMD5 = DigestUtils.md5Hex(readBody(pRequest));
      else this.bodyMD5 = null;
   }

   private String readBody(HttpServletRequest request) throws IOException {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      ServletInputStream in = request.getInputStream();
      final StringBuilder b = new StringBuilder();
      if (in.available() > 0) {
         ReaderWriter.writeTo(in, out);
         byte[] e = out.toByteArray();
         if (e.length > 0) b.append(new String(e));
      }
      return b.toString();
   }
}
