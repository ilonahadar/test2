// Useful open-source utility functions.

package com.elsevier.epic.utility;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class Utility {
   static public String outputTimestamp(long pTimestamp) {
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
      String result = sdf.format(new Date(pTimestamp));
      return result;
   }

   /**
    * Make any string safe to use as a JSON value
    *
    * @param str
    * @return
    */

   public static String escJSON(String str) {
      str = str.replace("\\","\\\\");
      str = str.replace("\"", "\\\"");
      str = str.replace("\r\n", "\\n");
      str = str.replace("\n", "\\n");
      str = str.replace("\r", "\\n");
      str = str.replace("\t", "\\t");
      return str;
   }

   /**
    * Convert a string to an integer value without any chance of an exception.
    *
    * @param str The string to convert.
    * @return The equivalent long value is returned.  0 is returned on failure.
    */

   static public int readInt(String str) {
      if ((str == null) || (str.isEmpty())) return 0;
      try {
         return Integer.parseInt(str);
      }
      catch (Exception e) {
         return 0;
      }
   }
}
