package com.elsevier.epic.cop5;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class EvsActivityMetrics implements DataFeed{

     private static final Logger LOG = Log.getLogger(EvsActivityMetrics.class);
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe

    PreparedStatement getStatement(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement(getResourceString("/evs_activity_metrics_c5.sql"));
        ps.setQueryTimeout(60);
        return ps;
    }

    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {

        if (pIDs.size() < 1) throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);

        String paramAccountID  = pIDs.get(0).value;
        String paramSubjectID = pIDs.get(1).value;

        int accountID = validateIntParams(paramAccountID);
        int subjectID = validateIntParams(paramSubjectID);

        ObjectNode jsRoot = jsFactory.objectNode();
        ObjectNode jsParams = jsFactory.objectNode();
        jsRoot.set("parameters", jsParams);
        jsParams.put("sisid", paramAccountID);
        jsParams.put("subjectid", paramSubjectID);

        queryCounter(jsRoot, accountID, subjectID);
        return Response.ok(jsRoot).build();
    }

    private void queryCounter(ObjectNode pResult, int pSIS, int pSubID){

        try (Connection con = PostgresClient.getConnection();
             PreparedStatement ps = getStatement(con)){

            ps.setInt(1, pSIS);
            ps.setInt(2, pSubID);
            ps.setInt(3, pSIS);
            ps.setInt(4, pSubID);
            ps.setInt(5, pSIS);
            ps.setInt(6, pSubID);
            ps.setInt(7, pSIS);
            ps.setInt(8, pSubID);
            ps.setInt(9, pSIS);
            ps.setInt(10, pSubID);

            if (!CoreServer.isProduction()) LOG.info(ps.toString());

            ObjectNode headNode = jsFactory.objectNode();

            ps.execute();

            getSDUsageBySubject(ps, headNode, "usage");
            ps.getMoreResults();
            getSCMetricsBySubject(ps, headNode, "publications");
            ps.getMoreResults();
            getSCMetricsBySubject(ps, headNode, "references");
            ps.getMoreResults();
            getSCMetricsBySubject(ps, headNode, "citations");
            ps.getMoreResults();
            getSCMetricsBySubject(ps, headNode, "patent_citations");

            pResult.set("result", headNode);
        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }
    }
    static private void getSDUsageBySubject(PreparedStatement ps, ObjectNode jsUsage, String name) throws SQLException {

        ResultSet rst = ps.getResultSet();
        LOG.info("Column count for getSDUsageBySubject: "+rst.getMetaData().getColumnCount());

        ArrayNode rowNode = jsFactory.arrayNode();
        //ObjectNode rowNode = jsFactory.objectNode();

        while (rst.next()) {
            String year = rst.getString(1);
            String all_journals_total = rst.getString(2);
            String all_journals_total_not_oa = rst.getString(3);
            String fc_journals_total = rst.getString(4);
            String fc_journals_total_not_oa = rst.getString(5);

            ObjectNode locNode = jsFactory.objectNode();

            locNode.put("year", year);
            locNode.put("all_journals_total", all_journals_total);
            locNode.put("all_journals_total_not_oa", all_journals_total_not_oa);
            locNode.put("fc_journals_total", fc_journals_total);
            locNode.put("fc_journals_total_not_oa", fc_journals_total_not_oa);

            rowNode.add(locNode);

        }

        jsUsage.set(name, rowNode);
    }

        static private void getSCMetricsBySubject(PreparedStatement ps, ObjectNode jsUsage, String name) throws SQLException {

        ResultSet rst = ps.getResultSet();

        ObjectNode publisherNode = jsFactory.objectNode();
        ArrayNode rowNode1 = jsFactory.arrayNode();
        ArrayNode rowNode2 = jsFactory.arrayNode();
        ArrayNode rowNode3 = jsFactory.arrayNode();
        ArrayNode rowNode4 = jsFactory.arrayNode();
        //ObjectNode rowNode = jsFactory.objectNode();

        while (rst.next()) {

            String publisher = rst.getString(1);
            String year = rst.getString(2);
            String all_journals_total = rst.getString(3);
            String all_journals_total_not_oa = rst.getString(4);
            String fc_journals_total = rst.getString(5);
            String fc_journals_total_not_oa = rst.getString(6);

            if (publisher.equals("Elsevier")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("year", year);
                locNode.put("all_journals_total", all_journals_total);
                locNode.put("all_journals_total_not_oa", all_journals_total_not_oa);
                locNode.put("fc_journals_total", fc_journals_total);
                locNode.put("fc_journals_total_not_oa", fc_journals_total_not_oa);

                rowNode1.add(locNode);

                publisherNode.set(publisher, rowNode1);
            }

            if (publisher.equals("Springer Nature")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("year", year);
                locNode.put("all_journals_total", all_journals_total);
                locNode.put("all_journals_total_not_oa", all_journals_total_not_oa);
                locNode.put("fc_journals_total", fc_journals_total);
                locNode.put("fc_journals_total_not_oa", fc_journals_total_not_oa);

                rowNode2.add(locNode);

                publisherNode.set(publisher, rowNode2);
            }

            if (publisher.equals("Wiley-Blackwell")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("year", year);
                locNode.put("all_journals_total", all_journals_total);
                locNode.put("all_journals_total_not_oa", all_journals_total_not_oa);
                locNode.put("fc_journals_total", fc_journals_total);
                locNode.put("fc_journals_total_not_oa", fc_journals_total_not_oa);

                rowNode3.add(locNode);

                publisherNode.set(publisher, rowNode3);
            }

            if (publisher.equals("Others")) {

                ObjectNode locNode = jsFactory.objectNode();

                locNode.put("year", year);
                locNode.put("all_journals_total", all_journals_total);
                locNode.put("all_journals_total_not_oa", all_journals_total_not_oa);
                locNode.put("fc_journals_total", fc_journals_total);
                locNode.put("fc_journals_total_not_oa", fc_journals_total_not_oa);

                rowNode4.add(locNode);

                publisherNode.set(publisher, rowNode4);
            }
        }

        jsUsage.set(name, publisherNode);
    }

    static private int validateIntParams(String pName) {

        int pVal;

        try {
            pVal = Integer.parseInt(pName);
        }
        catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
                    .setMessage("Invalid ID '" + pName + "'")
                    .setException(ex)
                    .build());
        }
        return pVal;
    }

    static private String getResourceString(String pName) {
        // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
        // all available resource files.
        InputStream isResource = String.class.getResourceAsStream(pName);
        if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
        else throw new RuntimeException("Could not find resource '" + pName + "'");
    }
}
