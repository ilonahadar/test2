package com.elsevier.epic.scival.collaboration;

/**
 * Encapsulates the https://cert.api.scival.com/api//Metric/FieldWeightCitImpact endpoint
 */
public interface ScivalFieldWeightCitImpactEndpoint {
    ScivalCallResponse call(int scivalInstitutionId, int startYear, int endYear);
}
