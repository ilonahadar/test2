/*

This health checker returns an unhealthy state if any server 5xx response codes have been reported in the last
X minutes.

*/

package com.elsevier.epic.core;

import com.codahale.metrics.health.HealthCheck;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class StatusHealthCheck extends HealthCheck {
   private static final Logger LOG = Log.getLogger(StatusHealthCheck.class);
   private static final int EXCEPTION_INTERVAL = 60 * 60 * 1000;

   static private long lastExceptionTime;
   static private Object lastIssue;
   static final private Lock lock = new ReentrantLock();

   @Override
   protected Result check() throws Exception {
      LOG.info("Checking server status.");

      try {
         lock.lock();
         if ((lastIssue != null) && (System.currentTimeMillis() - lastExceptionTime < EXCEPTION_INTERVAL)) {
            if (lastIssue instanceof String) {
               return Result.unhealthy((String)lastIssue);
            }
            else if (lastIssue instanceof Throwable) {
               return Result.unhealthy((Throwable)lastIssue);
            }
         }

         return Result.healthy("No exceptions have been reported in the last " + (EXCEPTION_INTERVAL / 1000) + " minutes.");
      }
      finally {
         lock.unlock();
      }
   }

   static public void reportServerStatus(int pStatusCode, String pMessage) {
      try {
         lock.lock();
         lastExceptionTime = System.currentTimeMillis();
         lastIssue = pMessage;
      }
      finally {
         lock.unlock();
      }
   }

   static public void reportException(Exception pException) {
      try {
         lock.lock();
         lastExceptionTime = System.currentTimeMillis();
         lastIssue = pException;
      }
      finally {
         lock.unlock();
      }
   }
}
