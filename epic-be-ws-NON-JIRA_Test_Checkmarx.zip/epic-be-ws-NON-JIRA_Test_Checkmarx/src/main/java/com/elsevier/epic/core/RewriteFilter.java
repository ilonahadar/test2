/**
 * This is a standard URI rewriter with regular expressions.  The patterns are compiled up-front so that we can
 * quickly check incoming URI's when received from the client.
 */

package com.elsevier.epic.core;

import com.elsevier.epic.types.InterfaceParser;
import com.elsevier.epic.jaxb.InterfaceType;
import com.elsevier.epic.jaxb.RewriteType;
import com.elsevier.epic.jaxb.Webservice;
import org.eclipse.jetty.io.EofException;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response.Status;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RewriteFilter implements Filter, InterfaceParser {
   private static final Logger LOG = Log.getLogger(RewriteFilter.class);
   final String path;

   private final Map<Pattern, String> remap = new HashMap<>();

   public RewriteFilter(String path) {
       this.path = path;
   }

   @Override
   public void parseInterface(ServerConfig pConfig, InterfaceType pInterface, Webservice pServiceXML) {
      String basePath = pServiceXML.getBasepath();
      for (RewriteType rewrite : pInterface.getRewrite()) {
         String incomingPath = basePath + rewrite.getRequest();
         Pattern pattern = Pattern.compile(incomingPath);
         LOG.info("Rewrite \"" + incomingPath + "\" ==> \"" + basePath + rewrite.getTo() + "\"");
         remap.put(pattern, rewrite.getTo());
      }
   }

   @Override
   public void doFilter(ServletRequest pRequest, ServletResponse pResponse, FilterChain pChain) throws IOException, ServletException {
      String requestURI = ((HttpServletRequest)pRequest).getRequestURI();

      boolean redirect = false;
      for (Map.Entry<Pattern, String> entry : remap.entrySet()) {
         if (entry.getKey().matcher(requestURI).matches()) {
            String newURI = entry.getValue();
            Matcher matcher = entry.getKey().matcher(requestURI);
            if (matcher.find()) {
               for (int g=1; g <= matcher.groupCount(); g++) {
                  String value = matcher.group(g);
                  newURI = newURI.replaceAll("\\(" + (g) + "\\)", value);
               }
            }

            requestURI = newURI;
            redirect = true;
         }
      }

      if (redirect) {
         try {
            //LOG.debug("Rewrite path " + requestURI + " to " + newURI);
            ((HttpServletRequest)pRequest).getRequestDispatcher(requestURI).forward(pRequest, pResponse); // Server side redirection
            //((HttpServletResponse)response).sendRedirect(newURI); // Client side redirection
         }
         catch (WebApplicationException | EofException e) {
            // Anything that is considered handled or does not need to be reported, just catch and throw it through
            // here.  EofException is ignored because it is caused when the client terminates its socket early.
            throw e;
         }
         catch (Exception e) {
            LOG.warn(e);
            throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
               .setMessage("An unhandled exception has been detected in the server.  The site administrator has been alerted.")
               .setException(e)
               .build());
         }
      }
      else { // Do the normal behaviour
         pChain.doFilter(pRequest, pResponse);
      }
   }

   @Override
   public void init(FilterConfig filterConfig) throws ServletException { }

   @Override
   public void destroy() { }

   @Override
   public void refreshInterface(InterfaceType pInterface, Webservice pServiceXML) {
   }
}
