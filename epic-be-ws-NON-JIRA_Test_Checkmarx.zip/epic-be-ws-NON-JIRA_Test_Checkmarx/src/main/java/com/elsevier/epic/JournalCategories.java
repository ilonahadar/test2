package com.elsevier.epic;

import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.types.JournalCategory;
import com.elsevier.epic.utility.SDJournals;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Map;

public class JournalCategories implements DataFeed {
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);
   private static ArrayNode jsListAll = null;
   private static ArrayNode jsListMajor = null;

   /**
    * Optimised journal category builder - creates the JSON result once and then returns that result for all future
    * calls.
    *
    * @return
    */

   ArrayNode getCategories() {
      if (jsListAll != null) return jsListAll;

      jsListAll = jsFactory.arrayNode();
      for (Map.Entry<Integer, JournalCategory> entry : SDJournals.allCategories().entrySet()) {
         ObjectNode obj = jsListAll.addObject();
         obj.put("code", entry.getKey());
         obj.put("name", entry.getValue().name);
      }
      return jsListAll;
   }

   ArrayNode getMajorCategories() {
      if (jsListMajor != null) return jsListMajor;

      jsListMajor = jsFactory.arrayNode();
      for (Map.Entry<Integer, JournalCategory> entry : SDJournals.allCategories().entrySet()) {
         int code = entry.getKey();
         if ((code % 100) == 0) {
            ObjectNode obj = jsListMajor.addObject();
            obj.put("code", code);
            obj.put("name", entry.getValue().name);
         }
      }
      return jsListMajor;
   }

   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      String paramType  = pParameters.get("type");

      if ("major".equals(paramType)) return Response.ok(getMajorCategories()).build();
      else return Response.ok(getCategories()).build();
   }
}
