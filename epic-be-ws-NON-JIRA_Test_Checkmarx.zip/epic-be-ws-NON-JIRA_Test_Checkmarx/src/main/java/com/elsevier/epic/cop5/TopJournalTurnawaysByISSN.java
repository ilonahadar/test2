/*
This is the support code for /account/{accountID}/source/issn/{issn}/turnaways
*/

package com.elsevier.epic.cop5;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.types.Journal;
import com.elsevier.epic.utility.SDJournals;
import com.elsevier.epic.utility.Utility;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;

public class TopJournalTurnawaysByISSN implements DataFeed {
   private static final Logger LOG = Log.getLogger(TopJournalTurnawaysByISSN.class);
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);
   private static final String TNAME = "vw_journal_monthly_turnaways_c5";

   static final int MIN_YEAR = 2015;


   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      if (pIDs.size() < 2) throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);

      String paramAccount = pIDs.get(0).value;
      String paramISSN = pIDs.get(1).value;

      String paramYearStart  = pParameters.get("yearstart");
      String paramYearEnd    = pParameters.get("yearend");
      int accountID = Integer.parseInt(paramAccount);

      ObjectNode jsRoot = jsFactory.objectNode();

      int ys = Utility.readInt(paramYearStart);
      final int yearEnd;
      int y = Utility.readInt(paramYearEnd);

      Calendar cal = Calendar.getInstance();
      int currentYear = cal.get(Calendar.YEAR);
      yearEnd = (y <= 0) ? currentYear : y;

      if (ys > currentYear) {
         return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid year parameter " + ys).build();
      }

      if ((ys < 0) || (ys > yearEnd)) {
         return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid year parameters " + ys + " to " + yearEnd).build();
      }

      final int yearStart = (ys < MIN_YEAR) ? MIN_YEAR : ys;

      try (Connection con = PostgresClient.getConnection()) {
         // This query returns institution's total article turnaways within a particular journal.
         final int COL_YEAR = 1;
         final int COL_YEAR_TOTAL = 2;
         final int COL_MONTHS = 3;
         final int COL_MONTHS_IBF = 4;
         final int COL_MONTHS_BF = 5;
 
         StringBuilder sb = new StringBuilder()
                 .append("select year,year_total,months,months_IBF,months_BF from getArticles(?,?,?,?,?)");

         try (PreparedStatement psUsage = con.prepareStatement(sb.toString())) {
            psUsage.setQueryTimeout(60);
            psUsage.setString(1, paramISSN);
            psUsage.setInt(2, accountID);
            psUsage.setInt(3, yearStart);
            psUsage.setInt(4, yearEnd);
            psUsage.setString(5,TNAME);


            ArrayNode jsDownloads = jsFactory.arrayNode();
 
            if (!CoreServer.isProduction()) LOG.info(psUsage.toString());

            ObjectNode jsParameters = jsFactory.objectNode();
            jsParameters.put("account", accountID);
            jsParameters.put("yearStart", yearStart);
            jsParameters.put("yearEnd", yearEnd);
            jsRoot.set("parameters", jsParameters);
                       
            Journal j = SDJournals.getJournal(paramISSN);
            if (j != null) {
               jsRoot.put("issn", j.issn);
               jsRoot.put("title", j.title);
               jsRoot.put("publisher", j.publisher);
               jsRoot.put("imprint", j.imprint);
               jsRoot.put("srcType", j.srcType);
               jsRoot.put("srcTypeName", j.srcTypeName);
               jsRoot.put("serial", j.serial);
               jsRoot.put("subscribable", j.subscribable);
            } 
            
            try (ResultSet rst = psUsage.executeQuery()) {
               while (rst.next()) {
                  ObjectNode jsEntry = jsFactory.objectNode();

                  ObjectNode jsMonthBreakdown = jsFactory.objectNode();

                  jsEntry.put("year", rst.getInt(COL_YEAR));
                  jsEntry.put("total", rst.getInt(COL_YEAR_TOTAL));
                  
                  Array months = rst.getArray(COL_MONTHS);
                  Array monthsIBF = rst.getArray(COL_MONTHS_IBF);
                  Array monthsBF = rst.getArray(COL_MONTHS_BF);
                  Array monthsFF;

                  if ((months != null) && (monthsIBF != null) && (monthsBF != null)) {
                     Integer[] marray = (Integer[])months.getArray();
                     ArrayNode an = jsEntry.putArray("months");
   
                     ArrayNode monthBreakdown = jsEntry.putArray("monthBreakdown");

                     // Intermediate backfile
                     Integer[] marrayIBF = (Integer[])monthsIBF.getArray();
                     ArrayNode anIBF = jsMonthBreakdown.putArray("IBF");
                     // Backfile
                     Integer[] marrayBF = (Integer[])monthsBF.getArray();
                     ArrayNode anBF = jsMonthBreakdown.putArray("BF");
                     // Frontfile
                     ArrayNode anFF = jsMonthBreakdown.putArray("FF");
                     
                     for (int x=0; x < marray.length; x++) {
                         an.add(marray[x]);
                         anIBF.add(marrayIBF[x]);
                         anBF.add(marrayBF[x]);
                         // backfile calculations in ETL process, whatever is left="frontfiles"
                         anFF.add(marray[x] - ( (marrayIBF[x]) + (marrayBF[x]) ) );
                     }
                     monthBreakdown.add(jsMonthBreakdown);
                  }
                  jsDownloads.add(jsEntry);
               }
            }
            jsRoot.set("results", jsDownloads);
         }
      }
      catch (SQLException ex) {
         LOG.warn(ex);
         throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
            .setMessage("A server database failure has occurred.")
            .setException(ex)
            .build());
      }

      return Response.ok(jsRoot).build();
   }
}
