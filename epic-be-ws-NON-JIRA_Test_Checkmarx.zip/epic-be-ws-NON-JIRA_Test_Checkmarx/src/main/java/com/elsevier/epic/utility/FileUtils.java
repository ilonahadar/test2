package com.elsevier.epic.utility;

import java.io.InputStream;
import java.util.Scanner;

public class FileUtils {
    public String getResourceString(final String pName) {
        // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
        // all available resource files.
        final InputStream isResource = String.class.getResourceAsStream(pName);
        if (isResource != null) {
            final Scanner scanner = new Scanner(isResource, "UTF-8");
            final String sql = scanner.useDelimiter("\\A").next();
            scanner.close();
            return sql;
        } else {
            throw new RuntimeException("Could not find resource '" + pName + "'");
        }
    }
}
