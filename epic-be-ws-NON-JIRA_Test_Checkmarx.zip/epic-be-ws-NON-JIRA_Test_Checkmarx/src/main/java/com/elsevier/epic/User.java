/**
 * REST support for user management -- /login and /logout particularly.
 */

package com.elsevier.epic;

import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.JWTVerifyException;
import com.elsevier.epic.types.InterfaceParser;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.core.ServerConfig;
import com.elsevier.epic.auth.AuthDigest;
import com.elsevier.epic.jaxb.InterfaceType;
import com.elsevier.epic.jaxb.OptionType;
import com.elsevier.epic.jaxb.ResourceType;
import com.elsevier.epic.jaxb.Webservice;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

@Path("/user")
@Produces(MediaType.APPLICATION_JSON)
public class User implements InterfaceParser {
   private static final Logger LOG = Log.getLogger(User.class);
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe

   private final String path;
   private final Map<Pattern, ResourceType> resources;
   static public final AtomicBoolean enabled = new AtomicBoolean(false);

   static private String method = "digest";

   public User(String path) {
      this.resources = new HashMap<>();
      this.path = path;
   }

   @Path("/login")
   @GET
   public Response postUserLogin(@Context HttpServletRequest pRequest) {
      // To see how the JWT and tokens are generated, please refer to AuthFilter's authenticate() function.

      ObjectNode jsResult = jsFactory.objectNode();

      // AuthFilter provides token and tokenMap if either a valid bearer token was received or digest authentication
      // was successful.

      Map<String, Object> tokenMap = (Map<String, Object>)pRequest.getAttribute("tokenMap");

      String token = (String)pRequest.getAttribute("token");
      if (token != null) jsResult.put("BearerToken", token);

      if ((tokenMap == null) && (token != null)) {
         try {
           tokenMap = new JWTVerifier(AuthDigest.jwtSecret).verify(token);
         }
         catch (NoSuchAlgorithmException | InvalidKeyException | SignatureException | JWTVerifyException ex) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
               .setMessage(ex.getMessage())
               .setException(ex)
               .build());
         }
         catch (IllegalStateException | IOException ex) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
               .setMessage(ex.getMessage())
               .setException(ex)
               .build());
         }
      }

      if (tokenMap != null) {
         if (tokenMap.containsKey("sis")) {
            ArrayList<Integer> sis = (ArrayList<Integer>)tokenMap.get("sis");
            ArrayNode jsArray = jsFactory.arrayNode();
            for (Integer s : sis) {
               if (s != null) jsArray.add(s);
            }
            if (jsArray.size() > 0) jsResult.set("sis", jsArray);
         }

         if (tokenMap.containsKey("accounts")) {
            ArrayList<Integer> accounts = (ArrayList<Integer>)tokenMap.get("accounts");
            ArrayNode jsArray = jsFactory.arrayNode();
            for (Integer a : accounts) {
               if (a != null) jsArray.add(a);
            }
            if (jsArray.size() > 0) jsResult.set("accounts", jsArray);
         }

         if (tokenMap.containsKey("al"))    jsResult.put("accessLevel", (Integer)tokenMap.get("al"));
         if (tokenMap.containsKey("uid"))   jsResult.put("uid", (String)tokenMap.get("uid"));
         if (tokenMap.containsKey("email")) jsResult.put("email", (String)tokenMap.get("email"));
      }
      else {
         jsResult.put("message", "Authenticated using a global token - please switch to user authentication.");
      }

      return Response.ok(jsResult).build();
   }

   @Path("/logout")
   @GET
   public Response postUserLogout() {
      return Response.ok().build();
   }

   @Override
   public void parseInterface(ServerConfig pConfig, InterfaceType pInterface, Webservice pServiceXML) {
      List<OptionType> options = pInterface.getOption();
      for (OptionType option : options) {
         String opName = option.getName();
         String opValue = option.getValue();
         if (option.getName() != null) {
            switch (opName.toLowerCase()) {
               case "method":
                  if (opValue != null) {
                     switch (opValue.toLowerCase()) {
                        case "none":   method = "none"; break;
                        case "digest": method = "digest"; break;
                        default: throw new RuntimeException("No support for authorisation method '" + opValue + "'");
                     }
                  }
                  break;
            }
         }
         else throw new RuntimeException("Invalid option passed to User class in data schema - missing 'name' attribute.");
      }

      if ("digest".equals(method)) {
         enabled.set(true);
      }
   }

   @Override
   public void refreshInterface(InterfaceType pInterface, Webservice pServiceXML) {
      LOG.info("If refreshing the user authorisation interface is required, please restart the web service.");
   }
}
