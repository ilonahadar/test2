package com.elsevier.epic;

import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.postgres.PostgresClient;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response.Status;
import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

public class Recommender implements DataFeed {
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

   static final private SimpleDateFormat sdfLong = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

   static {
      sdfLong.setTimeZone(TimeZone.getTimeZone("UTC"));
   }

   static class QueryResult {
       final Integer year;
       final Integer month;
       final Integer total;

       public QueryResult(Integer pYear, Integer pMonth, int pTotal) {
           this.year = pYear;
           this.month = pMonth;
           this.total = pTotal;
       }
   }

   static interface Query {
      static class ResultMap implements ResultSetMapper<QueryResult> {
          @Override
          public QueryResult map(int row, ResultSet rst, StatementContext ctxStatement) throws SQLException {
              return new QueryResult(rst.getInt("year"), rst.getInt("month"), rst.getInt("total"));
          }
      }

       @Mapper(ResultMap.class)
       @SqlQuery("SELECT r.year, r.month, r.total FROM vw_recommender r WHERE r.sis=:accountId\n" +
                  "ORDER BY r.year DESC, r.month DESC LIMIT :limit;")
       List<QueryResult> getResults(@Bind("accountId") int accountId, @Bind("limit") int limit);
   }

   @Override
   public Response query(HttpServletRequest pRequest, 
           ArrayList<IDValue> pIDs, 
           Map<String, String> pParameters) {
      int accountId = Integer.parseInt(pIDs.get(0).value);
      String periodVal = pParameters.get("period");
      int period = Integer.parseInt(periodVal);

      Query query = PostgresClient.getDBI().onDemand(Query.class);
      List<QueryResult> results = query.getResults(accountId, period+ 1 ); // "+1 because current month is removed

      // Get the final year and month for which we have data.  We'll use this information to
      // remove partial data from our results.

      String lastUpdate = LastUpdate.getUpdates().path("recommender").asText();
      int endYear, endMonth;

      try {
         Calendar cal = Calendar.getInstance();
         cal.setTime(sdfLong.parse(lastUpdate));
         endYear = cal.get(Calendar.YEAR);
         endMonth = cal.get(Calendar.MONTH) + 1;
      }
      catch (ParseException ex) {
         throw new WebApplicationException("Failed to process the recommender data timestamp.", Status.INTERNAL_SERVER_ERROR);
      }

      ObjectNode jsRoot = jsFactory.objectNode();
      jsRoot.put("totalRecords", results.size()-1); // because we remove currently processing month
      jsRoot.put("lastDate", LastUpdate.getUpdates().path("recommender").asText());
      ArrayNode jsResults = jsRoot.putArray("results");
      for (QueryResult entry : results) {
         // Ignore partial months of data
         // problem when the time stamp is wrong! 
         if ((entry.year == endYear) && (entry.month == endMonth)) continue;

         ObjectNode jsObject = jsResults.addObject();
         jsObject.put("year", entry.year);
         jsObject.put("month", entry.month);
         jsObject.put("downloads", entry.total);
      }

      return Response.ok(jsRoot).build();
   }
}
