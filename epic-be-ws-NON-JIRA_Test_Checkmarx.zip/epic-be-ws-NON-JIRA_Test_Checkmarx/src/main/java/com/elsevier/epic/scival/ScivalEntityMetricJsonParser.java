package com.elsevier.epic.scival;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;

public class ScivalEntityMetricJsonParser {
    private JsonObject jsonRootObject;
    private int coAuthoredPublications;
    private float coAuthPubGrowth;
    private float weightedImpact;
    private final String entityURI;

    public ScivalEntityMetricJsonParser(JsonElement jsonElement) {
        jsonRootObject = jsonElement.getAsJsonObject();
        try {
            entityURI = jsonRootObject.get("entityURI").getAsString();
            coAuthoredPublications = jsonRootObject.get("coAuthoredPublications").getAsInt();
            coAuthPubGrowth = jsonRootObject.get("coAuthPubGrowth").getAsFloat();
            weightedImpact = jsonRootObject.get("weightedImpact").getAsFloat();
        } catch (NullPointerException e) {
            throw new JsonSyntaxException("One or more required fields missing from JSON");
        }
    }

    public int getInstitutionId() {
        return new ScivalEntityURI(entityURI).getInstitutionId();
    }

    public int getCoAuthoredPublications() {
        return coAuthoredPublications;
    }

    public float getCoAuthoredGrowthPercent() {
        return coAuthPubGrowth;
    }

    public float getCoAuthoredFWCI() {
        return weightedImpact;
    }

}
