/**
 * This plugin converts country codes in the results to the user's preferred standard.  This requires to use the
 * countryCode query parameter with one of the following values:
 *
 * 1 - Integer
 * 2 - Two letters (AA)
 * 3 - Three letters (AAA)
 * 4 - Name
 *
 * E.g. ?countryCode=2
 */

package com.elsevier.epic.core;

import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.types.PostProcess;
import com.elsevier.epic.jaxb.OptionType;
import com.elsevier.epic.jaxb.PostprocessType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.elsevier.epic.utility.CCLookup;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;

public class CountryCode implements PostProcess {
   private static final Logger LOG = Log.getLogger(CountryCode.class);
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

   static private int readInt(String str) {
      if ((str == null) || (str.isEmpty())) return 0;
      try {
         return Integer.parseInt(str);
      }
      catch (Exception e) {
         return 0;
      }
   }

   /**
    *
    * @param postProcess JAXB response element from data schema
    * @param pResponse
    * @param pPathParams Path parameters from HTTP request
    * @param pQueryParams Query parameters from HTTP request
    */

   @Override
   public void postProcess(PostprocessType postProcess, Response pResponse, ArrayList<IDValue> pPathParams, Map<String, String> pQueryParams) {
      Object entity = pResponse.getEntity();
      if (!(entity instanceof ObjectNode)) return;

      Convertor state = new Convertor();

      // Parameter handling

      String paramCC = pQueryParams.get("countrycode");
      if (paramCC == null) return; // Do nothing if the user didn't request a country code modification
      state.requestedType = readInt(paramCC);
      if ((state.requestedType < 1) || (state.requestedType > 4)) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
            .setMessage("The countryCode parameter must be between 1 and 4.")
            .build());
      }

      // Process conversion options that are applicable to this resource.

      for (OptionType option : postProcess.getOption()) {
         switch(option.getName().toLowerCase()) {
            case "target":
               state.setTarget(option.getValue()); break;
            case "convert":
               String v = option.getValue();
               if ((v != null) && (v.equals("keys"))) state.setKeys = true;
               break;
            case "srctype":
               state.srcType = Integer.parseInt(option.getValue()); break;
            default:
               throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
                  .setMessage("Server error.  CountryCode conversion is incorrectly defined for this resource - unrecognised option.")
                  .build());
         }
      }

      if (state.srcType == state.requestedType) return; // Do nothing if the source type and requested type are the same.

      String msg;
      if ((msg = state.validState()) != null) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
            .setMessage("Server error.  CountryCode conversion is incorrectly defined for this resource: " + msg)
            .build());
      }

      JsonNode jsTarget = (ObjectNode)entity;
      processTarget(null, jsTarget, state.targetFields, state);
   }

   private void processTarget(JsonNode pParent, JsonNode pTarget, String[] pFields, Convertor pState) {
      for (int f=0; f < pFields.length; f++) {
         pParent = pTarget;
         pTarget = pTarget.get(pFields[f]);
         if (pTarget == null) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
               .setMessage("Server error.  CountryCode conversion is incorrectly defined for this resource - target '" + pFields[f] + "' is invalid.")
               .build());
         }

         if (pTarget.isArray()) {
            if (f == pFields.length-1) { // Convert each array entry, case-by-case basis.
               ArrayNode array = (ArrayNode)pTarget;
               for (int a=0; a < array.size(); a++) {
                  JsonNode entry = array.get(a);
                  pState.convertTarget(pParent, entry, pFields[pFields.length-1]);
               }
               return;
            }
            else {

            }

            ArrayNode array = (ArrayNode)pTarget;
            for (int a=0; a < array.size(); a++) {
               JsonNode entry = array.get(a);
               if (entry.isObject()) {
                  processTarget(pParent, entry, Arrays.copyOfRange(pFields, f+1, pFields.length), pState);
               }
            }
            return;
         }
      }

      pState.convertTarget(pParent, pTarget, pFields[pFields.length-1]);
   }

   @Override
   public ResponseBuilder noResults(ArrayList<IDValue> pPathParams, Map<String, String> pQueryParams) {
      return null;
   }

   static private class Convertor {
      boolean setKeys = false;
      int srcType = -1;
      int requestedType = -1;
      String[] targetFields = null;

      Convertor() {
      }

      public String validState() {
         if (targetFields == null) return "Target field not defined.";
         if ((srcType < 1) || (srcType > 4)) return "Invalid source type of " + srcType;
         if ((requestedType < 1) || (requestedType > 4)) return "Invalid request type of " + requestedType;
         return null;
      }

      public void setTarget(String pTarget) {
         this.targetFields = pTarget.split("\\.");
      }

      /**
       * Convert a value from one country code type to another.  If a failure occurs, the returned value is
       * not converted.
       *
       * @param pValue
       * @return
       */

      public String convert(String pValue) {
         if (this.srcType == this.requestedType) return pValue;

         Country ctry;
         if (this.srcType == 1) ctry = CCLookup.codeToCountry(readInt(pValue));
         else ctry = CCLookup.validCode(pValue);

         if (ctry != null) {
            switch (this.requestedType) {
               case 1: return Integer.toString(ctry.code);
               case 2: return ctry.two;
               case 3: return ctry.three;
               case 4: return ctry.name;
            }
         }

         LOG.info("Unrecognised country code '" + pValue + "'");
         return pValue;
      }

      public void convertTarget(JsonNode pParent, JsonNode pTarget, String pTagName) {
         if (this.setKeys) { // The keys in jsTarget are country codes, e.g. "660":"<- ISO Code"
            if (pTarget.isObject()) {
               ObjectNode jsNew = jsFactory.objectNode();

               Iterator<Map.Entry<String, JsonNode>> fields = pTarget.fields();
               while (fields.hasNext()) {
                  Map.Entry<String, JsonNode> field = fields.next();
                  jsNew.put(this.convert(field.getKey()), field.getValue());
               }

               ((ObjectNode)pTarget).removeAll();
               ((ObjectNode)pTarget).setAll(jsNew);
            }
         }
         else ((ObjectNode)pParent).put(pTagName, this.convert(pTarget.asText()));
      }
   }
}
