package com.elsevier.epic.types;

public class JournalCategory {
   public Integer code;
   public String name;
}
