
package com.elsevier.epic.auth;

import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.core.ServerConfig;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response.Status;
import java.util.List;

/**
 *
 * GlobalToken Example
 * -------------------
 * Authorization: GlobalToken sdjlffj93fi32fjk9f320k92
 */

public class AuthToken implements AuthClient {
   private static final Logger LOG = Log.getLogger(AuthToken.class);
   private static List<String> globalToken = null;

   @Override
   public void init(ServerConfig pConfig) {
      globalToken = pConfig.getGlobalToken();
   }

   @Override
   public int authenticate(HttpServletResponse hr, HttpServletRequest httpRequest, String authHeader) {

      // Did the client provide the correct auth token?

      if (globalToken != null) {
         if ((authHeader != null) && (authHeader.startsWith("GlobalToken"))) {
            String token = authHeader.substring(11).trim();
            if (globalToken.contains(token)) {
               return AuthFilter.AUTH_ACCEPTED;
            }
            else LOG.info("Invalid global token from client: " + token);
         }
         else if (globalToken.contains(authHeader)) { // WARNING: Old method allowed token in the header without any prefix, this is obsolete and must be removed.
            return AuthFilter.AUTH_ACCEPTED;
         }
      }
      else if ((authHeader != null) && (authHeader.startsWith("GlobalToken"))) {
         LOG.info("Invalid attempt to use GlobalToken (security feature disabled).");
         throw new WebApplicationException(ErrorResponse.status(Status.UNAUTHORIZED)
            .setMessage("Global tokens are disabled for this web service.")
            .build());
      }

      return AuthFilter.AUTH_CONTINUE;
   }
}
