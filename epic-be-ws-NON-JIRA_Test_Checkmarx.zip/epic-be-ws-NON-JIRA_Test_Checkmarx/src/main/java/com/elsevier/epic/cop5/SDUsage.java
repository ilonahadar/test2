package com.elsevier.epic.cop5;

import java.sql.Array;
import java.sql.SQLException;
import java.util.Arrays;

public class SDUsage implements Comparable<SDUsage>{

    int account_id;

    @Override
    public String toString() {
        return "SDUsage{" +
                "account_id=" + account_id +
                ", report_platform_description='" + report_platform_description + '\'' +
                ", year=" + year +
                ", Total=" + Arrays.toString(Total) +
                '}';
    }

    String report_platform_description;
    Integer year;
    Long[] Total;


    public SDUsage(int account_id, String report_platform_description,  int year,Array Total)throws SQLException {
        this.account_id = account_id;
        this.report_platform_description = report_platform_description;
        this.year = Integer.valueOf(year);
        this.Total = (Long[])Total.getArray();
    }

    public SDUsage(int account_id, String report_platform_description,  int year,Long[] Total)throws SQLException {
        this.account_id = account_id;
        this.report_platform_description = report_platform_description;
        this.year = Integer.valueOf(year);
        this.Total = Total;
    }

    public Integer getYear() {
        return year;
    }
    public int compareTo(SDUsage sd){
        if(year.intValue()==sd.year.intValue())
            return 0;
        else if(year.intValue()>sd.year.intValue())
            return 1;
        else
            return -1;
    }
}
