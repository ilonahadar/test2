package com.elsevier.epic;

import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.Define;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.sqlobject.stringtemplate.UseStringTemplate3StatementLocator;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TopJournalsC5 implements DataFeed {
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

   static class QueryResult {
      final int year;
      final int month;
      final String issn;
      final String title;
      final int total;

      public QueryResult(int pYear, int pMonth, String pISSN, String pTitle, int pTotal) {
         year  = pYear;
         month = pMonth;
         issn  = pISSN;
         title = pTitle;
         total = pTotal;
      }
   }

   @UseStringTemplate3StatementLocator()
   static interface Query {
      static class ResultMap implements ResultSetMapper<QueryResult> {
          @Override
          public QueryResult map(int row, ResultSet rst, StatementContext ctxStatement) throws SQLException {
              return new QueryResult(rst.getInt(1), rst.getInt(2), rst.getString(3), rst.getString(4), rst.getInt(5));
          }
      }

      @Mapper(ResultMap.class)
      @SqlQuery("SELECT year, month, v.issn, j.title, <period> AS total\n" +
                "FROM vw_journal_monthly_usage_rolling_c5 v, journal j\n" +
                "WHERE sis=:accountId\n" +
                 "AND j.issn = v.issn\n" +
                "ORDER BY <period> DESC LIMIT :limit;")
      List<QueryResult> runQuery(@Define("period") String period, @Bind("accountId") int accountId, @Bind("limit") int limit);
   }

   // Entry point for querying top journals

   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      int accountId = Integer.parseInt(pIDs.get(0).value);
      int count = Integer.parseInt(pIDs.get(1).value);
      int period = Integer.parseInt(pParameters.get("period"));

      if (period == 0) period = 12;

      String periodField = "m12";
      
      switch (period) {
         case 6: periodField = "m6"; break;
         case 12: periodField = "m12"; break;
         case 24: periodField = "m24"; break;
         case 36: periodField = "m36"; break;
         default:
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
               .setMessage("Acceptable period values are 6, 12, 24 or 36 (client requested " + period + ")")
               .build());
      }

      List<QueryResult> results = PostgresClient.getDBI().onDemand(Query.class).runQuery(periodField, accountId, count);

      ObjectNode jsRoot = jsFactory.objectNode();
      jsRoot.put("totalRecords", results.size());
      jsRoot.put("year", results.get(0).year);
      jsRoot.put("month", results.get(0).month);
      jsRoot.put("period", period);
      jsRoot.put("interval", "monthly");
      ArrayNode jsResults = jsRoot.putArray("results");
      for (QueryResult entry : results) {
         ObjectNode jsObject = jsResults.addObject();
         jsObject.put("issn", entry.issn);
         jsObject.put("title", entry.title);
         jsObject.put("total", entry.total);
      }

      return Response.ok(jsRoot).build();
   }
}
