/**
 *
 * TODO
 * ----
 * + Support 'algorithm' in the digest header.
 * + The nonce that we send to the user should be stored and checked when the user makes their next login attempt.
 *   Otherwise a single nonce can be repeatedly used by an attacker.
 * + apikey must be present and we will use this to check if the app is authorised.  NB: Administrator accounts
 *   are not subject to this restriction, because we want them to be able to make calls from the web browser.
 * + Logging in always hits the database - can we cache user information for a period of time (120 seconds) so that
 *   we don't have to request it so often?
 *
 * BearerToken Example
 * --------------------
 * Session tokens (bearer tokens) can be retrieved from /user/login and speed up the authorisation process.
 *
 * Authorization: Bearer sdjlffj93fi32fjk9f320k92...
 *
 *
 * Digest Example
 * --------------
 * Digest username="paul", realm="RELX Group", nonce="123456789", uri="/v1/user/login",
 * response="bfba7b2ced4b6179f2dcd712cbbf8043", opaque="123456789", qop=auth, nc=00000001, cnonce="8e48604ac51fb549"
 * OPTIONAL apikey="" algorithm="MD5|MD5-sess"
 */

package com.elsevier.epic.auth;

import com.auth0.jwt.JWTSigner;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.JWTVerifyException;
import com.auth0.jwt.internal.com.fasterxml.jackson.core.JsonParseException;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.core.ServerConfig;
import com.elsevier.epic.core.ServiceBuilder;
import com.elsevier.epic.postgres.PostgresClient;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.commons.codec.digest.DigestUtils;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response.Status;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

public class AuthDigest implements AuthClient {
   private static final Logger LOG = Log.getLogger(AuthDigest.class);

   static final public String jwtSecret = "3jkf983jXssAF3fsj398fAJLs3";
   static final private AtomicReference<PreparedStatement> psLogin = new AtomicReference<>();
   static final private JWTSigner signer = new JWTSigner(jwtSecret);
   private static final Random rnd = new Random();

   // Nonce handling

   static final private Map<String, Nonce> nonceCounter = new ConcurrentHashMap<>();

   static private class Nonce {
      String value;
      String opaque;
      int counter;
      long expires;

      private Nonce() {
         this.expires = System.currentTimeMillis() + (30 * 60 * 1000); // 30 minute expiry from creation.
         this.counter = 10; // Countdown - when this reaches zero, the nonce is no longer usable.
         this.value = String.format("%x", System.currentTimeMillis() * 31 * rnd.nextInt());
         this.opaque = String.format("%x", System.currentTimeMillis() * 17 * rnd.nextInt());
      }

      static private Nonce createNonce() {
         Nonce n = new Nonce();
         nonceCounter.put(n.value, n);
         return n;
      }
   }

   @Override
   public void init(ServerConfig pConfig) {
   }

   @Override
   public int authenticate(HttpServletResponse hr, HttpServletRequest httpRequest, String authHeader) {
      try {

         // If "X-Requested-With: XMLHttpRequest" appears in the request header, we'll add an 'X-' to the WWW
         // Authenticate header.  This prevents the client browser from automatically interfering with the
         // authentication process, which is useful to Javascript developers.

         String xWith = httpRequest.getHeader("X-Requested-With");
         String prefixAuth = "";
         if ("XMLHttpRequest".equals(xWith)) prefixAuth = "X-";

         // Support for JSON web tokens.

         if ((authHeader != null) && (authHeader.startsWith("Bearer"))) {
            String token = authHeader.substring(6).trim();

            try {
               Map<String, Object> tokenMap = new JWTVerifier(jwtSecret).verify(token);
               httpRequest.setAttribute("token", token);
               httpRequest.setAttribute("tokenMap", tokenMap);
               return AuthFilter.AUTH_ACCEPTED;
            }
            catch (JsonParseException | NoSuchAlgorithmException | InvalidKeyException | IllegalStateException | SignatureException | JWTVerifyException ex) {
               LOG.info("Invalid bearer token from client: " + token);
               hr.setHeader(prefixAuth + HttpHeaders.WWW_AUTHENTICATE, buildAuthentication());
               hr.setContentType("text/plain");
               hr.getWriter().print(ex.getMessage());
               hr.sendError(401);
               return AuthFilter.AUTH_RESPONDED;
            }
         }

         // Support for Digest

         try {
            if ((authHeader != null) && (authHeader.startsWith("Digest"))) {
               LOG.debug("Auth: " + authHeader);

               Map<String, String> authKeys = AuthParser.parseDigest(authHeader);

               UserCredentials credentials = new UserCredentials(ServiceBuilder.getServiceXML().getName(), authKeys, httpRequest);
               if (authDigest(credentials, hr, httpRequest)) { // The user login is valid.
                  return AuthFilter.AUTH_ACCEPTED;
               }
               else throw new AuthException("The provided HTTP Digest credentials were not accepted.");
            }
            else throw new AuthException("HTTP Digest credentials are required to access this resource.");
         }
         catch (AuthException ex) {
            // We use HttpServletReponse to send back the response because we need to provide a custom
            // header to the client's browser for auth-digest to work.
            hr.setHeader(prefixAuth + HttpHeaders.WWW_AUTHENTICATE, buildAuthentication());
            hr.setContentType("text/plain");
            hr.getWriter().print(ex.getMessage());
            hr.sendError(401);
            return AuthFilter.AUTH_RESPONDED;
         }
      }
      catch (IOException ex) {
         throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
            .setMessage("Server I/O failure, unable to proceed with client authentication.")
            .setException(ex)
            .build());
      }
   }

   /**
    *
    * @return
    */

   static private String buildAuthentication()
   {
      StringBuilder sb = new StringBuilder();
      final String realm = ServiceBuilder.getServiceXML().getName();
      AuthDigest.Nonce n = AuthDigest.Nonce.createNonce();
      sb.append("Digest realm=\"").append(realm).append("\", qop=\"auth\", nonce=\"").append(n.value).append("\", ")
        .append("opaque=\"").append(n.opaque).append("\"");
      return sb.toString();
   }

   static private boolean authDigest(UserCredentials user, HttpServletResponse pResponse, HttpServletRequest pRequest) throws AuthException {
      user.uid = user.authKeys.get("username");
      if ((user.uid == null) || (user.uid.isEmpty())) throw new AuthException("Missing username from digest header.");

      String reqURI = user.authKeys.get("uri");
      if ((reqURI == null) || ( reqURI.isEmpty())) throw new AuthException("Missing uri from digest header.");

      String receivedNonce = user.authKeys.get("nonce");
      if ((receivedNonce == null) || ( receivedNonce.isEmpty())) throw new AuthException("Missing nonce from digest header.");

      StringBuilder sb = new StringBuilder();
      sb.append("SELECT l.sis, l.access_level, l.user_token, l.first_name, l.surname, l.uid\n");
      sb.append("FROM login l\n");
      sb.append("WHERE lower(uid)=lower(?)\n");
      sb.append("GROUP BY l.sis, l.access_level, l.user_token, l.first_name, l.surname, l.uid\n");

      try (Connection con = PostgresClient.getConnection();
           PreparedStatement ps = con.prepareStatement(sb.toString())) {

         ps.setString(1, user.uid);

         //if (!Server.isProduction()) LOG.info(ps.toString());

         try (ResultSet rst = ps.executeQuery()) {
            if (rst.next()) {
               final String username = rst.getString("uid");
               final String userToken = rst.getString("user_token");
               final Array sisArray = rst.getArray("sis");
               user.firstName = rst.getString("first_name");
               user.surname = rst.getString("surname");

               if (sisArray != null) {
                  user.sis = new ArrayList<>(Arrays.asList((Integer[])sisArray.getArray()));
               }

               user.accessLevel = rst.getInt("access_level");

               // TODO: Has the user approved this application?

               if (user.accessLevel != UserCredentials.AL_ADMIN) {
               }

               // TODO: Support 'algorithm' instruction

               final String encryptionKeys = System.getenv("ENCRYPTION_KEY");
               final JsonObject jsonObject = new JsonParser().parse(encryptionKeys).getAsJsonObject();
               final String key = jsonObject.get("key").getAsString();
               final String initVector = jsonObject.get("initVector").getAsString();
               final String password;

               try {
                  password = EncryptionUtils.decrypt(key, initVector, userToken);
               } catch (Exception ex) {
                  throw new WebApplicationException("Internal error during authentication");
               }

               final String realm = user.authKeys.get("realm");

               String sigEncode;
               final String ha1 = DigestUtils.md5Hex(username + ":" + realm + ":" + password);
               final String qop = user.authKeys.get("qop"); // Optional

               if ("auth-int".equals(qop)) sigEncode = user.method + ":" + reqURI + ":" + user.bodyMD5;
               else sigEncode = user.method + ":" + reqURI;

               String ha2 = DigestUtils.md5Hex(sigEncode);

               if ((qop == null) || (qop.isEmpty())) {
                  sigEncode = DigestUtils.md5Hex(ha1 + ":" + receivedNonce + ":" + ha2);
               }
               else {
                  if ((realm == null) || (realm.isEmpty())) throw new AuthException("Missing 'realm' from digest header.");

                  String nonceCount = user.authKeys.get("nc");
                  if ((nonceCount == null) || (nonceCount.isEmpty())) throw new AuthException("Missing 'nc' from digest header.");

                  String clientNonce = user.authKeys.get("cnonce");
                  if ((clientNonce == null) || (clientNonce.isEmpty())) throw new AuthException("Missing 'cnonce' from digest header.");

                  sigEncode = ha1 + ":" + receivedNonce + ":" + nonceCount + ":" + clientNonce + ":" + qop + ":" + ha2;
               }

               user.serverSignature = DigestUtils.md5Hex(sigEncode);

               String clientSignature = user.authKeys.get("response");

               // JWT generation.  Gets stored in X-Token and can be retrieved by interfaces from there.

               HashMap<String, Object> claims = new HashMap<>();
               claims.put("uid", (String)user.uid);
               claims.put("al", (Integer)user.accessLevel);
               if (user.firstName != null) claims.put("firstName", user.firstName);
               if (user.surname != null) claims.put("surname", user.surname);
               if ((user.sis != null) && (user.sis.size() > 0)) claims.put("sis", user.sis);

               String token = signer.sign(claims);
               pResponse.addHeader("X-Token", token);
               pRequest.setAttribute("token", token);
               pRequest.setAttribute("tokenMap", claims);

               return user.serverSignature.equals(clientSignature);
            }
            else {
               try { Thread.sleep(250); } catch (InterruptedException ex) { } // Sleep to avoid hammering of bad login attempts
               throw new AuthException("Unable to resolve user ID '" + user.uid + "'");
            }
         }
      }
      catch (SQLException ex) {
         try { Thread.sleep(250); } catch (InterruptedException e) { } // Sleep to avoid hammering of bad login attempts
         LOG.warn(ex.getMessage(), ex);
         if ((ex = ex.getNextException()) != null) LOG.warn("Detail: ", ex);
         throw new AuthException("Server database failure, unable to login.");
      }
   }
}
