///*
//This is the support code for /source/{sourceID}/usage/?/...
//
//Please note that the data is all-inclusive and NOT filtered by institution.
//*/
//
///* Front end does not use. If needed, the creation of this table will have to
//     shift from hive tables as it was needed because counter derived data
//     was a subset (devote) of data so harvesting this had to come out of keyfe.
//     Commenting out for the moment for posterity
//*/
//
//package com.elsevier.epic;
//
//import com.elsevier.epic.postgres.DataFeed;
//import com.elsevier.epic.types.IDValue;
//import com.elsevier.epic.core.ErrorResponse;
//import com.elsevier.epic.core.CoreServer;
//import com.elsevier.epic.postgres.PostgresClient;
//import com.fasterxml.jackson.databind.node.ArrayNode;
//import com.fasterxml.jackson.databind.node.JsonNodeFactory;
//import com.fasterxml.jackson.databind.node.ObjectNode;
//import com.elsevier.epic.utility.Utility;
//import java.sql.*;
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.Map;
//import javax.servlet.http.HttpServletRequest;
//import javax.ws.rs.WebApplicationException;
//import javax.ws.rs.core.Response;
//import javax.ws.rs.core.Response.Status;
//import org.eclipse.jetty.util.log.Log;
//import org.eclipse.jetty.util.log.Logger;
//
//public class SourceAllUsage implements DataFeed {
//   private static final Logger LOG = Log.getLogger(SourceAllUsage.class);
//   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe
//
//   static final int MIN_YEAR = 2010;
//
//   @Override
//   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
//      if (pIDs.size() < 1) throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);
//
//      String paramISSN = pIDs.get(0).value;
//      String paramUsage;
//      if (pIDs.size() >= 2) paramUsage = pIDs.get(1).value;
//      else paramUsage = "all";
//
//      String paramYearStart  = pParameters.get("yearstart");
//      String paramYearEnd    = pParameters.get("yearend");
//
//      ObjectNode jsRoot = jsFactory.objectNode();
//
//      int ys = Utility.readInt(paramYearStart);
//      final int yearEnd;
//      int y = Utility.readInt(paramYearEnd);
//
//      Calendar cal = Calendar.getInstance();
//      int currentYear = cal.get(Calendar.YEAR);
//      yearEnd = (y <= 0) ? currentYear : y;
//
//      if (ys > currentYear) {
//         return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid year parameter " + ys).build();
//      }
//
//      if ((ys < 0) || (ys > yearEnd)) {
//         return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid year parameters " + ys + " to " + yearEnd).build();
//      }
//
//      final int yearStart = (ys < MIN_YEAR) ? MIN_YEAR : ys;
//
//      try (Connection con = PostgresClient.getConnection()) {
//         // This query returns the total downloads for ALL articles within a particular journal for ALL accounts.
//         // No filtering on institution is applied.
//
//         final int COL_YEAR = 1;
//         final int COL_MONTHS = 2;
//         final int COL_YEAR_TOTAL = 3;
//
//         StringBuilder sb = new StringBuilder();
//         sb.append("SELECT year, months, total FROM journal_annual_usage AS src\n")
//           .append("WHERE (issn=?) AND year BETWEEN ? AND ?\n")
//           .append("ORDER BY year ASC;\n");
//
//         try (PreparedStatement psUsage = con.prepareStatement(sb.toString())) {
//            psUsage.setQueryTimeout(5);
//            psUsage.setString(1, paramISSN);
//            psUsage.setInt(2, yearStart);
//            psUsage.setInt(3, yearEnd);
//
//            if (!CoreServer.isProduction()) LOG.info(psUsage.toString());
//
//            ObjectNode jsUsage = jsFactory.objectNode();
//            ArrayNode jsDownloads = jsFactory.arrayNode();
//
//            try (ResultSet rst = psUsage.executeQuery()) {
//               while (rst.next()) {
//                  ObjectNode jsEntry = jsFactory.objectNode();
//                  jsEntry.put("year", rst.getInt(COL_YEAR));
//                  jsEntry.put("total", rst.getInt(COL_YEAR_TOTAL));
//
//                  ArrayNode jsMonths = jsFactory.arrayNode();
//                  Integer[] aMonths = (Integer[])rst.getArray(COL_MONTHS).getArray();
//                  for (int v : aMonths) jsMonths.add(v);
//                  jsEntry.set("months", jsMonths);
//
//                  jsDownloads.add(jsEntry);
//               }
//            }
//
//            try (PreparedStatement psSource = con.prepareStatement(
//                "SELECT title, content_type, type_name, publisher, imprint, counter_usage\n" +
//                "FROM journal\n" +
//                "WHERE issn=?\n" +
//                "LIMIT 1")) {
//               psSource.setString(1, paramISSN);
//
//               try (ResultSet rst = psSource.executeQuery()) {
//                  if (rst.next()) {
//                     jsRoot.put("issn", paramISSN);
//                     jsRoot.put("title", rst.getString(1));
//                     jsRoot.put("contentType", rst.getString(2));
//                     jsRoot.put("typeName", rst.getString(3));
//                     jsRoot.put("publisher", rst.getString(4));
//                     jsRoot.put("imprint", rst.getString(5));
//                     jsRoot.put("active", rst.getInt(6) > 0);
//                  }
//               }
//
//               jsUsage.set("downloads", jsDownloads);
//               jsRoot.set("usage", jsUsage);
//            }
//         }
//      }
//      catch (SQLException ex) {
//         LOG.warn(ex);
//         throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
//            .setMessage("A server database failure has occurred.")
//            .setException(ex)
//            .build());
//      }
//
//      return Response.ok(jsRoot).build();
//   }
//}
