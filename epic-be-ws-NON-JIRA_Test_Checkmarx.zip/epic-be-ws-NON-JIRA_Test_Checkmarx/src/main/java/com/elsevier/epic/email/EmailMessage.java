package com.elsevier.epic.email;

import com.elsevier.epic.core.CoreServer;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Date;

public class EmailMessage {
   public String subject;
   public String content;
   public String contentType;
   public String recipient;
   public String sender;

   public EmailMessage(String pRecipient, String pSender, String pSubject, String pContent, String pContentType) {
      this.recipient   = pRecipient;
      this.sender      = pSender;
      this.subject     = pSubject;
      this.content     = pContent;
      this.contentType = pContentType;
   }

   public EmailMessage() {
      if (CoreServer.config != null) {
         this.sender = CoreServer.config.getMailSender();
         this.subject = "Automated message from web service.";
         this.recipient = CoreServer.config.getMailAdmin();
      }
   }

   protected MimeMessage getMimeMessage(javax.mail.Session pSession) throws MessagingException {
      MimeMessage msg = new MimeMessage(pSession);
      msg.setFrom(new InternetAddress(this.sender));
      msg.setRecipients(javax.mail.Message.RecipientType.TO, this.recipient);
      msg.setSubject(this.subject);
      msg.setSentDate(new Date());
      msg.setText(this.content, this.contentType);
      return msg;
   }
}
