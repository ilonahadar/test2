package com.elsevier.epic.validation;

import com.elsevier.epic.core.ErrorResponse;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static java.util.Arrays.asList;
import static java.util.Objects.nonNull;

public class SQLValidator {

    final List<String> blackListedKeywords = asList("create", "drop", "update", "insert", "alter", "delete", "attach", "detach","select");

    public void validate(final String... sqlKeywords) {
        Arrays.stream(sqlKeywords).forEach(word -> {
            if (nonNull(word)) {
                final String lowerCaseSql = word.toLowerCase();
                if (blackListedKeywords.stream().anyMatch(lowerCaseSql::contains)) {
                    throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
                                                                   .setMessage(String.format("keyword(s) %s no allowed", lowerCaseSql))
                                                                   .build());
                }
            }
        });
    }

    public Map<String, String[]> validate(final Map<String, String[]> inputs) {
        if (nonNull(inputs)) {
            inputs.forEach((k, v) -> {
                validate(k);
                validate(v);
            });
        }
        return inputs;
    }

}
