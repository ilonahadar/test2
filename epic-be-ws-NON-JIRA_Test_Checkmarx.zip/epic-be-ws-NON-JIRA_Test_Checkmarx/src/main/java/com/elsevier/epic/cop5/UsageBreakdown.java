

package com.elsevier.epic.cop5;

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.utility.Utility;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.sql.*;
import java.util.*;
import java.util.stream.*;

public class UsageBreakdown implements DataFeed {
    private static final Logger LOG = Log.getLogger(UsageBreakdown.class);
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe
    private static final List<String> metricsList = Arrays.asList("unique_title_requests","unique_item_requests","total_item_investigations","total_item_requests");
    private static final List<String> contentlist = Arrays.asList("E-books","Series","Reference Works", "Handbooks","Journal");
    List<SDUsage> TableList=new ArrayList<>();

    PreparedStatement getStatement(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement("select * from getUsageBreakdown(?,?,?,?,?,?,?,?,?,?)");
        ps.setQueryTimeout(60);
        return ps;
    }

    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
        if (pIDs.size() < 1) throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);

        String paramAccount = pIDs.get(0).value;
        int accountID;
        String paramYearStart;
        String paramYearEnd;
        String access_type;
        String content_type;
        String data_type;
        String returnPlatforms;
        String platform;
        String metric;
        String access_method;

        try { accountID = Integer.parseInt(paramAccount); }
        catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
                    .setMessage("Invalid ID '" + paramAccount + "'")
                    .setException(ex)
                    .build());
        }
        paramYearStart= pParameters.get("startyear");
        paramYearEnd= pParameters.get("endyear");
        platform= pParameters.get("platform");
        access_type= pParameters.get("access_type");
        access_method= pParameters.get("access_method");
        content_type= pParameters.get("content_type");
        data_type= pParameters.get("data_type");
        returnPlatforms=pParameters.get("returnplatforms");
        metric=pParameters.get("metric");

        if(metric == null) metric="total_item_requests";


        if (returnPlatforms!=null && !returnPlatforms.toUpperCase().equals("TRUE") && !returnPlatforms.toUpperCase().equals("FALSE")) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("return_platform can either be True or False" + returnPlatforms).build();
        }

        if (data_type!=null && !data_type.toUpperCase().equals("BOOK") && !data_type.toUpperCase().equals("JOURNAL")) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("data_type can either be Book or Journal").build();
        }

        if (!metricsList.contains(metric.toLowerCase())) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("metric is supposed to carry one of the following values "+metricsList.toString()).build();
        }

        if (content_type!=null && !contentlist.stream().map(x->x.toLowerCase()).collect(Collectors.toList()).contains(content_type.toLowerCase())) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("content_type is supposed to carry one of the following values "+contentlist.toString()).build();
        }

        if (access_type!=null && !access_type.toUpperCase().equals("CONTROLLED") && !access_type.toUpperCase().equals("GOLD_OPEN_ACCESS")&&!access_type.toUpperCase().equals("OTHER_FREE_TO_READ")) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("access_type is supposed to be one of the following Controlled,Gold_Open_Access,Other_Free_To_Read").build();
        }

        if (access_method!=null && !access_method.toUpperCase().equals("TDM") && !access_method.toUpperCase().equals("REGULAR")) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("access_method can either be TDM or Regular").build();
        }

        if(access_type!=null) if(access_type.toUpperCase().equals("GOLD_OPEN_ACCESS")) access_type="OA_Gold";

        Calendar cal = Calendar.getInstance();
        ObjectNode jsRoot = jsFactory.objectNode();
        int fourYearsBefore =  cal.get(Calendar.YEAR)-4;
        if(paramYearStart==null  )
            paramYearStart=Integer.toString(fourYearsBefore);

        if(paramYearEnd==null) paramYearEnd=Integer.toString(cal.get(Calendar.YEAR));

        int ys = Utility.readInt(paramYearStart) < fourYearsBefore ? fourYearsBefore : Utility.readInt(paramYearStart);
        final int yearEnd;
        int ye = Utility.readInt(paramYearEnd);

        int currentYear = cal.get(Calendar.YEAR);
        yearEnd = (ye <= 0) ? currentYear : ye;

        if (ys > currentYear) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Start year "+ys+" cannot be greater than current year "+ currentYear).build();
        }

        if ((ys < 0) || (ys > yearEnd)) {
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("Invalid parameters. Default/Passed parameters startYear:"+paramYearStart+",endYear:"+paramYearEnd).build();
        }


        queryUsageBreakdownData(jsRoot,accountID,ys,yearEnd,access_type, content_type, data_type, returnPlatforms, platform, metric, access_method);

        if(jsRoot.size()==0)
            return ErrorResponse.status(Status.BAD_REQUEST).setMessage("No data found for the id passed").build();

        return Response.ok(jsRoot).build();
    }
    private static Map<Integer, List<SDUsage>> getDefaultYearMap(int accountID,String report_platform_description,int startYear,int endYear)
            throws SQLException {
        List<SDUsage> sdUsageList=new ArrayList<>();
        Long[] zeroList =  LongStream.range(0,12).map(x -> Long.valueOf("0")).boxed().toArray(Long[]::new);
        for (int i = startYear; i < endYear; i++) {
            sdUsageList.add(new SDUsage(accountID, report_platform_description, i, zeroList));
        }
        return sdUsageList.stream().collect(Collectors.groupingBy(x-> x.getYear(),Collectors.toList()));
    }
    private void queryUsageBreakdownData(ObjectNode jsRoot, int pSIS,int paramYearStart,int paramYearEnd,String access_type,String content_type,String data_type,String returnPlatforms,String platform,String metric,String access_method) {


        try (Connection con = PostgresClient.getConnection();
             PreparedStatement ps = getStatement(con)) {
            ps.setQueryTimeout(60);
            ps.setInt(1, pSIS);
            ps.setInt(2, paramYearStart);
            ps.setInt(3, paramYearEnd);
            ps.setString(4, metric);
            ps.setString(5, returnPlatforms);
            ps.setString(6, platform);
            ps.setString(7, access_type);
            ps.setString(8, access_method);
            ps.setString(9, content_type);
            ps.setString(10, data_type);



            if (!CoreServer.isProduction()) LOG.info(ps.toString());
            //ps.execute();

            try (ResultSet rst = ps.executeQuery()) {

                while (rst.next()) { SDUsage sd = new SDUsage(rst.getInt(1),rst.getString(3),rst.getInt(2),rst.getArray(4));
                    TableList.add(sd);
                }
                if(TableList.size()>0) {


                    ArrayNode TotalUsageArrayNode = jsFactory.arrayNode();
                    jsRoot.set("Total", TotalUsageArrayNode);


                    Collections.sort(TableList);
                    Map<Integer, List<SDUsage>>  yearMapFromDb= TableList.stream().filter(x -> x.report_platform_description.equals("NA")).collect(Collectors.groupingBy(x -> x.year));
                    Map<Integer, List<SDUsage>>  allYearMapCooked =  getDefaultYearMap(pSIS,"NA",paramYearStart,paramYearEnd);
                    Map<Integer, List<SDUsage>> sortedAllyearTreeMap = new TreeMap<>();
                    allYearMapCooked.putAll(yearMapFromDb);
                    sortedAllyearTreeMap.putAll(allYearMapCooked);
                    for (Map.Entry<Integer, List<SDUsage>> entry : sortedAllyearTreeMap.entrySet()) {
                        Integer key = entry.getKey();
                        List<SDUsage> value = entry.getValue();
                        ObjectNode oo = jsRoot.objectNode();
                        oo.put("Year", key);
                        for (SDUsage s : value) {
                            ArrayNode monthsArrayNode = jsRoot.arrayNode();
                            Arrays.stream(s.Total).forEach(monthsArrayNode::add);
                            oo.set("Months", monthsArrayNode);
                        }
                        TotalUsageArrayNode.add(oo);
                    }

                    if (returnPlatforms != null && returnPlatforms.toLowerCase().equals("true")) {

                        ObjectNode PlatformNode = jsRoot.objectNode();
                        jsRoot.set("Platform", PlatformNode);

                        Map<String, List<SDUsage>> platformMap = TableList.stream().filter(x -> !x.report_platform_description.equals("NA")).collect(Collectors.groupingBy(x -> x.report_platform_description));
                        for (Map.Entry<String, List<SDUsage>> entry : platformMap.entrySet()) {
                            String key = entry.getKey();
                            List<SDUsage> sdUsageList = entry.getValue();
                            List<SDUsage> sdUsageListForAllyears = new ArrayList<>();
                            Map<Integer, List<SDUsage>>  DefaultyearMapRPD =  getDefaultYearMap(pSIS,key,paramYearStart,paramYearEnd);
                            DefaultyearMapRPD.putAll(sdUsageList.stream().collect(Collectors.groupingBy(x-> x.getYear(),Collectors.toList())));
                            DefaultyearMapRPD.forEach((k,v) -> sdUsageListForAllyears.addAll(v));
                            Collections.sort(sdUsageListForAllyears);
                            ArrayNode PlatformArrayNode = jsRoot.arrayNode();
                            PlatformNode.set(key, PlatformArrayNode);

                            for (SDUsage s : sdUsageListForAllyears) {
                                System.out.println(s.report_platform_description);
                                ObjectNode oo = jsRoot.objectNode();
                                ArrayNode monthsArrayNode = jsRoot.arrayNode();
                                Arrays.stream(s.Total).forEach(monthsArrayNode::add);
                                oo.put("Year", s.year);
                                oo.set("Months", monthsArrayNode);
                                PlatformArrayNode.add(oo);

                            }

                        }
                    }
                }

            }


            catch (SQLException ex) {
                LOG.warn(ex);
                throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                        .setMessage("A server database failure has occurred.")
                        .setException(ex)
                        .build());
            }
        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }


    }



}

