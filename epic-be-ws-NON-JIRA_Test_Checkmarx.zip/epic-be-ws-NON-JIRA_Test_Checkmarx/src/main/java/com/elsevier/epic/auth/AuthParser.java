/**
 * This static module is for parsing Authorization strings in HTTP headers.  It is particularly aimed at Digest
 * authentication.
 */

package com.elsevier.epic.auth;

import javax.ws.rs.WebApplicationException;
import java.util.HashMap;
import java.util.Map;

public class AuthParser {

   static private int skipWhitespace(String pString, int pPos) {
      for (; pPos < pString.length(); pPos++) {
         if (pString.charAt(pPos) > 0x20) break;
      }
      return pPos;
   }

   static private int consumeValue(String pString, int pPos) {
      for (; pPos < pString.length(); pPos++) {
         char ch = pString.charAt(pPos);
         if ((ch <= 0x20) || (ch == ',')) break;
      }
      return pPos;
   }

   static private int consumeKey(String pString, int pPos) {
      for (; pPos < pString.length(); pPos++) {
         char ch = pString.charAt(pPos);
         if ((ch <= 0x20) || (ch == '=')) break;
      }
      return pPos;
   }

   static private int consumeQuoted(String pString, StringBuilder sb, int pPos) {
      if (pString.charAt(pPos) == '"') {
         pPos++;
         for (; pPos < pString.length(); pPos++) {
            char ch = pString.charAt(pPos);
            if (ch == '"') {
               pPos++;
               break;
            }
            else if (ch == '\\') {
               sb.append(pString.charAt(++pPos));
            }
            else sb.append(ch);
         }
      }
      return pPos;
   }

   static public Map<String, String> parseDigest(String pString) {
      Map<String, String> authKeys = new HashMap<>();

      int i = skipWhitespace(pString, 7); // Skip whitespace
      while (i < pString.length()) { // username="paul", realm="RELX"
         // Extract the key

         int end = consumeKey(pString, i);
         String key = pString.substring(i, end);
         i = skipWhitespace(pString, end);

         if (pString.charAt(i) != '=') throw new WebApplicationException();
         i++;
         i = skipWhitespace(pString, i);

         // Extract the value

         if (pString.charAt(i) == '"') {
            StringBuilder sb = new StringBuilder();
            i = consumeQuoted(pString, sb, i);
            authKeys.put(key, sb.toString());
         }
         else {
            end = consumeValue(pString, i);
            authKeys.put(key, pString.substring(i, end));
            i = end;
         }

         // Skip to next key

         i = skipWhitespace(pString, i);
         if ((i < pString.length()) && (pString.charAt(i) == ',')) i++;
         i = skipWhitespace(pString, i);
      }

      return authKeys;
   }
}