// Support for scopus usage v3/account/[inst id]/sc/usage

package com.elsevier.epic.engineering_village;

import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.utility.Utility;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.io.InputStream;
import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.groupingBy;

public class CombinedDbTopSearchRollup implements DataFeed {
   private static final Logger LOG = Log.getLogger(CombinedDbTopSearchRollup.class);
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe



   PreparedStatement getStatement(Connection con) throws SQLException {
      PreparedStatement ps = con.prepareStatement(getResourceString("/engineering_village_combined_db_top_search.sql"));
      ps.setQueryTimeout(60);
      return ps;
   }
   static List<Integer> mapToList(Map<Integer,Integer> monthCountmap){
      List<Integer> monthCountList = new ArrayList<Integer>(
              Arrays.asList(0,0,0,0,0,0,0,0,0,0,0,0));
      for(int i=0;i<12;i++){

         if(monthCountmap.containsKey(i+1))
            monthCountList.set(i,monthCountmap.get(i+1));
         else
            monthCountList.set(i,0);

      }
      return monthCountList;
   }
   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      if (pIDs.size() < 1) throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);

      String paramAccount  = pIDs.get(0).value;

      String paramDepartmentId    = pParameters.get("departmentid");
      paramAccount=paramAccount.replace("ECR","");


      int accountID;
      try { accountID = Integer.parseInt(paramAccount); }
      catch (NumberFormatException ex) {
         throw new WebApplicationException(ErrorResponse.status(Status.BAD_REQUEST)
            .setMessage("Invalid ID '" + paramAccount + "'")
            .setException(ex)
            .build());
      }
      int departmentId = Utility.readInt(paramDepartmentId);
      ObjectNode jsRoot = jsFactory.objectNode();
      processSearchMetricsResultSet(jsRoot,accountID,departmentId);
      return Response.ok(jsRoot).build();
   }

   private void processSearchMetricsResultSet(ObjectNode jsRoot, int accountID, int departmentID) {
      List<CombinedDbTopSearch> l1  = new ArrayList<>();
      try (Connection con = PostgresClient.getConnection();
           PreparedStatement ps = getStatement(con)) {
         ps.setInt(1, accountID);
         ps.setInt(2, departmentID);
         ps.execute();
         ResultSet rst = ps.getResultSet();
         while (rst.next()) {
            l1.add(new CombinedDbTopSearch(rst.getString(1),rst.getInt(2),rst.getInt(3),rst.getInt(4),rst.getInt(5)));
         }
      }
      catch (SQLException ex) {
         LOG.warn(ex);
         throw new WebApplicationException(ErrorResponse.status(Status.INTERNAL_SERVER_ERROR)
                 .setMessage("A server database failure has occurred.")
                 .setException(ex)
                 .build());
      }
      Map<CombinedDbTopSearchKey,Map<Integer,Map<Integer,Integer>>> dbCombinedMap =
              l1.stream().collect(groupingBy( x-> new CombinedDbTopSearchKey(x.getDbcombined(),x.getLast12monthscount()),groupingBy(x->x.getYear(),
                      groupingBy(x -> x.getMonth(), Collectors.summingInt(x-> x.getCount())))));

      ArrayNode combinedDbArrayNode = jsFactory.arrayNode();
      for(Map.Entry<CombinedDbTopSearchKey,Map<Integer,Map<Integer,Integer>>>  m1 : dbCombinedMap.entrySet()) {
         ObjectNode combinedDbNode = jsFactory.objectNode();
         // System.out.println(m1.getKey().getDbCombined());
         ArrayNode yearArrayNode = jsFactory.arrayNode();
         for(Map.Entry<Integer,Map<Integer,Integer>>  m2 : m1.getValue().entrySet()) {
            ObjectNode yearNode = jsFactory.objectNode();
            yearNode.put("year",m2.getKey());
            List<Integer> monthCountList = mapToList(m2.getValue());
            Integer monthTotal = monthCountList.stream().reduce((x,y) -> x+y).orElse(0);
            yearNode.put("total",monthTotal);
            ArrayNode monthCountArrayNode = jsFactory.arrayNode();
            int counter=1;
            for(Integer count: monthCountList) {
               ObjectNode monthNode = jsFactory.objectNode();
               monthNode.put(Integer.valueOf(counter).toString(),count);
               monthCountArrayNode.add(monthNode);
               counter++;
            }
            yearNode.set("months",monthCountArrayNode);
            yearArrayNode.add(yearNode);
         }
         combinedDbNode.put("combineddb",m1.getKey().getDbCombined());
         combinedDbNode.put("last12months",m1.getKey().getLast12MonthCount());
         combinedDbNode.set("yearmonths",yearArrayNode);
         combinedDbArrayNode.add(combinedDbNode);
      }
        jsRoot.set("metrics", combinedDbArrayNode);
   }

   static private String getResourceString(String pName) {
      // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
      // all available resource files.
      InputStream isResource = String.class.getResourceAsStream(pName);
      if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
      else throw new RuntimeException("Could not find resource '" + pName + "'");
   }
}


class CombinedDbTopSearch {
   public String getDbcombined() {
      return dbcombined;
   }


   private String dbcombined;
   private int year;
   private int count;
   private int month;

   public int getLast12monthscount() {
      return last12monthscount;
   }

   private int last12monthscount;

   public CombinedDbTopSearch(String dbcombined, int count, int year, int month, int last12monthscount) {
      this.dbcombined= dbcombined;
      this.year = year;
      this.count = count;
      this.month = month;
      this.last12monthscount=last12monthscount;
   }
   public int getYear() {
      return year;
   }

   public void setYear(int year) {
      this.year = year;
   }

   public int getCount() {
      return count;
   }

   public void setCount(int count) {
      this.count = count;
   }

   public int getMonth() {
      return month;
   }

   public void setMonth(int month) {
      this.month = month;
   }

   @Override
   public String toString() {
      return "TopSearch{" +
              "year=" + year +
              ", count=" + count +
              ", month=" + month +
              '}';
   }
}

class CombinedDbTopSearchKey {
   @Override
   public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;
      CombinedDbTopSearchKey that = (CombinedDbTopSearchKey) o;
      return last12MonthCount == that.last12MonthCount &&
              dbCombined.equals(that.dbCombined);
   }

   @Override
   public int hashCode() {
      return Objects.hash(dbCombined, last12MonthCount);
   }

   @Override
   public String toString() {
      return "TopSearchKey{" +
              "dbCombined='" + dbCombined + '\'' +
              ", last12MonthCount=" + last12MonthCount +
              '}';
   }

   private String dbCombined;
   private int last12MonthCount;
   public String getDbCombined() {
      return dbCombined;
   }

   public int getLast12MonthCount() {
      return last12MonthCount;
   }


   public CombinedDbTopSearchKey(String dbCombined, int last12MonthCount) {
      this.dbCombined = dbCombined;
      this.last12MonthCount = last12MonthCount;
   }
}
