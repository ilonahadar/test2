package com.elsevier.epic.sdusage;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.*;

/**
 * Created by lenehajf on 5/22/17.
 */
public class SDBreakdown {


    private Set<String> values = null;
    private ObjectNode oNode = null;
    private Map<Integer, Long[]> total = null;
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe
    private Map<String, ObjectNode> years = null;
    private String name;

    public SDBreakdown(String name, String[] values){
        this.name = name;
        this.values = new HashSet<String>(Arrays.asList(values));
        oNode = jsFactory.objectNode();
        years = new HashMap<>();
    }

    public boolean contains(String val){
         return values.contains(val);
    }

    public void setNode(String name, JsonNode value){
        oNode.set(name, value);
    }

    public ObjectNode getNodeObject(){
        if (total != null) {
            ObjectNode lNode = jsFactory.objectNode();
            for(Integer yr: total.keySet()){
                ArrayNode jsTotal = processArray(total.get(yr));
                lNode.set(String.valueOf(yr), jsTotal);
            }
            oNode.set("Total", lNode);

            for(String key :years.keySet()){
                ObjectNode locNode = years.get(key);
                oNode.set(key.toString(), locNode );
            }
        }
        return oNode;
    }

    public void addToTotal(int year, Long[] arr){
        if (total  ==  null){
            total = new HashMap<>();
        }
        if (total.get(year) == null) {
            total.put(year, arr);
        } else {
            Long[] arrYr = total.get(year);
            for (int i = 0; i < arr.length; ++i) {
                arrYr[i] = arrYr[i] + arr[i];
            }
            total.put(year, arrYr);
        }
    }

    public void addToTotal(Map<Integer, Long[]> years){
        if (years == null ) return;
        for(Integer yr: years.keySet()){
            addToTotal(yr, years.get(yr).clone());
        }
    }

    public void setTotal(Map<Integer, Long[]> total){
        this.total = total;
    }

    public Map<Integer, Long[]> getTotal(){
        return this.total;
    }

    public String getName(){
        return this.name;
    }

    public void addToYears(String category, int year, Long[] months){
        ObjectNode yrs = years.get(category);
        if (yrs == null){
            ObjectNode locNode = jsFactory.objectNode();
            locNode.set(String.valueOf(year), processArray(months));
            years.put(category, locNode);
        } else {
            yrs.set(String.valueOf(year), processArray(months));
        }
    }

    public void addObjectNode(String name, ObjectNode node){
        oNode.set(name, node);
    }

    static private ArrayNode processArray(Long[] arr){
        ArrayNode jsMonths = jsFactory.arrayNode();
        for (long v : arr) jsMonths.add(v);
        return jsMonths;
    }
}
