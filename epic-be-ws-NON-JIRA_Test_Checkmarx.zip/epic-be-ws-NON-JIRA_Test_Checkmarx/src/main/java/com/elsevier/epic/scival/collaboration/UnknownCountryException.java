package com.elsevier.epic.scival.collaboration;

public class UnknownCountryException extends Exception {
    public UnknownCountryException(int countryISONum) {
        super(String.format("Unknown country with ISO Num %d", countryISONum));
    }
}
