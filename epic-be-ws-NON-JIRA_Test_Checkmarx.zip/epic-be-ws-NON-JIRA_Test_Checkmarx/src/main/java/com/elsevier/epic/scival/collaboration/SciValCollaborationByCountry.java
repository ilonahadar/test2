package com.elsevier.epic.scival.collaboration;

import com.elsevier.epic.scival.ScivalEntityMetricJsonParser;
import com.elsevier.epic.scival.ScivalEntityMetricsJsonParser;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.scival.SVInstitute;
import com.google.gson.*;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import javax.ws.rs.core.Response;

/**
 * The primary logic of SciVal Collaboration By Country interaction with Scival api and local Postgres data (all isolated by strategy)
 */
public class SciValCollaborationByCountry {
    private static final Logger LOG = Log.getLogger(SciValCollaborationByCountry.class);

    public static final int TOP_3 = 3;
    private final CurrentYear currentYear;
    private final ScivalCollaboratingEntityEndpoint scivalCollaboratingEntityEndpoint;
    private CountryNameLookup countryNameLookup;
    private AccountLookup accountLookup;
    private ScivalFieldWeightCitImpactEndpoint scivalFieldWeightCitImpactEndpoint;

    public SciValCollaborationByCountry(ScivalCollaboratingEntityEndpoint scivalCollaboratingEntityEndpoint, ScivalFieldWeightCitImpactEndpoint scivalFieldWeightCitImpactEndpoint,
                                        CountryNameLookup countryNameLookup, AccountLookup accountLookup, CurrentYear currentYear) {
        this.currentYear = currentYear;
        this.scivalCollaboratingEntityEndpoint = scivalCollaboratingEntityEndpoint;
        this.countryNameLookup = countryNameLookup;
        this.accountLookup = accountLookup;
        this.scivalFieldWeightCitImpactEndpoint = scivalFieldWeightCitImpactEndpoint;
    }

    public Response query(Account account, Country countryToFilterBy, StartAndEndYear startAndEndYear) {
        if (startAndEndYear.getStartYear() == null || !isValidYear(startAndEndYear.getStartYear())) {
            return ErrorResponse.status(Response.Status.BAD_REQUEST).setMessage("A yearStart parameter value is required.").build();
        }
        if (startAndEndYear.getEndYear() == null || !isValidYear(startAndEndYear.getEndYear())) {
            return ErrorResponse.status(Response.Status.BAD_REQUEST).setMessage("A yearEnd parameter value is required.").build();
        }

        int startYear = asYear(startAndEndYear.getStartYear());
        if (startYear < 1996 || startYear > currentYear.getCurrentYear()) {
            return ErrorResponse.status(Response.Status.BAD_REQUEST).setMessage("The yearStart parameter value is invalid.").build();
        }
        int endYear = asYear(startAndEndYear.getEndYear());
        if (endYear < 1996 || endYear > currentYear.getCurrentYear()) {
            return ErrorResponse.status(Response.Status.BAD_REQUEST).setMessage("The endYear parameter value is invalid.").build();
        }

        if (startYear > endYear) {
            return ErrorResponse.status(Response.Status.BAD_REQUEST).setMessage("Bad start and end year values").build();
        }

        int scivalInstitutionId = 0;
        try {
            scivalInstitutionId = accountLookup.getScivalInstitutionId(account.getAccountId());
        } catch (RuntimeException e) {
            return ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR).setMessage(e.getMessage()).build();
        } catch (UnknownAccountException e) {
            return ErrorResponse.status(Response.Status.NOT_FOUND).setMessage(e.getMessage()).build();
        }

        String countryName = null;
        try {
            countryName = countryNameLookup.getCountryName(countryToFilterBy.getCountryISONumber());
        } catch (UnknownCountryException e) {
            LOG.warn(e.getMessage());
            return ErrorResponse.status(Response.Status.BAD_REQUEST).setMessage(e.getMessage()).build();
        } catch (Exception e) {
            LOG.warn(e.getMessage());
            return ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR).setMessage(e.getMessage()).build();
        }

        ScivalCallResponse scivalCollaboratingEntityEndpointScivalCallResponse = scivalCollaboratingEntityEndpoint.call(scivalInstitutionId, countryToFilterBy.getCountryISONumber(), startYear, endYear);
        if (!scivalCollaboratingEntityEndpointScivalCallResponse.success) {
            String failureDescription = scivalCollaboratingEntityEndpointScivalCallResponse.getDescription();
            LOG.warn(failureDescription);
            return ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR).setMessage(failureDescription).build();
        }

        ScivalEntityMetricsJsonParser scivalResponse = null;
        try {
            scivalResponse = new ScivalEntityMetricsJsonParser(scivalCollaboratingEntityEndpointScivalCallResponse.json);
        } catch (JsonSyntaxException e) {
            return ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR).setMessage("Scival returned bad json!").build();
        }

        GetFWCIForInstitution getFWCIForInstitution = new GetFWCIForInstitution(scivalFieldWeightCitImpactEndpoint);
        try {
            getFWCIForInstitution.call(scivalInstitutionId, startYear, endYear);
        } catch (Exception e) {
            return ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR).setMessage("Scival returned bad json!").build();
        }

        if (!getFWCIForInstitution.getScivalCallResponse().success) {
            String failureDescription = getFWCIForInstitution.getScivalCallResponse().getDescription();
            LOG.warn(failureDescription);
            return ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR).setMessage(failureDescription).build();
        }

        SciValCollaborationByCountryResponse response = new SciValCollaborationByCountryResponse(countryName, getFWCIForInstitution.getFwci());
        int index = 0;
        while (response.resultCount() < TOP_3 && index < scivalResponse.getItemCount()) {
            ScivalEntityMetricJsonParser item = scivalResponse.getItem(index);

            try {
               SVInstitute inst = SVInstitute.getSVInstitute(item.getInstitutionId());
                GetFWCIForInstitution getFWCIForOtherInstitution = new GetFWCIForInstitution(scivalFieldWeightCitImpactEndpoint);
                try {
                    getFWCIForOtherInstitution.call(item.getInstitutionId(), startYear, endYear);
                } catch (Exception e) {
                    return ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR).setMessage("Scival returned bad json!").build();
                }

                if (getFWCIForOtherInstitution.getScivalCallResponse().success) {
                    response.addResult(inst.name != null ? inst.name : Integer.toString(inst.id), item.getCoAuthoredPublications(), item.getCoAuthoredGrowthPercent(), getFWCIForOtherInstitution.getFwci(), item.getCoAuthoredFWCI());
                }
                else {
                    String failureDescription = getFWCIForOtherInstitution.getScivalCallResponse().getDescription();
                    LOG.warn(failureDescription);
                    return ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR).setMessage(failureDescription).build();
                }
            } catch (Exception e) {
                LOG.warn(e.getMessage());
            }
            index++;
        }
        return Response.ok(new GsonBuilder().create().toJson(response)).build();
    }

    private int asYear(String yearParameter) {
        return Integer.parseInt(yearParameter);
    }

    private boolean isValidYear(String startYearParameter) {
        try {
            Integer.parseInt(startYearParameter);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public interface Country {
        int getCountryISONumber();
    }

    public interface Account {
        int getAccountId();
    }

    public interface StartAndEndYear {
        String getStartYear();
        String getEndYear();
    }

    public interface CurrentYear {
        int getCurrentYear();
    }
}
