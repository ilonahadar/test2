/**
 * The /api interface provides run-time introspection of the web service interfaces.
 */

package com.elsevier.epic.core;

import com.elsevier.epic.auth.AuthFilter;
import com.elsevier.epic.auth.UserCredentials;
import com.elsevier.epic.exceptions.AppException;
import com.elsevier.epic.jaxb.ResourceType;
import com.elsevier.epic.jaxb.Webservice;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

@Path("/api")
@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
public class API {
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe

   final String path;
   final Map<Pattern, ResourceType> resources;

   public API(String path) {
      this.resources = new HashMap<>();
      this.path = path;
   }

   @GET
   @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
   public Response getAPI(@Context HttpServletRequest pRequest) throws IOException {
      if (("application/json").equals(pRequest.getContentType())) {
         return Response.ok(ServiceBuilder.getPublicXML(), MediaType.APPLICATION_JSON).build();
      }
      else {
         return Response.ok(ServiceBuilder.getPublicXML(), MediaType.APPLICATION_XML).build();
      }
   }

   @GET
   @Path("/refresh")
   public synchronized Object getRefresh(@Context HttpServletRequest pRequest) {
      AuthFilter.checkAccessLevel(pRequest, UserCredentials.AL_ADMIN);

      try {
         ServiceBuilder.refreshConfiguration();
         return Response.ok().build();
      }
      catch (IOException ex) {
         throw new AppException("Failed to process internal schema files.");
      }
   }

   // Returns a plain-string name of the running service.

   @GET
   @Path("/service/name")
   public Response getServiceName() {
      Webservice ws = ServiceBuilder.getServiceXML();
      String name = ws.getName();
      if (name != null) {
         ObjectNode jsResult = jsFactory.objectNode();
         jsResult.put("serviceName", name);
         return Response.ok(jsResult, MediaType.APPLICATION_JSON_TYPE).build();
      }
      else return Response.noContent().build();
   }
}
