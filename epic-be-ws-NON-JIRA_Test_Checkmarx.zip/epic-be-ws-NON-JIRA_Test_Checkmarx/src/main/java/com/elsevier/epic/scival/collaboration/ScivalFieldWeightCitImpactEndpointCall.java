package com.elsevier.epic.scival.collaboration;

import com.elsevier.epic.Server;
import com.elsevier.epic.scival.SciVal;

import java.net.MalformedURLException;
import java.net.URL;

public class ScivalFieldWeightCitImpactEndpointCall implements ScivalFieldWeightCitImpactEndpoint {

    @Override
    public ScivalCallResponse call(int scivalInstitutionId, int startYear, int endYear) {
        final String site = Server.config.getSVSite();

        final StringBuilder sbURI = new StringBuilder()
                .append("https://" + site + "/api/Metric/FieldWeightCitImpact")
                .append("?entities=Institution/").append(scivalInstitutionId)
                .append("&years=").append(startYear).append("-").append(endYear);

        URL url = null;
        try {
            url = new URL(sbURI.toString());
        } catch (MalformedURLException e) {
            return ScivalCallResponse.failure(url, e);
        }
        try {
            return ScivalCallResponse.success(SciVal.requestContent(SciVal.svClient().target(sbURI.toString())));
        } catch (Exception e) {
            return ScivalCallResponse.failure(url, e);
        }
    }
}
