package com.elsevier.epic.scival.collaboration;

import com.elsevier.epic.Server;
import com.elsevier.epic.scival.SciVal;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

class ScivalCollaboratingEntityEndpointCall implements ScivalCollaboratingEntityEndpoint {

    @Override
    public ScivalCallResponse call(int scivalInstitutionId, int isoCountryCode, int startYear, int endYear) {
        final String site = Server.config.getSVSite();

        final StringBuilder sbURI = new StringBuilder()
                .append("https://" + site + "/api/CollaborationMetric/CollaboratingEntity")
                .append("?entity=Institution/").append(scivalInstitutionId)
                .append("&years=").append(startYear).append("-").append(endYear)
                .append("&countryCodeFilter=").append(isoCountryCode);

        URL url = null;
        try {
            url = new URL(sbURI.toString());
        } catch (MalformedURLException e) {
            return ScivalCallResponse.failure(url, e);
        }

        try {
            return ScivalCallResponse.success(SciVal.requestContent(SciVal.svClient().target(sbURI.toString())));
        } catch (Exception e) {
            return ScivalCallResponse.failure(url, e);
        }
    }
}
