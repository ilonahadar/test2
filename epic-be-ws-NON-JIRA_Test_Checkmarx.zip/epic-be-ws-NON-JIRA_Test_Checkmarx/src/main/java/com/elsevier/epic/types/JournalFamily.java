package com.elsevier.epic.types;

public class JournalFamily {
    public String name;
}
