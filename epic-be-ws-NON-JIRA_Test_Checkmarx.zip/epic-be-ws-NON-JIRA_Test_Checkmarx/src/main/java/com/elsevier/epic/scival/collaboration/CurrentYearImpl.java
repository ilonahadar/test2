package com.elsevier.epic.scival.collaboration;

import java.util.Calendar;

public class CurrentYearImpl implements SciValCollaborationByCountry.CurrentYear {
    @Override
    public int getCurrentYear() {
        return Calendar.getInstance().get(Calendar.YEAR);
    }
}
