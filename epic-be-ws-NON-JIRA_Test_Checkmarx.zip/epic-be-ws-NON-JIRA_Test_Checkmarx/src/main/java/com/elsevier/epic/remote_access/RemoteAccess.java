package com.elsevier.epic.remote_access;

import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.postgres.PostgresClient;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.elsevier.epic.utility.Utility;
import java.io.InputStream;
import java.sql.*;
import java.util.*;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;
import java.util.Comparator;
import java.util.Date;

/**
 * Remote access api
 */
public class RemoteAccess implements DataFeed{

    private static final Logger LOG = Log.getLogger(RemoteAccess.class);
    private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false); // It's thread-safe

    PreparedStatement getStatement(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement(getResourceString("/remote_access.sql"));
        ps.setQueryTimeout(60);
        return ps;
    }

    @Override
    public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
        if (pIDs.size() < 1) throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);

        String paramAccount  = pIDs.get(0).value;

        String paramReport;
        paramReport = "SUM";

        int accountID;
        try { accountID = Integer.parseInt(paramAccount); }
        catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
                    .setMessage("Invalid ID '" + paramAccount + "'")
                    .setException(ex)
                    .build());
        }

        ObjectNode jsRoot = jsFactory.objectNode();
        ObjectNode jsParams = jsFactory.objectNode();
        jsRoot.set("parameters", jsParams);
        jsParams.put("id", paramAccount)
                .put("report", paramReport.toUpperCase());

        queryCounter(jsRoot, accountID);
        return Response.ok(jsRoot).build();
    }

    private void queryCounter(ObjectNode pResult, int pSIS) {
        try (Connection con = PostgresClient.getConnection();
             PreparedStatement ps = getStatement(con)) {
            ps.setInt(1, pSIS);
            ps.setInt(2, pSIS);
            ps.setInt(3, pSIS);
            ps.setInt(4, pSIS);
            ps.setInt(5, pSIS);
            ps.setInt(6, pSIS);
            if (!CoreServer.isProduction()) LOG.info(ps.toString());

            ObjectNode jsUsage = jsFactory.objectNode();

            ps.execute();
            /*
                getRA_PersonalizedUsers(?);
                getRA_DeviceTypeUsage(?);
                getRA_AccessType(?);
                getRA_GenPersonalized(?, ARRAY['ANON_SHIBBOLETH','REG_SHIBBOLETH']::text[]);
                getRA_GenPersonalized(?, ARRAY['ANON_IP','REG_IP']::text[]);
                getRA_PeerInstitutions(?);
             */


            processRecords(ps, jsUsage, "PersonalizedUser");
            ps.getMoreResults();
            processRecords(ps, jsUsage, "DeviceTypeUsage") ;
            ps.getMoreResults();
            processRecords(ps, jsUsage, "AccessType");
            ps.getMoreResults();
            processRecords(ps, jsUsage, "RemotePersonalized");
            ps.getMoreResults();
            processRecords(ps, jsUsage, "CampusPersonalized");
            ps.getMoreResults();
            processRecords(ps, jsUsage, "PeerInstitutions");
            pResult.set("usage", jsUsage);
        }
        catch (SQLException ex) {
            LOG.warn(ex);
            throw new WebApplicationException(ErrorResponse.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .setMessage("A server database failure has occurred.")
                    .setException(ex)
                    .build());
        }
    }

    static private void processRecords(PreparedStatement ps, ObjectNode jsUsage, String name) throws java.sql.SQLException {
        ResultSet rst = ps.getResultSet();
        ResultSetMetaData rsmd = rst.getMetaData();
        //ArrayList<String> colNames = getColumnNames(rsmd);

        int colCount = rsmd.getColumnCount();

        ArrayNode currNode = jsFactory.arrayNode();
        //Note: the order is set in the query...
        while(rst.next()){

            ObjectNode locNode = jsFactory.objectNode();
            for(int ii=1; ii<=colCount; ii++){
                String colName = rsmd.getColumnName(ii);
                int colType = rsmd.getColumnType(ii);
                if (colType == Types.VARCHAR || colType == Types.CHAR || colType == Types.DATE){
                    String result = rst.getString(ii);
                    locNode.put(colName, result);
                } else if( colType == Types.NUMERIC || colType == Types.BIGINT || colType == Types.INTEGER) {
                    float result = rst.getFloat(ii);
                    locNode.put(colName, result);
                } else {
                    throw new RuntimeException("Could not find type for '" + colName + "'");
                }

            }
            currNode.add(locNode);
        }
        jsUsage.set(name, currNode);
    }

    static private String getResourceString(String pName) {
        // Note: If the 'resource cannot be found' then you may need to do a clean rebuild so that your IDE can resolve
        // all available resource files.
        InputStream isResource = String.class.getResourceAsStream(pName);
        if (isResource != null) return new Scanner(isResource, "UTF-8").useDelimiter("\\A").next();
        else throw new RuntimeException("Could not find resource '" + pName + "'");
    }
}
