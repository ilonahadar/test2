package com.elsevier.epic.scival;

public class ScivalEntityURI {
    private final int institutionId;

    public ScivalEntityURI(String entityURI) {
        String strippedOfIdentifier = entityURI.replace("Institution/", "");
        this.institutionId = Integer.parseInt(strippedOfIdentifier);
    }

    public int getInstitutionId() {
        return institutionId;
    }
}
