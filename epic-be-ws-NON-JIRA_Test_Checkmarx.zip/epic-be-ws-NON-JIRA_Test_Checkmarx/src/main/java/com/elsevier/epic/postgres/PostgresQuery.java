package com.elsevier.epic.postgres;

import com.elsevier.epic.postgres.RunQuery;
import org.eclipse.jetty.server.session.Session;
//import org.eclipse.jetty.server.session.JDBCSessionDataStore.Session

public class PostgresQuery extends RunQuery {
   public Session session;
   public java.sql.ResultSet sqlRecords;

   public PostgresQuery(String name, String sql, String store, String src) {
      super(name, sql, store, src);
   }
}

