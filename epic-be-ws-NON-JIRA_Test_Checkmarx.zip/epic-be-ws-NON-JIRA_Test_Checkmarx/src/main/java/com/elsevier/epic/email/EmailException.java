package com.elsevier.epic.email;

import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.core.CoreServer;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetAddress;

public class EmailException {
   private static final Logger LOG = Log.getLogger(EmailException.class);

   // The 'sending' variable is used to prevent any possibility of recursively sending emails (which could
   // happen if an exception is generated while attempting to send a message).

   private static final ThreadLocal<Boolean> sending = new ThreadLocal<Boolean>() {
      @Override
      protected Boolean initialValue() {
         return false;
      }
   };

   /**
    * Send an email describing an exception to the site administrator.
    *
    * @param pCause
    * @param pMessage
    */

   static public void send(Throwable pCause, String pMessage) {
      if (sending.get() == true) return;

      try {
         sending.set(true);
         if (CoreServer.emailServer != null) {
            StringBuilder body = new StringBuilder();

            if (pMessage != null) {
               body.append(pMessage).append("\n\n");
            }

            if (pCause != null) {
               StringWriter sw = new StringWriter();
               PrintWriter pw = new PrintWriter(sw);
               pCause.printStackTrace(pw);
               body.append(sw.toString());
            }
            else {
               for (StackTraceElement ste : new Throwable().getStackTrace()) {
                  body.append(ste.toString()).append("\n");
               }
            }

            EmailMessage msg = new EmailMessage();
            msg.subject = "Web Service Exception";
            msg.content = body.toString();
            CoreServer.emailServer.sendMessage(msg);
         }
      }
      catch (Exception e) { // Catch-all is necessary because this method can be called within other catch frames.
         LOG.warn("Failed to send email.", e);
      }
      finally {
         sending.set(false);
      }
   }

   /**
    * Convert an ErrorResponse to an email message.
    *
    * @param pResponse
    */

   static public void sendErrorResponse(ErrorResponse pResponse) {
      if (sending.get() == true) return;

      try {
         sending.set(true);

         if (CoreServer.emailServer != null) {
            StringBuilder body = new StringBuilder();

            body.append("Server IP: ").append(InetAddress.getLocalHost().getHostAddress()).append("\n\n");

            body.append("Status Code ").append(pResponse.getStatusCode()).append(": ")
                .append(pResponse.getMessage())
                .append("\n\n");

            // Include a print-out of the exception if we have one.

            Exception ex = pResponse.getException();
            if (ex != null) {
               StringWriter sw = new StringWriter();
               ex.printStackTrace(new PrintWriter(sw));
               body.append(sw.toString());
            }
            else {
               for (StackTraceElement ste : new Throwable().getStackTrace()) {
                  body.append(ste.toString()).append("\n");
               }
            }

            EmailMessage msg = new EmailMessage();
            msg.subject = "Web Service Error";
            msg.content = body.toString();
            CoreServer.emailServer.sendMessage(msg);
         }
      }
      catch (Exception e) { // Catch-all is necessary because this method can be called within other catch frames.
         LOG.warn("Failed to send email.", e);
      }
      finally {
         sending.set(false);
      }
   }
}
