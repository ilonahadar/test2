package com.elsevier.epic.auth;

public class AuthException extends Exception {
   public String userMsg = null; // A user message can be defined that is suitable for user dialogs.  Otherwise use Exception.msg for dev messages.
   public int status = 401;

   public AuthException(int pStatus, String pMsg) {
      this.status = pStatus;
      this.userMsg = pMsg;
   }

   public AuthException(String pMsg){
      this.userMsg = pMsg;
   }

   public AuthException(String pMsg, Throwable t){
      this.userMsg = pMsg;
   }

   public AuthException(Throwable t) {
      this.userMsg = t.getMessage();
   }
}