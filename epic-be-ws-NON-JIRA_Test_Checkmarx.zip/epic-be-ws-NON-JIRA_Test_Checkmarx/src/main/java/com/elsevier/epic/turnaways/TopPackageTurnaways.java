package com.elsevier.epic.turnaways;

import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.postgres.DataFeed;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.postgres.PostgresClient;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import javax.ws.rs.WebApplicationException;
import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.Define;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.sqlobject.stringtemplate.UseStringTemplate3StatementLocator;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

public class TopPackageTurnaways implements DataFeed {
   private static final JsonNodeFactory jsFactory = new JsonNodeFactory(false);

   static class Result {
      final int packageID;
      final String packageTitle;
      final int totalTurnaways;
      final int totalTitles;
      final int year;
      final int month;
      final String topISBN;
      final String topTitle;
      final int topCount;

      public Result(int id, String title, int totalTurnaways, int totalTitles, int year, int month,
         String topISBN, String topTitle, Integer topCount) {

         this.packageID = id;
         this.packageTitle = title;
         this.totalTurnaways = totalTurnaways;
         this.totalTitles = totalTitles;
         this.year = year;
         this.month = month;
         this.topISBN = topISBN;
         this.topTitle = topTitle;
         this.topCount = topCount;
      }
   }

   @UseStringTemplate3StatementLocator()
   interface Query {
      class ResultMap implements ResultSetMapper<Result> {
         @Override
         public Result map(int row, ResultSet rst, StatementContext ctxStatement) throws SQLException {
            return new Result(rst.getInt(1), rst.getString(2), rst.getInt(3), rst.getInt(4), rst.getInt(5),
               rst.getInt(6), rst.getString(7), rst.getString(8), rst.getInt(9));
         }
      }

      @Mapper(ResultMap.class)
      @SqlQuery("SELECT package_id, package_title, <usageCount> AS totalTurnaways, <titleCount> AS totalTitles, year, month, top_isbn, top_title, top_count\n" +
                "FROM vw_package_monthly_turnaways_rolling\n" +
                "WHERE (sis=:accountId) AND (<usageCount> > 0) <filter>\n" +
                "ORDER BY <sort>\n" +
                "LIMIT 30;")
      List<Result> runQuery(@Define("usageCount") String usageCount, @Define("titleCount") String titleCount, @Define("filter") String filter, @Define("sort") String sort, @Bind("accountId") int accountId);
   }

   // Entry point

   @Override
   public Response query(HttpServletRequest pRequest, ArrayList<IDValue> pIDs, Map<String, String> pParameters) {
      int accountID = Integer.parseInt(pIDs.get(0).value);
      int period = Integer.parseInt(pParameters.get("period"));
      String sort = pParameters.get("sort");
      String subject = pParameters.get("subject");

      if (period == 0) period = 12;

      String usageField = "u12";
      String titleField = "t12";

      switch (period) {
         //case 6: usageField = "u6"; titleField = "t6"; break;
         case 12: usageField = "u12"; titleField = "t12"; break;
         //case 24: usageField = "u24"; titleField = "t24"; break;
         //case 36: usageField = "u36"; titleField = "t36"; break;
         default:
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
               //.setMessage("Acceptable period values are 6, 12, 24 or 36 (client requested " + period + ")")
               .setMessage("Acceptable period value is 12 (client requested " + period + ")")
               .build());
      }

      String sortField;
      if (sort == null) sort = "total";

      switch (sort) {
         case "title": sortField = titleField + " DESC, package_title ASC"; break;
         case "total": sortField = usageField + " DESC, package_title ASC"; break;
         case "popularity": sortField = "(" + usageField + "\\:\\:float / " + titleField + "\\:\\:float) DESC, " + usageField + " DESC, package_title ASC"; break;
         default:
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
               .setMessage("Unrecognised sort parameter '" + sort + "'")
               .build());
      }

      String filter = "";
      if (subject != null) {
         try {
            int subjectID = Integer.parseInt(subject);
            filter = " AND (subject_id=" + subjectID + ")";
         }
         catch (NumberFormatException ex) {
            throw new WebApplicationException(ErrorResponse.status(Response.Status.BAD_REQUEST)
               .setMessage("Invalid subject parameter '" + subject + "'")
               .build());
         }
      }

      Query q = PostgresClient.getDBI().onDemand(Query.class);
      List<Result> results = q.runQuery(usageField, titleField, filter, sortField, accountID);

      if (results.size() == 0) {
         throw new WebApplicationException(ErrorResponse.status(Response.Status.NO_CONTENT)
            .setMessage("No data available for the queried account.")
            .build());
      }

      int year = results.get(0).year;
      int month = results.get(0).month;

      ArrayNode jsResults = jsFactory.arrayNode();
      int totalRecords = 0;
      for (Result entry : results) {
         ObjectNode jsObject = jsResults.addObject();
         jsObject.put("packageID", entry.packageID);
         jsObject.put("package", entry.packageTitle);
         jsObject.put("total", entry.totalTurnaways);
         jsObject.put("titles", entry.totalTitles);
         jsObject.put("topISBN", entry.topISBN);
         jsObject.put("topTitle", entry.topTitle);
         jsObject.put("topTitleCount", entry.topCount);
         totalRecords++;
      }

      ObjectNode jsRoot = jsFactory.objectNode();

      jsRoot.set("parameters",
         jsFactory.objectNode()
            .put("account", accountID)
            .put("sort", sort));

      jsRoot.put("totalRecords", totalRecords);
      jsRoot.put("reportDate", String.format("%04d-%02d-01", year, month));
      jsRoot.put("period", period);
      jsRoot.put("interval", "monthly");
      jsRoot.set("results", jsResults);

      return Response.ok(jsRoot).build();
   }
}
