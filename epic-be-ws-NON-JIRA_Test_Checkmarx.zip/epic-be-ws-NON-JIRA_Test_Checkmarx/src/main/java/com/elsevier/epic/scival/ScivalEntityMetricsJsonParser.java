package com.elsevier.epic.scival;

import com.elsevier.epic.scival.ScivalEntityMetricJsonParser;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import java.util.ArrayList;
import java.util.List;

public class ScivalEntityMetricsJsonParser {

    public static final String COLLAB_ENTITY_METRICS_KEY = "collabEntityMetrics";
    public static final String MISSING_COLLAB = "Unexpected JSON from ScivalEntityMetrics endpoint, missing 'collabEntityMetrics'";
    private final List<ScivalEntityMetricJsonParser> itemParsers = new ArrayList();

    public ScivalEntityMetricsJsonParser(String json) {
        JsonElement parser = new JsonParser().parse(json);
        JsonArray collabEntityMetrics;
        try {
            collabEntityMetrics = parser.getAsJsonObject().getAsJsonArray(COLLAB_ENTITY_METRICS_KEY);
        } catch (ClassCastException e) {
            throw new JsonSyntaxException(MISSING_COLLAB);
        }
        if (collabEntityMetrics == null) {
            throw new JsonSyntaxException(MISSING_COLLAB);
        }

        for (JsonElement collabEntityMetric : collabEntityMetrics) {
            itemParsers.add(new ScivalEntityMetricJsonParser(collabEntityMetric));
        }
    }

    public int getItemCount() {
        return itemParsers.size();
    }

    public ScivalEntityMetricJsonParser getItem(int index) {
        return itemParsers.get(index);
    }
}
