package com.elsevier.epic;

import com.elsevier.epic.core.CoreServer;

public class Server extends CoreServer {
   public static void main(String[] args) throws Exception {
      System.out.println("EPIC Web Service API");
      System.out.println("Copyright Elsevier 2015\n");

      new CoreServer().run(args);
   }
}
