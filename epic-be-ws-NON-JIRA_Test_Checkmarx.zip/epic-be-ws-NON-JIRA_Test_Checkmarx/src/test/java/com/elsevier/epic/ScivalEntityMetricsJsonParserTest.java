package com.elsevier.epic;

import com.elsevier.epic.scival.ScivalEntityMetricsJsonParser;
import com.elsevier.epic.scival.ScivalEntityMetricJsonParser;
import com.google.gson.JsonSyntaxException;
import org.apache.commons.io.FileUtils;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

import static org.fest.assertions.Assertions.assertThat;

public class ScivalEntityMetricsJsonParserTest {

    @Test
    public void canParseMultipleItems() throws IOException {
        String json = FileUtils.readFileToString(new File(getClass().getClassLoader().getResource("com/elsevier/epic/scival/scival-api-collaboration-leeds-university.json").getPath()));
        assertThat(json).isNotNull();

        ScivalEntityMetricsJsonParser parser = new ScivalEntityMetricsJsonParser(json);
        assertThat(parser.getItemCount()).isEqualTo(15);

        ScivalEntityMetricJsonParser item0 = parser.getItem(0);
        assertThat(item0).isNotNull();
        assertThat(item0.getInstitutionId()).isEqualTo(310011);
        assertThat(item0.getCoAuthoredPublications()).isEqualTo(137);
        assertThat(item0.getCoAuthoredGrowthPercent()).isEqualTo(-13.725491f);
        assertThat(item0.getCoAuthoredFWCI()).isEqualTo(3.6178463f);

        ScivalEntityMetricJsonParser item1 = parser.getItem(1);
        assertThat(item1).isNotNull();
        assertThat(item1.getInstitutionId()).isEqualTo(310010);
        assertThat(item1.getCoAuthoredPublications()).isEqualTo(51);
        assertThat(item1.getCoAuthoredGrowthPercent()).isEqualTo(7.142857f);
        assertThat(item1.getCoAuthoredFWCI()).isEqualTo(5.9245324f);
    }

    @Test(expected = JsonSyntaxException.class)
    public void throwsJsonSyntaxExceptionIfCollabEntityMetricsItemMissing() {
        new ScivalEntityMetricsJsonParser("{}");
    }

    @Test(expected = JsonSyntaxException.class)
    public void throwsJsonSyntaxExceptionIfCollabEntityMetricsItemIsNotAnArray() {
        new ScivalEntityMetricsJsonParser("{\"" + ScivalEntityMetricsJsonParser. COLLAB_ENTITY_METRICS_KEY + "\": 123}");
    }

    @Test
    public void canParseEmptyMetricsArray() {
        ScivalEntityMetricsJsonParser parser = new ScivalEntityMetricsJsonParser("{\"collabEntityMetrics\":[]}");
        assertThat(parser.getItemCount()).isEqualTo(0);
    }

    @Test(expected = JsonSyntaxException.class)
    public void throwsJsonSyntaxExceptionIfNotValidJson() {
        new ScivalEntityMetricsJsonParser("what a load of nonsense");
    }

    @Test(expected = JsonSyntaxException.class)
    public void throwsJsonSyntaxExceptionIfItemParserThrowsOne() {
        new ScivalEntityMetricsJsonParser("{\"collabEntityMetrics\":[{}]}");
    }

}
