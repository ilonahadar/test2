package com.elsevier.epic.auth;

import org.junit.jupiter.api.Test;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class EncryptionUtilsTest {

    @Test
    public void shouldReturnDecryptedPassword()
            throws InvalidAlgorithmParameterException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException,
                   BadPaddingException, InvalidKeyException {
        //given
        final String key = "sixteencharacter";
        final String initVector = "jvHJ1XFt0IXBrxxx";
        final String password = "secret password";
        final String encryptedPassword = "lwropOKPZ3oX2WwJ1-tsOA==";

        //when
        final String decryptedPassword = EncryptionUtils.decrypt(key, initVector, encryptedPassword);

        //then
        assertEquals(decryptedPassword, password);
    }
}
