package com.elsevier.epic; /**
 * Unit tests for the Utility class only.
 */

import com.elsevier.epic.utility.Utility;
import junit.framework.TestCase;

public class UtilityTests extends TestCase {

   public UtilityTests(String testName) {
      super(testName);
   }

   public void testEscJSON() {
      assertEquals("Hello World", Utility.escJSON("Hello World"));
      assertEquals("Hello\\tWorld\\n", Utility.escJSON("Hello\tWorld\n"));
      assertEquals("Back\\\\Slash", Utility.escJSON("Back\\Slash"));
   }

   public void testReadInt() {
      assertEquals(1024, Utility.readInt("1024"));
      assertEquals(0, Utility.readInt("abcdefg"));
      assertEquals(0, Utility.readInt("-5abc"));
      assertEquals(0, Utility.readInt("-5 abc"));
      assertEquals(0, Utility.readInt("abc 10"));
   }
/*
   public void testParamEncode() {
      assertEquals("%2Fweb%3Cdata%3E%2F%3Fhello%3Dworld%2Bhi", Utility.paramEncode("/web<data>/?hello=world+hi"));
   }
*/
   public void testXmlToString() {

   }
}
