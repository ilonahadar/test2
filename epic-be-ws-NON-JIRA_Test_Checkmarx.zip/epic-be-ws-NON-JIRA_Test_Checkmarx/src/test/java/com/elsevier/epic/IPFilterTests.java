package com.elsevier.epic; /**
 * Unit tests for the IPFilter class only.
 */

import com.elsevier.epic.auth.AuthFilter;
import com.elsevier.epic.auth.AuthIP;
import com.elsevier.epic.core.ServerConfig;
import com.elsevier.epic.exceptions.AppException;
import org.junit.BeforeClass;
import org.junit.Test;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class IPFilterTests {
   @BeforeClass
   public static void beforeClass() {
      // Define the valid IP address range for our tests.
      ServerConfig config = new ServerConfig();
      config.setAllowedIPs(new ArrayList<>(Arrays.asList("127.0.0.1", "198.185.16.0 - 198.185.25.255")));
      AuthFilter.addAuthClient(config, new AuthIP());
   }

   // Tests to ensure that validateIPList() is capable of detecting good and bad filter definitions.

   @Test
   public void testGoodIPFilter() {
      List<String> goodFilters = new ArrayList<>();
      goodFilters.add("198.185.16.0 - 198.185.25.255");
      goodFilters.add("18.185.16.210-31.100.0.0");
      goodFilters.add("127.0.0.1");
      AuthIP.validateIPList(goodFilters);
   }

   @Test(expected=AppException.class)
   public void testBadIPFilter1() {
      AuthIP.validateIPList(new ArrayList<>(Arrays.asList("abcdefg")));
   }

   @Test(expected=AppException.class)
   public void testBadIPFilter2() {
      AuthIP.validateIPList(new ArrayList<>(Arrays.asList("256.0.0.1")));
   }

   @Test(expected=AppException.class)
   public void testBadIPFilter3() {
      AuthIP.validateIPList(new ArrayList<>(Arrays.asList("1.2.3")));
   }

   @Test(expected=AppException.class)
   public void testBadIPFilter4() {
      AuthIP.validateIPList(new ArrayList<>(Arrays.asList("11.22.33.g")));
   }

   @Test(expected=AppException.class)
   public void testBadIPFilter5() {
      AuthIP.validateIPList(new ArrayList<>(Arrays.asList("11.22.33.44g")));
   }

   @Test(expected=AppException.class)
   public void testBadIPFilter6() {
      AuthIP.validateIPList(new ArrayList<>(Arrays.asList("xx11.22.33.44")));
   }

   @Test(expected=AppException.class)
   public void testBadIPFilter7() {
      AuthIP.validateIPList(new ArrayList<>(Arrays.asList("55")));
   }

   @Test(expected=AppException.class)
   public void testBadIPFilter8() {
      AuthIP.validateIPList(new ArrayList<>(Arrays.asList("")));
   }

   // IP addresses outside of the ranges.

   @Test
   public void testBadIP1() throws UnknownHostException {
      assertFalse(AuthIP.validIP(InetAddress.getByName("google.com")));
   }

   @Test
   public void testBadIP2() throws UnknownHostException {
      assertFalse(AuthIP.validIP(InetAddress.getByName("198.180.0.1")));
   }

   @Test
   public void testBadIP3() throws UnknownHostException {
      assertFalse(AuthIP.validIP(InetAddress.getByName("127.0.0.2")));
   }

   @Test
   public void testBadIP4() throws UnknownHostException {
      assertFalse(AuthIP.validIP(InetAddress.getByName("201.30.45.12")));
   }

   // IP addresses that fit within the ranges.

   @Test
   public void testGoodIP1() throws UnknownHostException {
      assertTrue(AuthIP.validIP(InetAddress.getByName("127.0.0.1")));
   }

   @Test
   public void testGoodIP2() throws UnknownHostException {
      assertTrue(AuthIP.validIP(InetAddress.getByName("198.185.16.0")));
   }

   @Test
   public void testGoodIP3() throws UnknownHostException {
      assertTrue(AuthIP.validIP(InetAddress.getByName("198.185.16.1")));
   }

   @Test
   public void testGoodIP4() throws UnknownHostException {
      assertTrue(AuthIP.validIP(InetAddress.getByName("198.185.25.255")));
   }
}
