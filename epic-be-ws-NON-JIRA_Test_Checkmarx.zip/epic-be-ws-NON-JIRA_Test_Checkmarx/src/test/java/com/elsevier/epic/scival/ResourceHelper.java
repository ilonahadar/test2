package com.elsevier.epic.scival;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;

/**
 * Created by greend on 14/04/2016.
 */
public class ResourceHelper {
    public static String fromResourceInClasspath(String path) throws IOException {
        return FileUtils.readFileToString(new File(ResourceHelper.class.getClassLoader().getResource(path).getPath()));
    }
}
