package com.elsevier.epic;

import com.elsevier.epic.scival.ScivalEntityURI;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

public class ScivalEntityURITest {

    @Test
    public void canExtractInstitutionId() {
        ScivalEntityURI scivalEntityURI = new ScivalEntityURI("Institution/508076");
        assertThat(scivalEntityURI.getInstitutionId()).isEqualTo(508076);
    }
}