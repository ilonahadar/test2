package com.elsevier.epic;

import com.elsevier.epic.scival.ScivalEntityMetricJsonParser;
import com.elsevier.epic.scival.ResourceHelper;
import com.google.gson.*;
import org.apache.commons.io.FileUtils;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by greend on 14/04/2016.
 */
public class ScivalEntityMetricJsonParserTest {

    public static final String ENTITY_URI = "entityURI";
    public static final String CO_AUTHORED_PUBLICATIONS = "coAuthoredPublications";
    public static final String CO_AUTH_PUB_GROWTH = "coAuthPubGrowth";
    public static final String WEIGHTED_IMPACT = "weightedImpact";

    @Test
    public void canParseValidItem() throws IOException {
        ScivalEntityMetricJsonParser parser = new ScivalEntityMetricJsonParser(parse("com/elsevier/epic/scival/valid-collab-entity-metrics-item.json"));
        assertThat(parser.getCoAuthoredFWCI()).isEqualTo(3.617846141434314f);
        assertThat(parser.getCoAuthoredGrowthPercent()).isEqualTo(-13.72549019607843f);
        assertThat(parser.getCoAuthoredPublications()).isEqualTo(137);
        assertThat(parser.getInstitutionId()).isEqualTo(310011);
    }

    @Test
    public void willParseIfMinimalFieldsArePresent() throws IOException {
        new ScivalEntityMetricJsonParser(createJsonWithRequiredFields());
    }

    private JsonObject createJsonWithRequiredFields() {
        JsonObject object = new JsonObject();
        object.add(ENTITY_URI, new JsonPrimitive("Institution/310011"));
        object.add(CO_AUTHORED_PUBLICATIONS, new JsonPrimitive(137));
        object.add(CO_AUTH_PUB_GROWTH, new JsonPrimitive(-13.72549019607843));
        object.add(WEIGHTED_IMPACT, new JsonPrimitive(3.617846141434314));
        return object;
    }

    @Test(expected = JsonSyntaxException.class)
    public void willThrowExceptionIfEntityUriMissing() {
        JsonObject object = createJsonWithRequiredFields();
        object.remove(ENTITY_URI);
        new ScivalEntityMetricJsonParser(object);
    }

    @Test(expected = JsonSyntaxException.class)
    public void willThrowExceptionIfCoAuthoredPublicationsMissing() {
        JsonObject object = createJsonWithRequiredFields();
        object.remove(CO_AUTHORED_PUBLICATIONS);
        new ScivalEntityMetricJsonParser(object);
    }

    @Test(expected = JsonSyntaxException.class)
    public void willThrowExceptionIfCoAuthoredPublicationGrowthMissing() {
        JsonObject object = createJsonWithRequiredFields();
        object.remove(CO_AUTH_PUB_GROWTH);
        new ScivalEntityMetricJsonParser(object);
    }

    @Test(expected = JsonSyntaxException.class)
    public void willThrowExceptionIfWeightedImpactMissing() {
        JsonObject object = createJsonWithRequiredFields();
        object.remove(WEIGHTED_IMPACT);
        new ScivalEntityMetricJsonParser(object);
    }

    private JsonElement parse(String path) throws IOException {
        return new JsonParser().parse(ResourceHelper.fromResourceInClasspath(path));
    }
}