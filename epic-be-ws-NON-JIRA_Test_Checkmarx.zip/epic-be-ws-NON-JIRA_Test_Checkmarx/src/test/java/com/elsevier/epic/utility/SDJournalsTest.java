package com.elsevier.epic.utility;

import com.elsevier.epic.postgres.PostgresClient;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class SDJournalsTest {

    @Mock
    private Connection connection;

    @Mock
    private PreparedStatement preparedStatement;

    @Mock
    private ResultSet resultSet;

    @Mock
    private PostgresClient postgresClient;

    @Test
    public void shouldReturnJournalFamilies() throws SQLException {
        SDJournals sdJournals = new SDJournals(postgresClient);

        when(postgresClient.getConnectionPool()).thenReturn(connection);
        when(connection.prepareStatement(anyString())).thenReturn(preparedStatement);
        when(preparedStatement.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("Cell Press").thenReturn("");

        sdJournals.loadFamilies();
        final ArrayList<String> actualJournalFamilies = sdJournals.allJournalFamilies();

        assertEquals("Cell Press", actualJournalFamilies.get(0));
    }
}
