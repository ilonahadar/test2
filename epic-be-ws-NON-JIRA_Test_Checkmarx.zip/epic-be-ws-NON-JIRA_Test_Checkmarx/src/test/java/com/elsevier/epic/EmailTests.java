package com.elsevier.epic; /**
 * Tests for the Email and EmailServer classes.
 */

import com.elsevier.epic.core.CoreServer;
import com.elsevier.epic.email.EmailMessage;
import com.elsevier.epic.email.EmailServer;
import junit.framework.TestCase;
import org.junit.Test;

public class EmailTests extends TestCase {
   public EmailTests(String testName) {
      super(testName);
   }

   @Test
   public void testEmailServer() {
      EmailServer server = new EmailServer("server", 80, "admin@elsevier.com", "login", "password", "TLS");
   }

   @Test
   public void testValidAddress() {
      assertEquals(EmailServer.validAddress("someone@elsevier.com"), true);
      assertEquals(EmailServer.validAddress("not\0valid@elsevier.com"), false);
      assertEquals(EmailServer.validAddress("plaintext"), false);
   }

   // This one needs to be run as an integration test.

   @Test
   public void testSendMessage() {
      if (CoreServer.emailServer != null) {
         EmailMessage msg = new EmailMessage();
         msg.subject = "Web server email test";
         msg.content = "This is a test message from the web service JUnit tests.";
         CoreServer.emailServer.sendMessage(msg);
      }
      else System.out.println("Unable to run testSendMessage() because the server is not running.");
   }
}
