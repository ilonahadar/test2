package com.elsevier.epic;

import com.elsevier.epic.exceptions.AppException;
import org.junit.Test;

public class AppExceptionTests {

   @Test(expected = AppException.class)
   public void testAppException1() {
      throw new AppException("Test");
   }

   @Test(expected = AppException.class)
   public void testAppException2() {
      throw new AppException("Test", new Exception("Hello"));
   }

   @Test(expected = AppException.class)
   public void testAppException3() {
      throw new AppException(new Exception("Hello"));
   }
}
