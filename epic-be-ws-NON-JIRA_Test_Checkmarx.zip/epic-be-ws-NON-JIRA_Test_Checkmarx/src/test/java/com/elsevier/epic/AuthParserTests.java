package com.elsevier.epic; /**
 * Unit tests for the AuthParser class only.
 */

import junit.framework.TestCase;
import org.junit.Test;

import java.util.Map;

import static com.elsevier.epic.auth.AuthParser.parseDigest;

public class AuthParserTests extends TestCase {

   public AuthParserTests(String testName) {
      super(testName);
   }

   @Test
   public void testAuth1() {
      String msg = "Digest\n"
      + "                 realm=\"testrealm@host.com\",\n"
      + "                 qop=\"auth,auth-int\",\n"
      + "                 nonce=\"dcd98b7102dd2f0e8b11d0f600bfb0c093\",\n"
      + "                 opaque=\"5ccc069c403ebaf9f0171e9517f40e41\"";

      Map<String, String> map = parseDigest(msg);

      assertEquals(map.get("realm"), "testrealm@host.com");
      assertEquals(map.get("qop"), "auth,auth-int");
      assertEquals(map.get("nonce"), "dcd98b7102dd2f0e8b11d0f600bfb0c093");
      assertEquals(map.get("opaque"), "5ccc069c403ebaf9f0171e9517f40e41");
   }

   @Test
   public void testAuth2() {
      String msg = "Digest username=\"Mufasa\",\n"
      + "                 realm=\"testrealm@host.com\",\n"
      + "                 nonce=\"dcd98b7102dd2f0e8b11d0f600bfb0c093\",\n"
      + "                 uri=\"/dir/index.html\",\n"
      + "                 qop=auth,\n"
      + "                 nc=00000001,\n"
      + "                 cnonce=\"0a4f113b\",\n"
      + "                 response=\"6629fae49393a05397450978507c4ef1\",\n"
      + "                 opaque=\"5ccc069c403ebaf9f0171e9517f40e41\"";

      Map<String, String> map = parseDigest(msg);

      assertEquals(map.get("realm"), "testrealm@host.com");
      assertEquals(map.get("qop"), "auth");
      assertEquals(map.get("nc"), "00000001");
      assertEquals(map.get("opaque"), "5ccc069c403ebaf9f0171e9517f40e41");
   }
}
