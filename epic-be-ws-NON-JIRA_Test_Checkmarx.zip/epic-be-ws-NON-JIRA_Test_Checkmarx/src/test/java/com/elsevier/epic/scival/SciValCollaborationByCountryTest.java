package com.elsevier.epic.scival;

import com.elsevier.epic.core.ErrorResponse;
import com.elsevier.epic.scival.collaboration.*;
import com.elsevier.epic.scival.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.junit.*;

import javax.ws.rs.core.Response;
import java.io.IOException;
import java.net.URL;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Ignore
public class SciValCollaborationByCountryTest {

    private static final int ISO_NUM_DENMARK = 208;
    private static final int ACCOUNT_ID = 121;
    private static final int SCIVAL_INSTITUTION_ID = 58000;
    private static final String UNIVERSITY_OF_COPENHAGEN = "University of Copenhagen";
    private static final String AARHUS_UNIVERSITY = "Aarhus University";
    private static final String TECHNICAL_UNIVERSITY_OF_DENMARK = "Technical University of Denmark";
    private static final String DENMARK = "Denmark";
    public static final int UNIVERSITY_OF_COPENHAGEN_SCIVAL_ID = 310011;
    public static final int AARHUS_UNIVERSITY_SCIVAL_ID = 310010;
    public static final int TECHNICAL_UNIVERSITY_OF_DENMARK_SCIVAL_ID = 310009;
    public static final int SYDDANSK_UNIVERSITET_SCIVAL_ID = 310008;
    public static final String SYDDANSK_UNIVERSITET = "Syddansk Universitet";

    private final SciValCollaborationByCountry.CurrentYear currentYear = mock(SciValCollaborationByCountry.CurrentYear.class);
    private final CountryNameLookup countryNameLookup = mock(CountryNameLookup.class);
    private final AccountLookup accountLookup = mock(AccountLookup.class);
    private ScivalCollaboratingEntityEndpoint mockScivalCollaborationMetricEndpoint = mock(ScivalCollaboratingEntityEndpoint.class);
    private ScivalFieldWeightCitImpactEndpoint mockScivalFieldWeightCitImpactEndpoint = mock(ScivalFieldWeightCitImpactEndpoint.class);
    private SciValCollaborationByCountry.Account account = mock(SciValCollaborationByCountry.Account.class);
    private SciValCollaborationByCountry.Country denmark = mock(SciValCollaborationByCountry.Country.class);
    private SciValCollaborationByCountry.StartAndEndYear startAndEndYear = mock(SciValCollaborationByCountry.StartAndEndYear.class);
    private SciValCollaborationByCountry sciValCollaborationByCountry;
    private String scivalCollaborationResponse;
    private String fwciLeedsUniResponse;
    private String fwciUniOfCopenhagenResponse;
    private URL scivalUrl;

    @Before
    public void setUp() throws IOException, UnknownAccountException, UnknownCountryException {
        SVInstitute.generateCache(false, true);

        scivalCollaborationResponse = ResourceHelper.fromResourceInClasspath("com/elsevier/epic/scival/scival-api-collaboration-leeds-university.json");
        fwciLeedsUniResponse = ResourceHelper.fromResourceInClasspath("com/elsevier/epic/scival/fwci-leeds-uni.json");
        fwciUniOfCopenhagenResponse = ResourceHelper.fromResourceInClasspath("com/elsevier/epic/scival/fwci-uni-of-copenhagen.json");

        sciValCollaborationByCountry = new SciValCollaborationByCountry(mockScivalCollaborationMetricEndpoint, mockScivalFieldWeightCitImpactEndpoint, countryNameLookup, accountLookup, currentYear);

        when(SVInstitute.getSVInstitute(UNIVERSITY_OF_COPENHAGEN_SCIVAL_ID).name).thenReturn(UNIVERSITY_OF_COPENHAGEN);
        when(SVInstitute.getSVInstitute(AARHUS_UNIVERSITY_SCIVAL_ID).name).thenReturn(AARHUS_UNIVERSITY);
        when(SVInstitute.getSVInstitute(TECHNICAL_UNIVERSITY_OF_DENMARK_SCIVAL_ID).name).thenReturn(TECHNICAL_UNIVERSITY_OF_DENMARK);
        when(countryNameLookup.getCountryName(ISO_NUM_DENMARK)).thenReturn(DENMARK);
        when(currentYear.getCurrentYear()).thenReturn(2016);
        when(accountLookup.getScivalInstitutionId(ACCOUNT_ID)).thenReturn(SCIVAL_INSTITUTION_ID);
        when(account.getAccountId()).thenReturn(ACCOUNT_ID);
        when(denmark.getCountryISONumber()).thenReturn(ISO_NUM_DENMARK);
        scivalUrl = new URL("http://www.google.com");
    }

    @Test
    public void whenCountryCodeDoesNotResolveToACountryNameThenWeReturnBadRequest() throws UnknownCountryException {
        setMocksForDateRange(2012, 2013);
        int countryISONum = 131;
        when(countryNameLookup.getCountryName(countryISONum)).thenThrow(new UnknownCountryException(countryISONum));
        SciValCollaborationByCountry.Country country = mock(SciValCollaborationByCountry.Country.class);
        when(country.getCountryISONumber()).thenReturn(countryISONum);

        Response response = sciValCollaborationByCountry.query(account, country, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.BAD_REQUEST.getStatusCode());
        assertThat(((ErrorResponse)response.getEntity()).getMessage()).contains(String.valueOf(countryISONum));
    }


    @Test
    public void whenScivalCollaborationEndpointReturnsJsonWeDoNotRecogniseWeReturnInternalServerError() {
        when(startAndEndYear.getStartYear()).thenReturn(String.valueOf(2012));
        when(startAndEndYear.getEndYear()).thenReturn(String.valueOf(2014));

        when(mockScivalCollaborationMetricEndpoint.call(SCIVAL_INSTITUTION_ID, ISO_NUM_DENMARK, 2012, 2014)).thenReturn(ScivalCallResponse.success("{}"));
        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
    }

    @Test
    public void whenScivalFWCIEndpointReturnsJsonWeDoNotRecogniseWeReturnInternalServerError() {
        when(startAndEndYear.getStartYear()).thenReturn(String.valueOf(2012));
        when(startAndEndYear.getEndYear()).thenReturn(String.valueOf(2014));
        when(mockScivalCollaborationMetricEndpoint.call(SCIVAL_INSTITUTION_ID, ISO_NUM_DENMARK, 2012, 2014)).thenReturn(ScivalCallResponse.success(scivalCollaborationResponse));
        when(mockScivalFieldWeightCitImpactEndpoint.call(SCIVAL_INSTITUTION_ID, 2012, 2014)).thenReturn(ScivalCallResponse.success("{}"));

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
    }

    @Test
    public void whenExceptionOccursDuringCountryNameLookupWeReturnInternalServerError() throws UnknownAccountException, UnknownCountryException {
        setMocksForDateRange(2012, 2014);
        when(countryNameLookup.getCountryName(ISO_NUM_DENMARK)).thenThrow(new RuntimeException("He's a villain George!"));
        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
    }

    @Test
    public void whenExceptionOccursDuringAccountLookupWeReturnInternalServerError() throws UnknownAccountException {
        setMocksForDateRange(2012, 2014);
        when(accountLookup.getScivalInstitutionId(ACCOUNT_ID)).thenThrow(new RuntimeException("sorry govnor"));
        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
    }

    @Test
    public void whenScivalReturnsBadJsonWeReturnInternalServerError() {
        when(startAndEndYear.getStartYear()).thenReturn(String.valueOf(2012));
        when(startAndEndYear.getEndYear()).thenReturn(String.valueOf(2014));

        when(mockScivalCollaborationMetricEndpoint.call(SCIVAL_INSTITUTION_ID, ISO_NUM_DENMARK, 2012, 2014)).thenReturn(ScivalCallResponse.success("not valid json"));

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
    }

    @Test
    public void whenScivalCollaborationCallFailsWeReturnHttp500Error() {
        setMocksForDateRange(2015, 2016);
        when(mockScivalCollaborationMetricEndpoint.call(SCIVAL_INSTITUTION_ID, ISO_NUM_DENMARK, 2015, 2016)).thenReturn(ScivalCallResponse.failure(scivalUrl, new RuntimeException("scival failed")));

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
    }

    @Test
    public void whenScivalFwciForInstitutionCallFailsWeReturnHttp500Error() {
        setMocksForDateRange(2015, 2016);
        when(mockScivalFieldWeightCitImpactEndpoint.call(SCIVAL_INSTITUTION_ID, 2015, 2016)).thenReturn(ScivalCallResponse.failure(scivalUrl, new RuntimeException("scival failed")));

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
    }

    @Test
    public void whenScivalFwciForOtherInstituionCallFailsWeReturnHttp500Error() {
        setMocksForDateRange(2015, 2016);

        // this institution fwci call succeeds
        when(mockScivalCollaborationMetricEndpoint.call(SCIVAL_INSTITUTION_ID, ISO_NUM_DENMARK, 2015, 2016)).thenReturn(ScivalCallResponse.success(scivalCollaborationResponse));

        // but assciated institution call fails
        when(mockScivalFieldWeightCitImpactEndpoint.call(UNIVERSITY_OF_COPENHAGEN_SCIVAL_ID, 2015, 2016)).thenReturn(ScivalCallResponse.failure(scivalUrl, new RuntimeException("scival failed")));

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
    }

    @Test
    public void whenInstitutionHasNoCollaboratorsWeReturnEmmptyResultsArrayInJson() throws IOException {
        setMocksForDateRange(2015, 2016);

        when(mockScivalCollaborationMetricEndpoint.call(SCIVAL_INSTITUTION_ID, ISO_NUM_DENMARK, 2015, 2016)).thenReturn(ScivalCallResponse.success("{ \"collabEntityMetrics\": [] }"));

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.OK.getStatusCode());

        JsonObject responseRootObject = new JsonParser().parse(response.getEntity().toString()).getAsJsonObject();
        JsonArray resultsArray = responseRootObject.get("results").getAsJsonArray();
        assertThat(resultsArray.size()).isEqualTo(0);
    }

    @Test
    public void whenInstitutionHasLessThanThreeCollaboratorsWeShowOnlyThose() throws IOException {
        setMocksForDateRange(2015, 2016);

        when(mockScivalCollaborationMetricEndpoint.call(SCIVAL_INSTITUTION_ID, ISO_NUM_DENMARK, 2015, 2016)).thenReturn(ScivalCallResponse.success(ResourceHelper.fromResourceInClasspath("com/elsevier/epic/scival/scival-api-collaboration-single-collaborator.json")));

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.OK.getStatusCode());

        JsonObject responseRootObject = new JsonParser().parse(response.getEntity().toString()).getAsJsonObject();
        JsonArray resultsArray = responseRootObject.get("results").getAsJsonArray();
        assertThat(resultsArray.size()).isEqualTo(1);
    }

    @Test
    public void weIgnoreInstitutionsForWhichNameLookupThrowsException() {
        setMocksForDateRange(2015, 2016);

        when(SVInstitute.getSVInstitute(UNIVERSITY_OF_COPENHAGEN_SCIVAL_ID).name).thenThrow(new RuntimeException("some chaos or other"));
        when(SVInstitute.getSVInstitute(SYDDANSK_UNIVERSITET_SCIVAL_ID).name).thenReturn(SYDDANSK_UNIVERSITET);
        when(mockScivalFieldWeightCitImpactEndpoint.call(SYDDANSK_UNIVERSITET_SCIVAL_ID, 2015, 2016)).thenReturn(ScivalCallResponse.success(fwciLeedsUniResponse));

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);

        JsonObject responseRootObject = new JsonParser().parse(response.getEntity().toString()).getAsJsonObject();
        JsonArray resultsArray = responseRootObject.get("results").getAsJsonArray();
        assertThat(resultsArray.size()).isEqualTo(3);

        JsonObject item2 = resultsArray.get(2).getAsJsonObject();
        assertThat(item2.get("institutionName").getAsString()).isEqualTo(SYDDANSK_UNIVERSITET);
    }

    @Test
    public void weIgnoreInstitutionsForWhichWeHaveNoNameInOurDatabase() {
        setMocksForDateRange(2015, 2016);

        when(SVInstitute.getSVInstitute(SYDDANSK_UNIVERSITET_SCIVAL_ID).name).thenReturn(SYDDANSK_UNIVERSITET);
        when(mockScivalFieldWeightCitImpactEndpoint.call(SYDDANSK_UNIVERSITET_SCIVAL_ID, 2015, 2016)).thenReturn(ScivalCallResponse.success(fwciLeedsUniResponse));

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);

        JsonObject responseRootObject = new JsonParser().parse(response.getEntity().toString()).getAsJsonObject();
        JsonArray resultsArray = responseRootObject.get("results").getAsJsonArray();
        assertThat(resultsArray.size()).isEqualTo(3);

        JsonObject item2 = resultsArray.get(2).getAsJsonObject();
        assertThat(item2.get("institutionName").getAsString()).isEqualTo(SYDDANSK_UNIVERSITET);
    }

    @Test
    public void whenSpecifiedAccountDoesNotExistReturns404() throws UnknownAccountException {
        setMocksForDateRange(2015, 2016);

        when(accountLookup.getScivalInstitutionId(ACCOUNT_ID)).thenThrow(new UnknownAccountException(ACCOUNT_ID));

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);

        assertThat(response.getStatus()).isEqualTo(Response.Status.NOT_FOUND.getStatusCode());
        assertThat(((ErrorResponse)response.getEntity()).getMessage()).contains(String.valueOf(ACCOUNT_ID));
    }

    @Test
    public void onlyReturnsTopThreeInstitutions() {
        setMocksForDateRange(2014, 2016);

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);

        JsonObject responseRootObject = new JsonParser().parse(response.getEntity().toString()).getAsJsonObject();

        assertThat(responseRootObject.get("countryName").getAsString()).isEqualTo(DENMARK);
        assertThat(responseRootObject.get("FWCI").getAsFloat()).isEqualTo(1.3223147f);

        JsonArray resultsArray = responseRootObject.get("results").getAsJsonArray();
        assertThat(resultsArray.size()).isEqualTo(3);

        JsonObject item0 = resultsArray.get(0).getAsJsonObject();
        assertThat(item0.get("institutionName").getAsString()).isEqualTo(UNIVERSITY_OF_COPENHAGEN);
        assertThat(item0.get("coAuthPub").getAsInt()).isEqualTo(137);
        assertThat(item0.get("coAuthGrowth").getAsFloat()).isEqualTo(-13.72549019607843f);
        assertThat(item0.get("coAuthFWCI").getAsFloat()).isEqualTo(3.617846141434314f);
        assertThat(item0.get("institutionFWCI").getAsFloat()).isEqualTo(2.762345554f);

        JsonObject item1 = resultsArray.get(1).getAsJsonObject();
        assertThat(item1.get("institutionName").getAsString()).isEqualTo(AARHUS_UNIVERSITY);
        assertThat(item1.get("coAuthPub").getAsInt()).isEqualTo(51);

        JsonObject item2 = resultsArray.get(2).getAsJsonObject();
        assertThat(item2.get("institutionName").getAsString()).isEqualTo(TECHNICAL_UNIVERSITY_OF_DENMARK);
        assertThat(item2.get("coAuthPub").getAsInt()).isEqualTo(22);
    }

    @Test
    public void respondsWithValidJsonInResponseBody() {
        setMocksForDateRange(2015, 2016);

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        String output = response.getEntity().toString();

        org.junit.Assert.assertThat(output, matchesJsonSchemaInClasspath("schemas/collaboration_by_country_schema.json"));
    }

    @Test
    public void goodParametersGiveStatusOk() {
        setMocksForDateRange(2015, 2016);

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.OK.getStatusCode());
    }

    @Test
    public void missingStartYearCausesBadRequestResponse() {
        when(startAndEndYear.getStartYear()).thenReturn(null);
        when(startAndEndYear.getEndYear()).thenReturn("2001");

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void missingEndYearCausesBadRequestResponse() {
        when(startAndEndYear.getStartYear()).thenReturn("2015");
        when(startAndEndYear.getEndYear()).thenReturn(null);

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void badStartYearCausesBadRequestResponse() {
        when(startAndEndYear.getStartYear()).thenReturn("not-a-year");
        when(startAndEndYear.getEndYear()).thenReturn("2001");

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void badEndYearCausesBadRequestResponse() {
        when(startAndEndYear.getStartYear()).thenReturn("2015");
        when(startAndEndYear.getEndYear()).thenReturn("not-a-year");

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void startAfterEndDatesCausesBadRequestResponse() {
        when(startAndEndYear.getStartYear()).thenReturn("2015");
        when(startAndEndYear.getEndYear()).thenReturn("2014");

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void startBefore1996BadRequestResponse() {
        when(startAndEndYear.getStartYear()).thenReturn("1995");
        when(startAndEndYear.getEndYear()).thenReturn("2014");

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void endBefore1996BadRequestResponse() {
        when(startAndEndYear.getStartYear()).thenReturn("1995");
        when(startAndEndYear.getEndYear()).thenReturn("1995");

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void startYearInTheFutureBadRequestResponse() {
        when(startAndEndYear.getStartYear()).thenReturn("2020");
        when(startAndEndYear.getEndYear()).thenReturn("2021");

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void endYearInTheFutureBadRequestResponse() {
        when(startAndEndYear.getStartYear()).thenReturn("2015");
        when(startAndEndYear.getEndYear()).thenReturn("2017");

        Response response = sciValCollaborationByCountry.query(account, denmark, startAndEndYear);
        assertThat(response.getStatus()).isEqualTo(Response.Status.BAD_REQUEST.getStatusCode());
    }

    private void setMocksForDateRange(int startYear, int endYear) {
        when(mockScivalCollaborationMetricEndpoint.call(SCIVAL_INSTITUTION_ID, ISO_NUM_DENMARK, startYear, endYear)).thenReturn(ScivalCallResponse.success(scivalCollaborationResponse));
        when(mockScivalFieldWeightCitImpactEndpoint.call(SCIVAL_INSTITUTION_ID, startYear, endYear)).thenReturn(ScivalCallResponse.success(fwciLeedsUniResponse));
        when(mockScivalFieldWeightCitImpactEndpoint.call(UNIVERSITY_OF_COPENHAGEN_SCIVAL_ID, startYear, endYear)).thenReturn(ScivalCallResponse.success(fwciUniOfCopenhagenResponse));
        when(mockScivalFieldWeightCitImpactEndpoint.call(AARHUS_UNIVERSITY_SCIVAL_ID, startYear, endYear)).thenReturn(ScivalCallResponse.success(fwciLeedsUniResponse));
        when(mockScivalFieldWeightCitImpactEndpoint.call(TECHNICAL_UNIVERSITY_OF_DENMARK_SCIVAL_ID, startYear, endYear)).thenReturn(ScivalCallResponse.success(fwciLeedsUniResponse));
        when(startAndEndYear.getStartYear()).thenReturn(String.valueOf(startYear));
        when(startAndEndYear.getEndYear()).thenReturn(String.valueOf(endYear));
    }

}
