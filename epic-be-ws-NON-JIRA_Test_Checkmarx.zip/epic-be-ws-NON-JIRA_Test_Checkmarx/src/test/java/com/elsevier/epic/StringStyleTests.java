package com.elsevier.epic; /**
 * Tests for the StringStyle class
 */

import com.elsevier.epic.core.StringStyle;
import junit.framework.TestCase;

public class StringStyleTests extends TestCase {
   public StringStyleTests(String testName) {
      super(testName);
   }

   public void testCamelCase() {
      assertEquals("aB",   StringStyle.lowCamelCase("A B"));
      assertEquals("abc",  StringStyle.lowCamelCase("ABC"));
      assertEquals("-123", StringStyle.lowCamelCase("-123"));
      assertEquals("helloWorld", StringStyle.lowCamelCase("Hello_World"));
      assertEquals("thequickBrownFoxJumped0ver", StringStyle.lowCamelCase("theQuick\tbrown Fox   JUMPED 0ver"));
   }
}
