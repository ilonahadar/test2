package com.elsevier.epic;

import com.elsevier.epic.scival.SciVal;
import org.junit.Test;
import static org.junit.Assert.*;

public class SciValTests {

   @Test
   public void testSVHash1() {
      String user = "epic";
      String password = "E90CE987-64D9-4AC2-85F8-E16A6FD1FD55";
      String hash = SciVal.genSVHash("https://cert-api.nonprod.scival.com/api/Institution", "2015-12-03T17:30:37.927-0000", user, password);
      assertEquals("epic:n27uzzHi+BvZGpzsUWUfj4PtkkhUm1590LDcvxoQnfg=", hash);
   }

   @Test
   public void testSVHash2() {
      String user = "epic";
      String password = "E90CE987-64D9-4AC2-85F8-E16A6FD1FD55";
      String hash = SciVal.genSVHash("https://cert-api.nonprod.scival.com/api/CollaborationMetric/CollabByLocation?entities=Institution%2F508179&years=2012-2014&level=Country", "2015-12-04T11:31:14.366-0000", user, password);
      assertEquals("epic:KPWXrET8TKc5Tmt/EHiZIkulOov7+LSxm/pp83HDUdE=", hash);
   }

}
