package com.elsevier.epic.validation;


import org.junit.jupiter.api.Test;

import javax.ws.rs.WebApplicationException;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.*;

class SQLValidatorTest {

    @Test
    void shouldThrowExceptionWhenBlackListedDropWordFound() {
        final SQLValidator sqlValidator = new SQLValidator();
        assertThatThrownBy(() -> sqlValidator.validate("select * from;drop table"))
                .isInstanceOf(WebApplicationException.class);
    }

    @Test
    void shouldThrowExceptionWhenBlackListedDeleteWordFound() {
        final SQLValidator sqlValidator = new SQLValidator();
        assertThatThrownBy(() -> sqlValidator.validate("select * from;delete from table"))
                .isInstanceOf(WebApplicationException.class);
    }

    @Test
    void shouldThrowExceptionWhenBlackListedAlterWordFound() {
        final SQLValidator sqlValidator = new SQLValidator();
        assertThatThrownBy(() -> sqlValidator.validate("alter table"))
                .isInstanceOf(WebApplicationException.class);
    }

    @Test
    void shouldNotThrowExceptionWhenInputIsEmptyOrNull() {
        final SQLValidator sqlValidator = new SQLValidator();
        assertDoesNotThrow(() -> sqlValidator.validate(""));
        final String val = null;
        assertDoesNotThrow(() -> sqlValidator.validate(val));
    }

    @Test
    void shouldNotThrowExceptionWhenInputIsValid() {
        final SQLValidator sqlValidator = new SQLValidator();
        assertDoesNotThrow(() -> sqlValidator.validate("title"));
    }

    @Test
    void shouldThrowExceptionWhenMultipleStringAreInvalid() {
        final SQLValidator sqlValidator = new SQLValidator();
        assertThatThrownBy(() -> sqlValidator.validate("sort", "title", "drop;"))
                .isInstanceOf(WebApplicationException.class);
    }

    @Test
    void shouldReturnMapWhenIsValid() {
        final SQLValidator sqlValidator = new SQLValidator();
        final Map<String, String[]> map = new HashMap<>();
        map.put("period", new String[]{"12"});
        map.put("sort", new String[]{"1"});
        assertEquals(map, sqlValidator.validate(map));
    }

    @Test
    void shouldNotThrowExceptionWhenMapIsEmptyOrNull() {
        final SQLValidator sqlValidator = new SQLValidator();
        final Map<String, String[]> map = null;
        assertDoesNotThrow(() -> sqlValidator.validate(new HashMap<>()));
        assertDoesNotThrow(() -> sqlValidator.validate(map));
    }
}
