package com.elsevier.epic;

import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.utility.SDJournals;
import org.junit.Ignore;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
public class JournalFamiliesTest {


    @Mock
    private HttpServletRequest request;

    @Mock
    private ArrayList<IDValue> ids;

    @Mock
    private Map<String, String> map;

    @Mock
    private SDJournals sdJournals;

    private JournalFamilies journalFamiliesClass;

    @Test
    public void shouldReturnJournalFamiliesResponse() {
        //given
        journalFamiliesClass = new JournalFamilies(sdJournals);

        final ArrayList<String> journalFamilies = new ArrayList<>();
        journalFamilies.add("JournalFamily1");
        journalFamilies.add("JournalFamily2");
        journalFamilies.add("JournalFamily3");

        when(sdJournals.allJournalFamilies()).thenReturn(journalFamilies);
        //when
        final Response actualResponse = journalFamiliesClass.query(request, ids, map);

        //then
        assertEquals(Response.Status.OK.getStatusCode(), actualResponse.getStatus());
    }
}
