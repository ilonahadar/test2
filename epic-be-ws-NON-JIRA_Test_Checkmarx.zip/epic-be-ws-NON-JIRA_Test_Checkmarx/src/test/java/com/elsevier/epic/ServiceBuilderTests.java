package com.elsevier.epic; /**
 * Tests for the ServiceBuilder class.
 */

import com.elsevier.epic.core.ServiceBuilder;
import com.elsevier.epic.exceptions.AppException;
import junit.framework.TestCase;
import org.junit.Test;

import javax.xml.bind.util.ValidationEventCollector;

public class ServiceBuilderTests extends TestCase {
   @Test
   public void testRefreshConfiguration() {
      // refreshConfiguration() is tested by calling /api/refresh
   }

   @Test
   public void testPrintXSDFailure() {
      ValidationEventCollector vec = new ValidationEventCollector();
      ServiceBuilder.printXSDFailure(vec, new AppException("Test"));
   }
}
