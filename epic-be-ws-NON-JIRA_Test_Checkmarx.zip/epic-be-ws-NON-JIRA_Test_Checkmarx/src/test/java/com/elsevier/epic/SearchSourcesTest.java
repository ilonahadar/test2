package com.elsevier.epic;

import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.servlet.http.HttpServletRequest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SearchSourcesTest {

    @Mock
    private HttpServletRequest pRequest;

    @Mock
    private PostgresClient postgresClient;

    @Mock
    private Connection connection;

    @Mock
    private ResultSet rst;

    @Mock
    private PreparedStatement ps;

    @Captor
    private ArgumentCaptor<String> captor;

    private SearchSources searchSources;

    @BeforeEach
    void setUp() throws SQLException {
        searchSources = new SearchSources(postgresClient);
        when(postgresClient.getConnectionPool()).thenReturn(connection);
    }

    @Test
    void shouldCallSearchTypeAll() throws SQLException {
        final ArrayList<IDValue> pIDs = new ArrayList<>();
        pIDs.add(new IDValue(null, "all"));
        final Map<String, String> pParameters = new HashMap<>();
        pParameters.put("q", "00247804");
        pParameters.put("limit", "50");
        when(connection.prepareStatement(captor.capture())).thenReturn(ps);
        when(ps.executeQuery()).thenReturn(rst);
        when(rst.next()).thenReturn(true).thenReturn(false);
        searchSources.query(pRequest, pIDs, pParameters);
        assertEquals(
                "SELECT issn, title, publisher, imprint, content_type, type_name, subscribable, elsevier_pub\n" + "FROM vw_journals AS j\n" + "WHERE ((issn ILIKE ?) OR (title ILIKE ?))\n" + "ORDER BY levenshtein(?, title), issn LIMIT ?",
                captor.getValue());
    }

    @Test
    void shouldCallSearchTypeISSN() throws SQLException {
        final ArrayList<IDValue> pIDs = new ArrayList<>();
        pIDs.add(new IDValue(null, "issn"));
        final Map<String, String> pParameters = new HashMap<>();
        pParameters.put("q", "00247804");
        pParameters.put("limit", "50");
        when(connection.prepareStatement(captor.capture())).thenReturn(ps);
        when(ps.executeQuery()).thenReturn(rst);
        when(rst.next()).thenReturn(true).thenReturn(false);
        searchSources.query(pRequest, pIDs, pParameters);
        assertEquals(
                "SELECT issn, title, publisher, imprint, content_type, type_name, subscribable, elsevier_pub\n" + "FROM vw_journals AS j\n" + "WHERE (avail_title) AND (issn ILIKE ?)\n" + "ORDER BY issn LIMIT ?",
                captor.getValue());
    }

    @Test
    void shouldCallSearchTypeTitle() throws SQLException {
        final ArrayList<IDValue> pIDs = new ArrayList<>();
        pIDs.add(new IDValue(null, "title"));
        final Map<String, String> pParameters = new HashMap<>();
        pParameters.put("q", "00247804");
        pParameters.put("limit", "50");
        when(connection.prepareStatement(captor.capture())).thenReturn(ps);
        when(ps.executeQuery()).thenReturn(rst);
        when(rst.next()).thenReturn(true).thenReturn(false);
        searchSources.query(pRequest, pIDs, pParameters);
        assertEquals(
                "SELECT issn, title, publisher, imprint, content_type, type_name, subscribable, elsevier_pub\n" + "FROM vw_journals\n" + "WHERE title ILIKE ?\n" + "ORDER BY levenshtein(?, title), issn LIMIT ?",
                captor.getValue());
    }

}
