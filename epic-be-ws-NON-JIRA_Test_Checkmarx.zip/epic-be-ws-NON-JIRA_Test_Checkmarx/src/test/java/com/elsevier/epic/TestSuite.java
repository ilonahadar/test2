package com.elsevier.epic; /**
 * Use this test suite to run all the tests in one go.  There are two ways to execute the tests, either use
 * Maven by running 'mvn test'; or run the TestSuite's main entry point.
 */

import com.elsevier.epic.core.CoreServer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.RunWith;
import org.junit.runner.notification.Failure;
import org.junit.runners.Suite;

import java.io.IOException;

import static com.jayway.restassured.RestAssured.get;

@RunWith(Suite.class)
@Suite.SuiteClasses({
   AuthParserTests.class,
   AppExceptionTests.class,
   IPFilterTests.class,
   StringStyleTests.class,
   ServiceBuilderTests.class,
   UtilityTests.class,
   EmailTests.class
})

public class TestSuite {
   public static void main(String[] args) {
      Result result = JUnitCore.runClasses(TestSuite.class);

      System.out.println("--- Testing complete ---");

      for (Failure failure : result.getFailures()) {
         System.out.println(failure.toString());
      }
   }

   static private boolean running = false;
   static private boolean serviceRunning() {
      if (running) return running;
      try {
         Response resp = RestAssured.get("/api");
         if (resp.getStatusCode() == 200) {
            System.out.println("The web service is already running.");
            running = true;
         }
      }
      catch (Exception e) { }
      return running;
   }

   public static boolean runWebService(final String requiredService) {
      RestAssured.baseURI = "http://localhost";
      RestAssured.port = 9080;
      RestAssured.basePath = "/" + requiredService + "/v1";

      if (!serviceRunning()) {
         System.out.println("Running web service for the test environment...");

         Runnable r = new Runnable() {
            @Override
            public void run() {
               String[] args = { "server", "data/server-" + requiredService + ".yml" };
               try {
                  new CoreServer().run(args);
               }
               catch (Exception ex) { }
            }
         };

         new Thread(r).start();

         try {
            Thread.sleep(4000);
            return true;
         }
         catch (InterruptedException ex) { }
      }
      else {
         try {
            String serviceName = get("/api/service/name").body().asString();
            ObjectMapper mapper = new ObjectMapper();
            JsonNode jsService = mapper.readTree(serviceName);
            if (jsService.get("serviceName").asText().toLowerCase().equals(requiredService.toLowerCase())) return true;
         }
         catch (IOException e) {  }
      }
      return false;
   }
}