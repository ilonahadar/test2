package com.elsevier.epic.institutions;

import com.elsevier.epic.jaxb.IdType;
import com.elsevier.epic.postgres.PostgresClient;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.utility.FileUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.apache.commons.lang3.RandomUtils.nextInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class InstitutionDataTest {
    @Mock
    private IdType id;

    @Mock
    private HttpServletRequest request;

    @Mock
    private Map<String, String> parameters;

    @Mock
    private PostgresClient postgresClient;

    @Mock
    private Connection connection;

    @Mock
    private FileUtils fileUtils;

    private InstitutionData institutionData;

    @BeforeEach
    void setup(){
        institutionData = new InstitutionData(postgresClient, fileUtils);
    }

    @Test
    void shouldReturnInstitutionDataResponse_no_affiliations_no_metrics() throws IOException, SQLException {
        //given
        final InstitutionDataResponse response = new InstitutionDataResponse();
        final int svId = 1;
        final String svName = "Account";
        final String instName = "Institution";
        final String segment = "Academic";
        final String customerId = "ECR-680";
        final String country = "Italy";
        final String superAccountType = "Child";

        final String[] platformArray = new String[]{"Epic", "Scival"};
        final List<String> platform = Arrays.asList(platformArray);

        final Map<String, String> affiliation = new HashMap<>();
        affiliation.put("id", "6789");
        affiliation.put("name", "University");
        final List<Map<String, String>> affiliations = Collections.singletonList(affiliation);

        final Map<String, String> databaseAffiliations = new HashMap<>();
        databaseAffiliations.put("6789", "University");

        final Map<String, Object> accIdInfo = new HashMap<>();
        accIdInfo.put("acct_number", 12345);
        accIdInfo.put("acct_name", "University of Rome");
        accIdInfo.put("acct_platforms", platform);
        final List<Map<String, Object>> accIdInfos = Collections.singletonList(accIdInfo);

        final Integer[] accountIdArray = new Integer[]{1, 2};
        final List<Integer> accountIds = Arrays.asList(accountIdArray);

        final List<Map<String, String>> metricsDataAvailable = Collections.emptyList();

        response.setSvId(svId);
        response.setSvName(svName);
        response.setInstName(instName);
        response.setSegment(segment);
        response.setCustomerId(customerId);
        response.setCountry(country);
        response.setSuperAccountType(superAccountType);
        response.setAcctIdInfo(accIdInfos);
        response.setAccountId(accountIds);
        response.setPlatform(platform);
        response.setAffiliations(affiliations);
        response.setMetricDataAvailable(metricsDataAvailable);

        final IDValue accountId = new IDValue(id, String.valueOf(nextInt()));
        final ArrayList<IDValue> pIDS = new ArrayList<>();
        pIDS.add(accountId);


        when(postgresClient.getConnectionPool()).thenReturn(connection);

        //institution data
        final String institutionQuery = "institution query";
        final ResultSet accountInfoResultSet = mock(ResultSet.class);
        final PreparedStatement accountInfoPreparedStatement = mock(PreparedStatement.class);
        when(fileUtils.getResourceString("/select_account_info.sql")).thenReturn(institutionQuery);
        when(connection.prepareStatement(institutionQuery)).thenReturn(accountInfoPreparedStatement);
        when(accountInfoPreparedStatement.executeQuery()).thenReturn(accountInfoResultSet);
        when(accountInfoResultSet.next()).thenReturn(true).thenReturn(false);
        when(accountInfoResultSet.getInt(1)).thenReturn(svId);
        when(accountInfoResultSet.getString(10)).thenReturn(svName);
        when(accountInfoResultSet.getString(2)).thenReturn(instName);
        when(accountInfoResultSet.getString(3)).thenReturn(segment);
        when(accountInfoResultSet.getString(4)).thenReturn(customerId);
        when(accountInfoResultSet.getString(5)).thenReturn(country);
        when(accountInfoResultSet.getString(9)).thenReturn(superAccountType);

        final Array accountsSqlArray = mock(Array.class);
        when(accountInfoResultSet.getArray(6)).thenReturn(accountsSqlArray);
        when(accountsSqlArray.getArray()).thenReturn(accountIdArray);

        final Array platformsSqlArray = mock(Array.class);
        when(accountInfoResultSet.getArray(7)).thenReturn(platformsSqlArray);
        when(platformsSqlArray.getArray()).thenReturn(platformArray);
        when(accountInfoResultSet.getObject("affils")).thenReturn(databaseAffiliations);

        //account details data
        final String accountDetailsQuery = "account details query";
        final PreparedStatement accountDetailsPreparedStatement = mock(PreparedStatement.class);
        final ResultSet accountDetailsResultSet = mock(ResultSet.class);
        when(fileUtils.getResourceString("/select_account_detail_info.sql")).thenReturn(accountDetailsQuery);
        when(connection.prepareStatement(accountDetailsQuery)).thenReturn(accountDetailsPreparedStatement);
        when(accountDetailsPreparedStatement.executeQuery()).thenReturn(accountDetailsResultSet);
        when(accountDetailsResultSet.next()).thenReturn(true).thenReturn(false);
        when(accountDetailsResultSet.getInt(1)).thenReturn(12345);
        when(accountDetailsResultSet.getString(2)).thenReturn("University of Rome");
        final Array accountPlatformSqlArray = mock(Array.class);
        when(accountDetailsResultSet.getArray(3)).thenReturn(accountPlatformSqlArray);
        when(accountPlatformSqlArray.getArray()).thenReturn(platformArray);

        //metrics data
        final String metricsDataQuery = "select  * from checkMetricsDataAvailability(?)";
        final PreparedStatement metricsDataPreparedStatement = mock(PreparedStatement.class);
        final ResultSet metricsDataResultSet = mock(ResultSet.class);
        when(connection.prepareStatement(metricsDataQuery)).thenReturn(metricsDataPreparedStatement);
        when(metricsDataPreparedStatement.executeQuery()).thenReturn(metricsDataResultSet);
        when(metricsDataResultSet.next()).thenReturn(false);


        //when
        final Response actualResponse = institutionData.query(request, pIDS, parameters);
        final InstitutionDataResponse responseToAssert = (InstitutionDataResponse) actualResponse.getEntity();

        //then
        assertEquals(Response.Status.OK.getStatusCode(), actualResponse.getStatus());
        assertEquals(response, responseToAssert);
    }
}
