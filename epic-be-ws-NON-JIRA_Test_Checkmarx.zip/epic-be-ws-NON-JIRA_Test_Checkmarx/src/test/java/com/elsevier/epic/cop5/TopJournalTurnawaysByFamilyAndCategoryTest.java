package com.elsevier.epic.cop5;

import com.elsevier.epic.jaxb.IdType;
import com.elsevier.epic.types.IDValue;
import com.elsevier.epic.utility.SDJournals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.skife.jdbi.v2.DBI;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Map;

import static org.apache.commons.lang3.RandomUtils.nextInt;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TopJournalTurnawaysByFamilyAndCategoryTest {

    @Mock
    private DBI dbi;
    @Mock
    private HttpServletRequest request;
    @Mock
    private IdType id;
    @Mock
    private Map<String, String> parameters;
    @Mock
    private SDJournals sdJournals;
    @Mock
    private TopJournalTurnawaysByFamilyAndCategory.Query query;

    private TopJournalTurnawaysByFamilyAndCategory topJournalTurnawaysByFamilyAndCategory;

    @Test
    void shouldReturnJournalsByCategory() {
        //given
        topJournalTurnawaysByFamilyAndCategory = new TopJournalTurnawaysByFamilyAndCategory(dbi, sdJournals);
        final IDValue accountId = new IDValue(id, String.valueOf(nextInt()));
        final IDValue count = new IDValue(id, String.valueOf(nextInt()));
        final IDValue family = new IDValue(id, "All");
        final IDValue category = new IDValue(id, "1100");

        final ArrayList<IDValue> pIDS = new ArrayList<>();
        pIDS.add(accountId);
        pIDS.add(count);
        pIDS.add(family);
        pIDS.add(category);

        when(dbi.onDemand(TopJournalTurnawaysByFamilyAndCategory.Query.class)).thenReturn(query);

        //when
        final Response actualResponse = topJournalTurnawaysByFamilyAndCategory.query(request, pIDS, parameters);

        //then
        assertEquals(Response.Status.OK.getStatusCode(), actualResponse.getStatus());
        verify(query).filterByCategoryCode(anyInt(), anyInt());
    }

    @Test
    void shouldReturnJournalsByFamily() {
        //given
        topJournalTurnawaysByFamilyAndCategory = new TopJournalTurnawaysByFamilyAndCategory(dbi, sdJournals);
        final IDValue accountId = new IDValue(id, String.valueOf(nextInt()));
        final IDValue count = new IDValue(id, String.valueOf(nextInt()));
        final IDValue family = new IDValue(id, "Cell Press");
        final IDValue category = new IDValue(id, "All");

        final ArrayList<IDValue> pIDS = new ArrayList<>();
        pIDS.add(accountId);
        pIDS.add(count);
        pIDS.add(family);
        pIDS.add(category);

        when(dbi.onDemand(TopJournalTurnawaysByFamilyAndCategory.Query.class)).thenReturn(query);

        //when
        final Response actualResponse = topJournalTurnawaysByFamilyAndCategory.query(request, pIDS, parameters);

        //then
        assertEquals(Response.Status.OK.getStatusCode(), actualResponse.getStatus());
        verify(query).filterByJournalFamily(anyInt(), anyString());
    }

    @Test
    void shouldReturnJournalsByFamilyAndCategory() {
        //given
        topJournalTurnawaysByFamilyAndCategory = new TopJournalTurnawaysByFamilyAndCategory(dbi, sdJournals);
        final IDValue accountId = new IDValue(id, String.valueOf(nextInt()));
        final IDValue count = new IDValue(id, String.valueOf(nextInt()));
        final IDValue family = new IDValue(id, "Cell Press");
        final IDValue category = new IDValue(id, "1100");

        final ArrayList<IDValue> pIDS = new ArrayList<>();
        pIDS.add(accountId);
        pIDS.add(count);
        pIDS.add(family);
        pIDS.add(category);

        when(dbi.onDemand(TopJournalTurnawaysByFamilyAndCategory.Query.class)).thenReturn(query);

        //when
        final Response actualResponse = topJournalTurnawaysByFamilyAndCategory.query(request, pIDS, parameters);

        //then
        assertEquals(Response.Status.OK.getStatusCode(), actualResponse.getStatus());
        verify(query).filterByCategoryAndJournalFamily(anyInt(), anyString(), anyInt());
    }
}
