## E-PIC Karate Functional Tests

These are functional tests written using the Karate framework. The tests target various E-PIC endpoints and validate the schemas of the responses returned.

### Test Execution Instructions and Notes

To run the tests through Maven, use the below command.

```
mvn clean '-Dtest=com.elsevier.epic.RunAllTest' test
```

Through an IDE simply run `RunAllTest.java` or any individual `feature` file you would like to test.

The Authorizartion Bearer Token must be added as an environment variable with key `AUTHORIZATION_TOKEN`. The bearer token can be found in secrets manager titled: `epic-test-bearer-token`.

Logging level has been reduced to mask sensitive credentials and reduce console clutter. To increase logging level, uncomment `line 21: <appender-ref ref="STDOUT" />` in `logback-test.xml`.

The environment that the tests run in can be specified using the `'-DargLine="-Dkarate.env="'` flag, like so:

```
mvn clean -DargLine="-Dkarate.env=dev" '-Dtest=com.elsevier.epic.RunAllTest' test
```

The pipeline job for these tests is titled: `epic-be-test-api_karate_PROD`.

These tests are intended to be run on the `prod` environment, use of another environment may return unintended results.
