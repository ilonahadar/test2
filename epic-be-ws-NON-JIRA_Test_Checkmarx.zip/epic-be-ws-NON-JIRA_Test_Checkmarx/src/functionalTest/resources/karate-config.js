function fn() {
  // get system property 'karate.env'. You can use the '-DargLine="-Dkarate.env="' flag to switch environments.
  var env = karate.env;
  // The Bearer token must be added as an environment variable with key 'AUTHORIZATION_TOKEN'. The Bearer token secret can be found on the E-PIC non-prod AWS account titled: 'epic-test-bearer-token'.
  var auth = java.lang.System.getenv('AUTHORIZATION_TOKEN');
  karate.log('karate.env system property was:', env);
  if (!env) {
    env = 'prod';
  }
  var config = {
    env: env,
	baseUrl: 'https://epicws.e-pic.systems',
    authorization: auth,
  }
  if (env == 'prod') {
    config.baseUrl = 'https://epicws.e-pic.systems'
  }
  else if (env == 'prod1') {
      config.baseUrl = 'https://epicws1.e-pic.systems'
  }
  else if (env == 'prod2') {
      config.baseUrl = 'https://epicws2.e-pic.systems'
  }
  else if (env == 'dev') {
    config.baseUrl = 'https://dev-epicws.np.e-pic.systems'
  }
  else if (env == 'rc') {
    config.baseUrl = 'https://epicws-rc.e-pic.systems'
  }
  karate.configure('connectTimeout', 30000);
  karate.configure('readTimeout', 30000);
  return config;
}
