GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE public.login TO api;

insert into login (uid, user_token) values ('TEST', 'TEST');
