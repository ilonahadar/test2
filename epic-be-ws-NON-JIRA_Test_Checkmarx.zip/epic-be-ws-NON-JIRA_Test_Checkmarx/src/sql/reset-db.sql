DROP SCHEMA if exists public CASCADE;
CREATE SCHEMA public;
drop database if exists epicdb;
create database epicdb;

drop role if exists api;
drop extension if exists hstore;

-- Modified version of /Users/greend/work/epic/code/postgres/sql/accounts.sql which won't run natively
CREATE ROLE api WITH NOSUPERUSER NOCREATEDB LOGIN CONNECTION LIMIT -1 PASSWORD '???';
GRANT USAGE ON SCHEMA public TO api;
GRANT CONNECT ON DATABASE epicdb TO api;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO api;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO api;

-- Some fake views so that views.sql doesn't barf when it tries to drop views that dont exist
CREATE VIEW vw_top_articles as select 'hello world';
CREATE VIEW vw_monthly_breakdown as select 'hello world';
CREATE VIEW vw_time_series as select 'hello world';
CREATE VIEW vw_time_series_access as select 'hello world';
CREATE VIEW vw_time_series_pub as select 'hello world';
CREATE VIEW vw_time_series_src as select 'hello world';
