# EPIC Integration Testing
TBC

# EPIC Smoke Testing

This sub-project performs integration testing of the EPIC web server, and must be executed prior to each deployment in the production environment.

The standard command-line to execute integration tests against a locally running web service is:

```
mvn test-compile surefire:test -Dsystem.test.server=localhost -Dsystem.test.port=9080
```

To run the integration tests against a named service that is running on Marathon, please use the following command-line:

```
mvn test-compile surefire:test
   -Dsystem.marathon.server=10.182.2.116
   -Dsystem.marathon.port=8080
   -Dsystem.marathon.service=web-epic
   -Dsystem.test.port=9999
```

## Continuous Integration

NOT CURRENTLY TRUE DUE TO CI CHANGES: In our Jenkins configuration, the integration testing starts by launching a test service via Marathon, using the service name 'test-epic'.  The integration testing is then run, targeting the 'test-epic' service and a SureFire testing report is generated.  If the tests succeed, the service artifacts are uploaded to S3 and the deployment job is then executed to restart the production service with the new build.

## How It Works

The Java code loads PII's from 'src/test/resources/pii-list.txt' and then retrieves article data directly from the targeted server.  Please note that the Articles class performs this process and it contains some important constants - MIN_ARTICLES, MAX_MARTICLES and RANDOM_SAMPLE_SIZE.  These constants control the overall level of coverage in terms of the queried article data.  The recommended values are 50, 100 and 25 respectively.

The body data for each article is stored in memory, then the individual integration tests are run by SureFire if the loading process completes successfully.

## Technology Used

The test framework is based on JUnit and Rest Assured.  You can learn more about Rest Assured here:

    https://code.google.com/p/rest-assured/wiki/Usage

