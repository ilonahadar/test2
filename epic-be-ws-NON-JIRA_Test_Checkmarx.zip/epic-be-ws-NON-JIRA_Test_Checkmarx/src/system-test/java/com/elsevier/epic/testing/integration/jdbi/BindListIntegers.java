package com.elsevier.epic.testing.integration.jdbi;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.sql.Array;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.skife.jdbi.v2.SQLStatement;
import org.skife.jdbi.v2.sqlobject.Binder;
import org.skife.jdbi.v2.sqlobject.BinderFactory;
import org.skife.jdbi.v2.sqlobject.BindingAnnotation;

@BindingAnnotation(BindListIntegers.BindArrayBinderFactory.class)
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.PARAMETER })
public @interface BindListIntegers {
    String value();

    public static class BindArrayBinderFactory implements BinderFactory {

        @Override
        public Binder build(Annotation annotation) {
            return new Binder<BindListIntegers, List<Integer>>() {

                @Override
                public void bind(SQLStatement<?> sqlStatement, BindListIntegers bindArray, List<Integer> list) {
                    try {
                        Array ary = sqlStatement.getContext()
                                .getConnection()
                                .createArrayOf("integer", list != null ? list.toArray() : new Integer[0]);
                        sqlStatement.bindBySqlType(bindArray.value(), ary, Types.ARRAY);
                    }
                    catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }
            };
        }
    }
}
