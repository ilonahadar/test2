package com.elsevier.epic.testing.integration.api;

import com.squareup.okhttp.Interceptor;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import java.io.IOException;

public class AddAuthenticationHeader implements Interceptor {
    @Override
    public Response intercept(Chain chain) throws IOException {
        Request authenticatedRequest = chain.request()
                .newBuilder()
                .header("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1aWQiOiJ0ZXN0cGF1bCIsImFsIjozLCJzaXMiOlsxNzgsMzY4NzIxLDQ2OSw1MzY2OTQsMjQ2NjYxLDQ0OTEwLDI2OCwyNzE5NiwyOTYsMzM1MzgwLDUyNTUyMCwyNDk5LDE3NTgsMTc1NCwzMjU5MDgsMTc1Niw2MjQsMjcxOTQsODY2LDE3NjIsNTEyMDUwLDU0NzY4NywxNzYwLDI3Mjk0XSwiZW1haWwiOiJwLm1hbmlhc0BlbHNldmllci5jb20ifQ.dbhAnRp_L9Iqin7KYN5qrLofX03kXhPHB84L1tVWYj0")
                .build();
        return chain.proceed(authenticatedRequest);
    }
}
