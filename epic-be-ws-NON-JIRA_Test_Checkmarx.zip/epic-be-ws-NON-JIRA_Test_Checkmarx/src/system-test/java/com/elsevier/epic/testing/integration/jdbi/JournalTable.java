package com.elsevier.epic.testing.integration.jdbi;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;

public interface JournalTable {

    @SqlUpdate("insert into journal (crs_id, title, issn) values (:crs_id, :title, :issn)")
    int insert(@Bind("crs_id")int crs_id, @Bind("title")String title, @Bind("issn")String issn);

    @SqlUpdate("delete from journal")
    void deleteAllRows();
}
