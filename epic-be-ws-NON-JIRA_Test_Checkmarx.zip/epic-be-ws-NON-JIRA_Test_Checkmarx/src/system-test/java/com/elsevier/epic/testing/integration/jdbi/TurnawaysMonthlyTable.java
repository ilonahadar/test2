package com.elsevier.epic.testing.integration.jdbi;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;

//CREATE TABLE IF NOT EXISTS turnaways_monthly (
//        account_id INT NOT NULL,
//        issn       TEXT NOT NULL,
//        year       INT NOT NULL,
//        month      INT NOT NULL,
//        total      INT NOT NULL
//        );
public interface TurnawaysMonthlyTable {

    @SqlUpdate("insert into turnaways_monthly (account_id, issn, year, month, total) values (:account_id, :issn, :year, :month, :total)")
    int insert(@Bind("account_id")int account_id, @Bind("issn")String issn, @Bind("year")int year, @Bind("month")int month, @Bind("total")int total);

    @SqlUpdate("delete from turnaways_monthly")
    void deleteAllRows();
}
