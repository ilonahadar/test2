package com.elsevier.epic.testing.integration.api;

import com.squareup.okhttp.ResponseBody;
import retrofit.Call;
import retrofit.http.GET;
import retrofit.http.Path;

public interface EpicApi {

    @GET("/v3/account/{account}/sd/top/{count}/turnaways")
    Call<ResponseBody> turnaways(@Path("account") int accountId, @Path("count") int count);

}
